import { useState, useEffect, useCallback, useRef } from "react";

// ─── NOAA tide station IDs closest to each destination ───
const TIDE_STATIONS = {
  1: "8761927", // Honey Island - Shell Beach
  2: "8761927", // Manchac - Shell Beach
  3: "8761927", // Blind River - Shell Beach
  4: "8747437", // Grand Island - Bay Waveland
  5: "8761927", // Rabbit Island - Shell Beach
  6: "8747437", // Half Moon - Bay Waveland
  7: "8761927", // Isle Au Pitre - Shell Beach
  8: "8761927", // Lake Borgne - Shell Beach
  9: "8761927", // Big Branch - Shell Beach
  10: "8760922", // Barataria - Grand Isle
  11: "8741533", // Deer Island - Biloxi
  12: "8760922", // Grand Isle - Grand Isle
  13: "8741533", // Ship Island - Biloxi
  14: "8741533", // Cat Island - Biloxi
  15: "8764227", // Atchafalaya - Morgan City
};

// NOAA marine zone IDs for weather
const MARINE_ZONES = {
  1: "GMZ550", 2: "GMZ550", 3: "GMZ550", 4: "GMZ550", 5: "GMZ550",
  6: "GMZ550", 7: "GMZ550", 8: "GMZ550", 9: "GMZ550", 10: "GMZ556",
  11: "GMZ530", 12: "GMZ556", 13: "GMZ530", 14: "GMZ530", 15: "GMZ550",
};

// Nearest NOAA buoy coords per destination
const BUOY_COORDS = {
  1: [30.22, -89.67], 2: [30.22, -89.67], 3: [30.22, -89.67],
  4: [30.32, -89.37], 5: [30.17, -89.73], 6: [30.25, -89.37],
  7: [30.15, -89.17], 8: [30.00, -89.50], 9: [30.37, -89.80],
  10: [29.27, -89.96], 11: [30.38, -88.96], 12: [29.27, -89.96],
  13: [30.22, -88.95], 14: [30.22, -89.10], 15: [29.70, -91.20],
};

const GEAR_CATEGORIES = [
  { id:"safety", label:"Safety / Legal", emoji:"🚨", color:"#f87171", items:[
    {id:"s1",text:"USCG-approved life jacket — one per rider",critical:true},
    {id:"s2",text:"Throwable Type IV flotation device",critical:true},
    {id:"s3",text:"Handheld VHF radio (Uniden MHS75 or Standard Horizon HX40)",critical:true},
    {id:"s4",text:"Whistle attached to PFD",critical:false},
    {id:"s5",text:"Visual distress signals / flares (required for Gulf trips)",critical:true},
    {id:"s6",text:"Fire extinguisher — USCG B-1 rated",critical:true},
    {id:"s7",text:"Kill switch lanyard (always worn when riding)",critical:true},
    {id:"s8",text:"First aid kit — waterproof case",critical:false},
    {id:"s9",text:"LA and MS boating registrations onboard",critical:true},
  ]},
  { id:"nav", label:"Navigation", emoji:"📱", color:"#38bdf8", items:[
    {id:"n1",text:"Navionics app subscription (~$35/yr)",critical:true},
    {id:"n2",text:"onX Offroad app (~$30/yr) — swamp/WMA trips",critical:false},
    {id:"n3",text:"RAM handlebar mount for phone",critical:true},
    {id:"n4",text:"Waterproof phone mount with cover",critical:true},
    {id:"n5",text:"Backup handheld GPS — Garmin inReach or eTrex",critical:false},
  ]},
  { id:"storage", label:"Dry Storage / Carry", emoji:"🎒", color:"#a78bfa", items:[
    {id:"st1",text:"Waterproof dry bag 20L+ (Sealline or Sea to Summit)",critical:true},
    {id:"st2",text:"Waterproof phone pouch (backup)",critical:false},
    {id:"st3",text:"Small soft cooler for drinks/food",critical:false},
    {id:"st4",text:"Bungee cargo net for ski deck",critical:false},
    {id:"st5",text:"Pelican 1060 dry box for valuables",critical:false},
  ]},
  { id:"fuel", label:"Fuel / Mechanical", emoji:"⛽", color:"#fbbf24", items:[
    {id:"f1",text:"Portable fuel can — 2.5 gal min for remote trips",critical:true},
    {id:"f2",text:"Fuel funnel",critical:false},
    {id:"f3",text:"Basic tool kit — screwdrivers, pliers, zip ties, tape",critical:false},
    {id:"f4",text:"Spare spark plugs (ski-specific)",critical:false},
    {id:"f5",text:"Tow rope",critical:false},
    {id:"f6",text:"Bilge pump — manual backup",critical:false},
    {id:"f7",text:"WD-40 or ACF-50 — corrosion protection after saltwater",critical:false},
  ]},
  { id:"sun", label:"Sun / Weather", emoji:"🌞", color:"#fb923c", items:[
    {id:"w1",text:"SPF 50+ reef-safe sunscreen",critical:true},
    {id:"w2",text:"Buff / neck gaiter for sun and wind",critical:false},
    {id:"w3",text:"Polarized sunglasses with retention strap",critical:true},
    {id:"w4",text:"Rash guard or long sleeve sun shirt",critical:false},
    {id:"w5",text:"Neoprene gloves (for winter swamp rides)",critical:false},
    {id:"w6",text:"3mm wetsuit or drysuit (November–February)",critical:false},
    {id:"w7",text:"Waterproof watch or sport watch with compass",critical:false},
  ]},
  { id:"bugs", label:"Bugs / Hydration", emoji:"🦟", color:"#34d399", items:[
    {id:"b1",text:"DEET-based bug spray — 100% DEET for Atchafalaya",critical:true},
    {id:"b2",text:"Permethrin spray for clothing",critical:false},
    {id:"b3",text:"Lip balm with SPF",critical:false},
    {id:"b4",text:"Electrolyte packets — summer heat is serious",critical:true},
    {id:"b5",text:"2L minimum water per person per trip",critical:true},
  ]},
  { id:"anchor", label:"Island / Sandbar", emoji:"⚓", color:"#22d3ee", items:[
    {id:"a1",text:"Folding anchor — Seachoice or Mantus for sandy bottoms",critical:false},
    {id:"a2",text:"25ft+ anchor line",critical:false},
    {id:"a3",text:"Stake-out pole for marsh/shallow stops",critical:false},
    {id:"a4",text:"Small folding chairs or beach mat",critical:false},
    {id:"a5",text:"Trash bag — leave no trace",critical:false},
  ]},
  { id:"trailer", label:"Trailer / Launch", emoji:"🚗", color:"#e879f9", items:[
    {id:"t1",text:"Spare trailer tire + jack",critical:true},
    {id:"t2",text:"Trailer tire pressure gauge",critical:false},
    {id:"t3",text:"Wheel bearing protectors / Bearing Buddy caps",critical:true},
    {id:"t4",text:"Trailer lights tester",critical:false},
    {id:"t5",text:"Bow and stern tie-down straps",critical:true},
    {id:"t6",text:"Wheel chocks",critical:false},
    {id:"t7",text:"Launch ramp water shoes with grip",critical:false},
  ]},
  { id:"admin", label:"Planning / Admin", emoji:"📋", color:"#fde68a", items:[
    {id:"ad1",text:"Laminated float plan cards — fill out every trip",critical:true},
    {id:"ad2",text:"Physical tide chart for coastal trips",critical:false},
    {id:"ad3",text:"NOAA marine forecast bookmarked on phone",critical:true},
    {id:"ad4",text:"Emergency contacts saved offline",critical:true},
    {id:"ad5",text:"Louisiana fishing license (if fishing)",critical:false},
    {id:"ad6",text:"Mississippi fishing license (if fishing in MS waters)",critical:false},
  ]},
];

const destinations = [
  { id:1, name:"Honey Island Swamp", subtitle:"Pearl River System", category:"Inshore Marsh", emoji:"🐊", level:"easy", drive:"35 min", month:"January", waterDiff:1, remoteness:3, experience:4, color:"#00e5a0", launch:"Crawford Landing, 41490 Crawford Landing Rd, Slidell, LA", launchType:"Free public ramp", bestSeason:"Year-round · Best: Spring/Fall", description:"Your literal backyard. Cypress canopy, gators, herons, otters. Multiple channels to explore for hours.", disclaimers:["All channels look identical — offline GPS maps are non-negotiable","Submerged logs and stumps common — slow down in tight channels","Alligators active April–October — do not idle near banks or swim","Cell service is spotty — download maps before leaving the ramp","Tidal influence near the mouth — check tides for your return","Leave a float plan with someone onshore"], roundTripMiles:40, mapUrl:"https://www.google.com/maps/search/Crawford+Landing+Slidell+LA" },
  { id:2, name:"Manchac Swamp", subtitle:"Pass Manchac", category:"Inshore Swamp", emoji:"🌑", level:"easy", drive:"30 min", month:"February", waterDiff:1, remoteness:3, experience:4, color:"#a78bfa", launch:"Joyce WMA Boat Ramp, off Hwy 51, LaPlace, LA", launchType:"Free public ramp", bestSeason:"Fall/Winter · Atmospheric in fog", description:"Spooky beautiful cypress swamp connecting Lake Maurepas to Lake Pontchartrain. One of Louisiana's most storied waterways.", disclaimers:["Heavy boat traffic on weekends near the interstate bridge","Extremely shallow in some back channels — know your draft depth","Fog is common winter mornings — reduce speed, use nav lights","No facilities once you leave the ramp — fuel up beforehand","Water hyacinth can choke smaller channels in summer","Respect no-wake zones near private camps — enforcement occurs"], roundTripMiles:30, mapUrl:"https://www.google.com/maps/search/Joyce+WMA+Boat+Ramp+LaPlace+LA" },
  { id:3, name:"Blind River", subtitle:"Lake Maurepas", category:"River/Lake", emoji:"🍃", level:"easy", drive:"40 min", month:"March", waterDiff:2, remoteness:3, experience:3, color:"#34d399", launch:"Blind River Public Boat Launch, off Hwy 22 near Acy, LA", launchType:"Free public ramp", bestSeason:"Spring/Fall", description:"Winding cypress-lined river opening into Lake Maurepas. Peaceful and underrated. Link to Manchac for a full loop day.", disclaimers:["Lake Maurepas builds 2–3 ft chop in sustained winds over 15 mph","Low-clearance bridges on the river — scout before first run","Private camp docks line the river — watch for unmarked pilings","Freshwater mussel beds in shallows near the lake — avoid","No fueling options on the water — bring enough","Water levels vary significantly — call ahead after heavy rains"], roundTripMiles:35, mapUrl:"https://www.google.com/maps/search/Blind+River+Boat+Launch+Acy+LA" },
  { id:4, name:"Grand Island", subtitle:"Pearl River Mouth", category:"Near-Coast Island", emoji:"🏝️", level:"easy", drive:"50 min", month:"April", waterDiff:2, remoteness:3, experience:3, color:"#fbbf24", launch:"Pearlington Public Ramp, off Hwy 90, Pearlington, MS", launchType:"Free public ramp · Also: White's Bayou RV Park", bestSeason:"Spring/Summer/Fall", description:"Pearl River mouth sandbars and marsh islands. Remote feel without serious Gulf exposure. Quick easy run from Pearlington.", disclaimers:["River debris and submerged logs common near the mouth","Shallow shifting sandbars — passable one week, grounded the next","You cross LA/MS state line on water — carry both registrations","Mississippi Sound builds chop quickly with afternoon sea breeze","No fuel or services near the island — fill up in Pearlington","Mosquitoes are intense April–October — bring serious repellent"], roundTripMiles:20, mapUrl:"https://www.google.com/maps/search/Pearlington+MS+boat+ramp" },
  { id:5, name:"Rabbit Island", subtitle:"Lake Catherine", category:"Near-Shore Island", emoji:"⚓", level:"easy", drive:"55 min", month:"May", waterDiff:2, remoteness:3, experience:3, color:"#22d3ee", launch:"Lake Catherine Island Marina, 26204 Chef Menteur Hwy, New Orleans", launchType:"Full service · Fuel, bait, wet/dry slips, lodging", bestSeason:"Spring/Summer", description:"Popular local anchor-up sandbar near the Rigolets. NOLA locals' go-to for a quick beach day on protected water.", disclaimers:["Very busy summer weekends — heavy boat traffic, large wake hazards","Tidal current through the Rigolets is strong — don't fight an outgoing tide","No shade or facilities on the island — bring sun protection and water","Oyster beds at the island edges damage lower units at low tide","Alcohol-fueled crowds on weekends — stay alert for erratic boats"], roundTripMiles:25, mapUrl:"https://www.google.com/maps/place/Lake+Catherine+Island+Marina" },
  { id:6, name:"Half Moon Island", subtitle:"Mississippi Sound", category:"Near-Shore Island", emoji:"🌙", level:"moderate", drive:"60 min", month:"September", waterDiff:2, remoteness:4, experience:4, color:"#818cf8", launch:"LaFrance Fishing Camp, NW of Heron Bay, Hancock Co., MS", launchType:"Private launch + bait shop", bestSeason:"Sept–Oct for redfish · Spring also excellent", description:"Louisiana waters just across the MS line. Shallow marsh ponds with sight-fishing for bull reds. Best hidden gem near Pearlington.", disclaimers:["Louisiana waters — Louisiana fishing license required even launching from MS","Very shallow SW side — draft your ski before riding interior ponds","Hard oyster shell bottom — grounding here will cause serious damage","September brings heavy fishing boat traffic — watch your surroundings","Mississippi Sound gets rough fast in afternoon winds — be off water by 1pm","No cell service near the island — offline GPS required","First time? Hire a local guide to learn the channels"], roundTripMiles:30, mapUrl:"https://www.google.com/maps/search/LaFrance+Fishing+Camp+Heron+Bay+MS" },
  { id:7, name:"Isle Au Pitre", subtitle:"Biloxi Marsh", category:"Near-Shore Island", emoji:"🗺️", level:"moderate", drive:"70 min", month:"October", waterDiff:3, remoteness:4, experience:5, color:"#fb923c", launch:"Hopedale Marina, end of LA-624, Hopedale, LA", launchType:"Full service · Ramp, live bait, fuel, cabin rentals, RV campground", bestSeason:"Spring/Fall · Peak fishing Sept–Nov", description:"Northeastern tip of Louisiana's entire marsh realm. Sandy shoreline, incredible fishing, endless channels. The #1 hidden gem on this entire list.", disclaimers:["Do not attempt solo — two skis minimum, this is a remote trip","Navigation is extremely complex — Navionics offline maps required","Hurricane Katrina permanently altered the island — old charts unreliable","Flatboat Key oyster reef — anchor will not hold, very hard bottom","Open marsh sections fully exposed to Gulf wind — 15+ mph makes this rough","Fuel at Hopedale before launch — no other fuel options in range","Round trip from Hopedale can be 40+ miles — fuel plan accordingly","Bring a VHF radio — this is a genuine offshore-adjacent trip"], roundTripMiles:45, mapUrl:"https://www.google.com/maps/place/Hopedale+Marina" },
  { id:8, name:"Lake Borgne", subtitle:"MRGO Corridor", category:"Coastal Open Water", emoji:"🌬️", level:"moderate", drive:"70 min", month:"November", waterDiff:3, remoteness:4, experience:4, color:"#38bdf8", launch:"Hopedale Marina, LA-624 · OR Shell Beach public ramp, St. Bernard Parish", launchType:"Hopedale: Full service · Shell Beach: Free public ramp", bestSeason:"Fall/Winter · Waterfowl migration peak Nov–Dec", description:"Wide open coastal water connecting to the Gulf. Remote, wild, dolphins and sea turtles common. Powerful sense of scale and wilderness.", disclaimers:["Lake Borgne is large and fully exposed — no shelter, weather moves fast","Check NOAA marine forecast night before AND morning of — no exceptions","MRGO channel has commercial vessel traffic — yield to ship traffic","Cold fronts in November produce dangerous conditions with little warning","Handheld VHF radio required — Coast Guard monitoring active here","Do not attempt without ability to read a nautical chart","Hypothermia risk in winter — wetsuit or drysuit November–February","Two skis required — you are far from help if one breaks down"], roundTripMiles:50, mapUrl:"https://www.google.com/maps/place/Hopedale+Marina" },
  { id:9, name:"Big Branch Marsh", subtitle:"Lacombe / NWR", category:"Freshwater Marsh", emoji:"🦅", level:"easy", drive:"25 min", month:"December", waterDiff:1, remoteness:3, experience:3, color:"#86efac", launch:"Big Branch Marsh NWR Boat Launch, off Hwy 434, Lacombe, LA", launchType:"Free public ramp · National Wildlife Refuge", bestSeason:"Winter/Spring · Best birding Nov–March", description:"Right on your doorstep from Covington. Freshwater marsh with pine island ridges and incredible bird life. Almost zero PWC traffic.", disclaimers:["National Wildlife Refuge — strict rules, no disturbing wildlife","Speed limits enforced in refuge waters — obey all no-wake zones","Some areas closed seasonally for nesting — check USFWS first","Watch for exposed mud and oyster beds at low tide","Loud/aggressive riding is inappropriate here — respect the space","Lake Pontchartrain south shore access can have chop — check conditions"], roundTripMiles:20, mapUrl:"https://www.google.com/maps/search/Big+Branch+Marsh+NWR+Lacombe+LA" },
  { id:10, name:"Barataria Basin", subtitle:"Jean Lafitte Area", category:"Inshore Coastal Marsh", emoji:"🐊", level:"moderate", drive:"90 min", month:"April", waterDiff:2, remoteness:4, experience:5, color:"#4ade80", launch:"Crown Point Boat Ramp, Hwy 3134, Marrero, LA · OR Lafitte Harbor Marina", launchType:"Crown Point: Free public ramp · Lafitte Harbor: Full service", bestSeason:"Spring/Fall · Avoid summer midday heat", description:"One of the most productive inshore fisheries in the US. Endless marsh channels, remote fishing camps, incredible wildlife. Lose hours out here.", disclaimers:["Extremely easy to get disoriented — offline Navionics maps required","Download maps at home — cell service disappears within 30 min","Oil and gas infrastructure throughout — submerged wellhead pipes are real hazards","Alligators are abundant and large — don't stop engine near a bank gator","Water moccasins common on floating vegetation — avoid debris","Afternoon thunderstorms build fast June–September — off open water by noon","Fuel up at Lafitte Harbor — running dry here puts you miles from help"], roundTripMiles:55, mapUrl:"https://www.google.com/maps/search/Crown+Point+Boat+Ramp+Marrero+LA" },
  { id:11, name:"Deer Island", subtitle:"Biloxi, MS", category:"Near-Shore Island", emoji:"🦌", level:"moderate", drive:"90 min", month:"June", waterDiff:2, remoteness:3, experience:3, color:"#fde68a", launch:"Biloxi Small Craft Harbor, Biloxi, MS", launchType:"Public launch · Fuel and amenities nearby", bestSeason:"Summer", description:"Less than half a mile from the Biloxi waterfront. Easy beach landing, relaxed vibe, often overlooked compared to Ship and Cat.", disclaimers:["MS requires NASBLA boater safety certificate if born after Jan 1, 1988","Very heavy boat traffic leaving Biloxi Small Craft Harbor — use caution","Casino boat wakes near the harbor can be significant","Deer Island is a MS State Wildlife Area — no fires, no camping","Jellyfish are extremely common in summer — avoid swimming or wear a wetsuit","Afternoon sea breeze builds 2–4 ft chop by 1–2pm in summer"], roundTripMiles:5, mapUrl:"https://www.google.com/maps/search/Biloxi+Small+Craft+Harbor" },
  { id:12, name:"Grand Isle", subtitle:"Fourchon Beach", category:"Gulf Coast Beach", emoji:"🏖️", level:"advanced", drive:"2 hrs", month:"July", waterDiff:3, remoteness:3, experience:4, color:"#fb7185", launch:"Grand Isle Marina or Bridge Side Marina, Grand Isle, LA · OR Port Fourchon Marina", launchType:"Full service · Fuel, bait, slips, overnight at Grand Isle", bestSeason:"Summer · Spring also ideal", description:"13 miles of restored Gulf beach between Grand Isle and Fourchon. Ride east or west all day. Dolphins common. Fuel and food at Grand Isle.", disclaimers:["Gulf conditions change fast — NOAA marine forecast required every trip","Do not ride more than 1 mile offshore without VHF radio and float plan","Submerged wellheads and petroleum infrastructure throughout the area","Oil residue on beach possible (Deepwater Horizon legacy) — avoid tar","Jellyfish and Portuguese man-o-war common in summer","Hurricane season June–November — have an exit plan ready","Check weather before leaving Covington — 2 hr drive, no turning back","Fuel at Grand Isle Marina before heading west — no fuel on water to Fourchon"], roundTripMiles:60, mapUrl:"https://www.google.com/maps/search/Grand+Isle+Marina+Louisiana" },
  { id:13, name:"Ship Island", subtitle:"Gulf Islands Nat'l Seashore", category:"Offshore Gulf Island", emoji:"⛵", level:"advanced", drive:"2 hrs", month:"August", waterDiff:4, remoteness:4, experience:5, color:"#f87171", launch:"Ocean Springs Harbor or Gulfport Small Craft Harbor, MS", launchType:"Public ramps · Fuel and full amenities at both", bestSeason:"Late Spring/Summer · Calm Gulf only", description:"The crown jewel. White sand barrier island, Civil War fort ruins, dolphins on the 12-mile Gulf crossing. Best single destination in the region.", disclaimers:["🚨 12 MILES OFFSHORE — serious open Gulf crossing, not a casual ride","Only attempt with winds under 10 mph and seas under 1 ft — check 48 hrs out","TWO SKIS REQUIRED — breakdown 12 miles offshore alone is life-threatening","Handheld VHF radio required — file float plan with marina AND someone onshore","MS requires NASBLA certificate if born after Jan 1, 1988","Gulf current runs east-west — account for drift or you'll arrive off-target","Bring minimum 2L water per person, heavy SPF, a hat — zero shade","Plan return crossing by 12:30pm — afternoon storms are common in August","National Seashore — no fires, no collecting shells or artifacts","If conditions deteriorate mid-crossing: slow down, beam to waves, call CG VHF 16"], roundTripMiles:25, mapUrl:"https://www.google.com/maps/search/Ocean+Springs+Harbor+MS" },
  { id:14, name:"Cat Island", subtitle:"Gulf Islands, MS", category:"Offshore Gulf Island", emoji:"🐱", level:"advanced", drive:"1.5 hrs", month:"May", waterDiff:4, remoteness:4, experience:4, color:"#f472b6", launch:"Pass Christian Harbor or Long Beach Harbor, MS", launchType:"Public ramps · Pass Christian has fuel", bestSeason:"Late Spring/Early Summer", description:"Wilder and more remote than Ship Island. No facilities, true wilderness feel. Excellent fishing all around the island. Slightly closer from MS coast.", disclaimers:["10–12 miles offshore — same rules as Ship Island apply in full","No facilities on Cat Island — completely self-sufficient trip","Rocky and oyster shell bottom in areas — approach carefully at low tide","Less visited than Ship Island means less help if something goes wrong","Two skis required and VHF radio required — non-negotiable","Study a nautical chart before this trip — complex shoreline","Rip currents possible on Gulf-facing south shore — swim on north side","Check NOAA Gulf forecast 48 hours out, not just morning-of"], roundTripMiles:22, mapUrl:"https://www.google.com/maps/search/Pass+Christian+Harbor+MS" },
  { id:15, name:"Atchafalaya Basin", subtitle:"Henderson / Butte La Rose", category:"Inshore Swamp", emoji:"🌲", level:"advanced", drive:"1.75 hrs", month:"March", waterDiff:2, remoteness:5, experience:5, color:"#2dd4bf", launch:"Atchafalaya Basin Landing, 1377 Henderson Levee Rd, Henderson, LA · OR Cypress Cove Landing, 1399 Henderson Levee Rd", launchType:"Basin Landing: 3-lane ramp, $5 launch · Cypress Cove: 24/7 ramp + restaurant", bestSeason:"Spring high water for flooded forest · Fall for fishing", description:"Largest river swamp in North America. Ancient cypress/tupelo forest, bald eagles, otters. Ride through flooded forest in spring. Bucket list.", disclaimers:["The Basin is enormous — offline GPS required, cell service is zero inside","Spring high water is magic but brings fast-moving current — know your handling","Submerged stumps and logging debris everywhere — never ride fast in unfamiliar areas","Water level fluctuates dramatically — passable in April may be dry in September","Commercial crawfish operations work these waters — give traplines full clearance","No facilities inside the levee — fuel completely before launching","Biting insects are legendary April–October — long sleeves and DEET required","Alligators are large and numerous — respect their space especially in June","Genuinely remote — two skis minimum, VHF radio, float plan, tell someone your route"], roundTripMiles:60, mapUrl:"https://www.google.com/maps/place/Atchafalaya+Basin+Landing" },
];

const LEVEL = {
  easy:     {label:"Easy",    dot:"🟢",bg:"#052e16",border:"#16a34a",text:"#4ade80"},
  moderate: {label:"Moderate",dot:"🟡",bg:"#3b1d00",border:"#d97706",text:"#fcd34d"},
  advanced: {label:"Advanced",dot:"🔴",bg:"#3b0000",border:"#dc2626",text:"#f87171"},
};

// ─── GO/NO-GO SCORING ───────────────────────────────────────
function getGoScore(weather, dest) {
  if (!weather) return null;
  let score = 100;
  const issues = [];
  const windSpeed = weather.windSpeed || 0;
  const waveHeight = weather.waveHeight || 0;
  const isGulf = dest.waterDiff >= 3;
  const isOffshore = dest.waterDiff >= 4;

  if (isOffshore) {
    if (windSpeed > 10) { score -= 40; issues.push(`Wind ${windSpeed}mph — too high for offshore crossing`); }
    else if (windSpeed > 7) { score -= 20; issues.push(`Wind ${windSpeed}mph — borderline for offshore`); }
    if (waveHeight > 1) { score -= 40; issues.push(`Waves ${waveHeight}ft — too rough for offshore`); }
    else if (waveHeight > 0.5) { score -= 20; issues.push(`Waves ${waveHeight}ft — getting rough`); }
  } else if (isGulf) {
    if (windSpeed > 15) { score -= 35; issues.push(`Wind ${windSpeed}mph — too high for coastal`); }
    else if (windSpeed > 10) { score -= 15; issues.push(`Wind ${windSpeed}mph — use caution`); }
    if (waveHeight > 2) { score -= 30; issues.push(`Waves ${waveHeight}ft — rough coastal conditions`); }
  } else {
    if (windSpeed > 20) { score -= 25; issues.push(`Wind ${windSpeed}mph — choppy inland water`); }
    else if (windSpeed > 15) { score -= 10; issues.push(`Wind ${windSpeed}mph — moderate chop possible`); }
  }
  if (weather.shortForecast?.toLowerCase().includes("thunder")) { score -= 30; issues.push("Thunderstorms forecast — do not go"); }
  if (weather.shortForecast?.toLowerCase().includes("storm")) { score -= 25; issues.push("Storm conditions forecast"); }

  score = Math.max(0, Math.min(100, score));
  const label = score >= 80 ? "GO" : score >= 50 ? "CAUTION" : "NO GO";
  const color = score >= 80 ? "#4ade80" : score >= 50 ? "#fbbf24" : "#f87171";
  return { score, label, color, issues };
}

// ─── MAPS DATA ───────────────────────────────────────────────
// Precise ramp coordinates for Google Maps navigation
const RAMP_COORDS = {
  1:  { lat:30.3158, lng:-89.7823, name:"Crawford Landing, Slidell LA" },
  2:  { lat:30.2541, lng:-90.3274, name:"Joyce WMA Ramp, LaPlace LA" },
  3:  { lat:30.2215, lng:-90.4821, name:"Blind River Launch, Acy LA" },
  4:  { lat:30.3518, lng:-89.5934, name:"Pearlington Public Ramp, MS" },
  5:  { lat:30.1743, lng:-89.7301, name:"Lake Catherine Island Marina, New Orleans" },
  6:  { lat:30.2489, lng:-89.4312, name:"LaFrance Fishing Camp, Heron Bay MS" },
  7:  { lat:29.9712, lng:-89.4682, name:"Hopedale Marina, Hopedale LA" },
  8:  { lat:29.9712, lng:-89.4682, name:"Hopedale Marina, Hopedale LA" },
  9:  { lat:30.4231, lng:-89.9012, name:"Big Branch Marsh NWR Launch, Lacombe LA" },
  10: { lat:29.8712, lng:-90.1034, name:"Crown Point Boat Ramp, Marrero LA" },
  11: { lat:30.3891, lng:-88.9123, name:"Biloxi Small Craft Harbor, Biloxi MS" },
  12: { lat:29.2423, lng:-89.9612, name:"Grand Isle Marina, Grand Isle LA" },
  13: { lat:30.3912, lng:-88.8234, name:"Ocean Springs Harbor, Ocean Springs MS" },
  14: { lat:30.3312, lng:-89.2534, name:"Pass Christian Harbor, Pass Christian MS" },
  15: { lat:30.3134, lng:-91.7923, name:"Atchafalaya Basin Landing, Henderson LA" },
};

// Destination water coords for nautical chart centering
const WATER_COORDS = {
  1:  { lat:30.28,  lng:-89.78 },
  2:  { lat:30.25,  lng:-90.32 },
  3:  { lat:30.22,  lng:-90.48 },
  4:  { lat:30.35,  lng:-89.59 },
  5:  { lat:30.17,  lng:-89.73 },
  6:  { lat:30.25,  lng:-89.43 },
  7:  { lat:29.97,  lng:-89.47 },
  8:  { lat:30.00,  lng:-89.50 },
  9:  { lat:30.42,  lng:-89.90 },
  10: { lat:29.60,  lng:-90.10 },
  11: { lat:30.38,  lng:-89.00 },
  12: { lat:29.24,  lng:-89.96 },
  13: { lat:30.22,  lng:-88.95 },
  14: { lat:30.22,  lng:-89.10 },
  15: { lat:29.70,  lng:-91.20 },
};

function buildMapLinks(destId) {
  const ramp = RAMP_COORDS[destId];
  const water = WATER_COORDS[destId];
  const noaaZoom = 13;
  return {
    // Navigate to ramp — opens Apple Maps on iOS, Google Maps on Android
    appleMaps: `https://maps.apple.com/?daddr=${ramp.lat},${ramp.lng}&dirflg=d`,
    googleMaps: `https://www.google.com/maps/dir/?api=1&destination=${ramp.lat},${ramp.lng}&travelmode=driving`,
    // Satellite view of the ramp
    satellite: `https://www.google.com/maps/@${ramp.lat},${ramp.lng},17z/data=!3m1!1e3`,
    // NOAA nautical chart viewer centered on water destination
    noaaChart: `https://nauticalcharts.noaa.gov/charts/chart-viewer.html?lat=${water.lat}&lon=${water.lng}&zoom=${noaaZoom}`,
    // Navionics web chart
    navionics: `https://webapp.navionics.com/?lang=en#boating@8&key=_e%7BpEd%60%7EiO`,
    // Windy marine at destination
    windy: `https://www.windy.com/${water.lat}/${water.lng}?${water.lat},${water.lng},9`,
  };
}

// ─── HELPER COMPONENTS ──────────────────────────────────────
function Pill({ children, bg, border, color }) {
  return <span style={{ background:bg, border:`1px solid ${border}`, color, borderRadius:20, padding:"3px 10px", fontSize:11, fontWeight:700, letterSpacing:0.3, display:"inline-block" }}>{children}</span>;
}

function XpBar({ value, color }) {
  return (
    <div style={{ display:"flex", gap:3 }}>
      {[1,2,3,4,5].map(i=>(
        <div key={i} style={{ flex:1, height:5, borderRadius:3, background:i<=value?color:"rgba(255,255,255,0.08)", boxShadow:i<=value?`0 0 6px ${color}88`:"none", transition:"all 0.2s" }}/>
      ))}
    </div>
  );
}

// ─── WEATHER SCREEN ─────────────────────────────────────────

// Nearest NEXRAD radar station per destination
const DEST_RADAR = {
  1:  { station:"KLIX", lat:30.28, lon:-89.78, name:"Honey Island / Pearl River" },
  2:  { station:"KLIX", lat:30.25, lon:-90.32, name:"Manchac Swamp" },
  3:  { station:"KLIX", lat:30.22, lon:-90.48, name:"Blind River" },
  4:  { station:"KLIX", lat:30.35, lon:-89.59, name:"Grand Island" },
  5:  { station:"KLIX", lat:30.17, lon:-89.73, name:"Rabbit Island" },
  6:  { station:"KLIX", lat:30.25, lon:-89.43, name:"Half Moon Island" },
  7:  { station:"KLIX", lat:29.97, lon:-89.47, name:"Isle Au Pitre" },
  8:  { station:"KLIX", lat:30.00, lon:-89.50, name:"Lake Borgne" },
  9:  { station:"KLIX", lat:30.42, lon:-89.90, name:"Big Branch Marsh" },
  10: { station:"KLIX", lat:29.60, lon:-90.10, name:"Barataria Basin" },
  11: { station:"KMOB", lat:30.40, lon:-89.00, name:"Deer Island" },
  12: { station:"KLIX", lat:29.24, lon:-89.96, name:"Grand Isle" },
  13: { station:"KMOB", lat:30.22, lon:-88.95, name:"Ship Island" },
  14: { station:"KMOB", lat:30.22, lon:-89.10, name:"Cat Island" },
  15: { station:"KLCH", lat:29.70, lon:-91.20, name:"Atchafalaya Basin" },
};

function WeatherScreen({ destinations }) {
  const [selected, setSelected] = useState(destinations[0]);

  const radar = selected ? DEST_RADAR[selected.id] : null;

  // Build destination-specific radar URL — opens Weather.gov radar centered on destination
  const radarUrl = radar
    ? `https://radar.weather.gov/station/${radar.station}/standard`
    : "https://radar.weather.gov/";

  // Windy URL centered on destination coordinates
  const windyUrl = radar
    ? `https://www.windy.com/${radar.lat.toFixed(2)}/${radar.lon.toFixed(2)}?wind,${radar.lat.toFixed(2)},${radar.lon.toFixed(2)},10`
    : "https://www.windy.com/29.1/-89.9?wind,29.1,-89.9,9";

  const isOffshore = selected?.waterDiff >= 3;

  const links = [
    { label:`📡 Radar — ${radar?.name || "South Louisiana"}`, url:radarUrl, icon:"📡", desc:`Live NEXRAD radar (${radar?.station}) — the closest station to ${selected?.name || "your destination"}. Watch for storm cells building to the west and northwest.`, color:"#fb923c", highlight:true },
    { label:"Windy.com — Wind & Waves at Destination", url:windyUrl, icon:"💨", desc:`Opened centered on ${selected?.name || "your destination"}. Shows live wind speed, gusts, direction, and wave height at your exact riding area.`, color:"#4ade80", highlight:true },
    { label:"NOAA Marine Forecast — Gulf & Coastal LA/MS", url:"https://www.weather.gov/mob/", icon:"🌊", desc:"Official marine forecast for Gulf of Mexico, Lake Pontchartrain, and coastal waters. Check before every trip.", color:"#38bdf8" },
    { label:"NWS Offshore Forecast — LIX", url:"https://www.weather.gov/lix/offshoreforecast", icon:"🛥️", desc:"Detailed offshore marine forecast for Gulf of Mexico. Critical for Ship Island, Cat Island, Grand Isle trips.", color:"#a78bfa" },
    { label:"Weather.gov — New Orleans / Northshore", url:"https://www.weather.gov/lix/", icon:"🌤️", desc:"Full local forecast for the Northshore area. Check for thunderstorm timing and frontal systems.", color:"#fbbf24" },
    { label:"NOAA Tides & Currents", url:"https://tidesandcurrents.noaa.gov/map/", icon:"🌊", desc:"Tide predictions and water levels. Pick the station closest to your destination.", color:"#22d3ee" },
    { label:"NHC — Tropical Weather Outlook", url:"https://www.nhc.noaa.gov/gtwo.php", icon:"🌀", desc:"National Hurricane Center tropical outlook. Check June–November before any Gulf or coastal trip.", color:"#f87171" },
    ...(isOffshore ? [
      { label:"NOAA Offshore Forecast — Coastal Waters", url:"https://www.weather.gov/mob/cwf", icon:"⛵", desc:"Required reading before Ship Island or Cat Island crossings. Specific wave height and wind forecasts.", color:"#ef4444" },
      { label:"Passage Weather — Gulf of Mexico", url:"https://www.passageweather.com/index.php?id=5&forecast=wind&region=GoMexico&tz=UTC&type=2d", icon:"🗺️", desc:"Multi-day wind and wave charts for Gulf of Mexico. Plan offshore trips 2–3 days out.", color:"#f472b6" },
    ] : []),
  ];

  return (
    <div style={{ padding:"0 16px 100px" }}>
      {/* Destination selector */}
      <div style={{ marginBottom:14 }}>
        <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:1, marginBottom:8 }}>Select Destination</div>
        <div style={{ display:"flex", gap:8, overflowX:"auto", paddingBottom:4, WebkitOverflowScrolling:"touch" }}>
          {destinations.map(d=>(
            <button key={d.id} onClick={()=>setSelected(d)} style={{ flexShrink:0, padding:"8px 14px", borderRadius:16, border:`1.5px solid ${selected?.id===d.id?d.color+"88":"rgba(255,255,255,0.08)"}`, background:selected?.id===d.id?d.color+"18":"rgba(255,255,255,0.04)", color:selected?.id===d.id?d.color:"rgba(255,255,255,0.4)", fontSize:12, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap", transition:"all 0.15s" }}>{d.emoji} {d.name.split(" ")[0]}</button>
          ))}
        </div>
      </div>

      {/* Destination header */}
      {selected && (
        <div style={{ background:`${selected.color}12`, border:`1.5px solid ${selected.color}33`, borderRadius:16, padding:"12px 16px", marginBottom:14, display:"flex", gap:10, alignItems:"center" }}>
          <span style={{ fontSize:24 }}>{selected.emoji}</span>
          <div style={{ flex:1 }}>
            <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:16, color:"#fff" }}>{selected.name}</div>
            <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)" }}>{selected.subtitle} · Radar: {radar?.station}</div>
          </div>
          {isOffshore && <span style={{ fontSize:10, fontWeight:700, padding:"3px 8px", borderRadius:10, background:"rgba(248,113,113,0.15)", color:"#f87171", border:"1px solid rgba(248,113,113,0.3)" }}>+ Offshore</span>}
        </div>
      )}

      {/* Weather links */}
      <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
        {links.map((link,i)=>(
          <a key={i} href={link.url} target="_blank" rel="noopener noreferrer"
            style={{ display:"flex", gap:12, alignItems:"flex-start", background:link.highlight?`${link.color}14`:`${link.color}0a`, border:`${link.highlight?"2px":"1.5px"} solid ${link.color}${link.highlight?"66":"33"}`, borderRadius:18, padding:"14px 16px", textDecoration:"none", WebkitTapHighlightColor:"transparent" }}>
            <div style={{ width:44, height:44, borderRadius:14, background:`${link.color}18`, border:`1.5px solid ${link.color}44`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:22, flexShrink:0 }}>{link.icon}</div>
            <div style={{ flex:1 }}>
              <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:14, color:link.color, letterSpacing:0.3, marginBottom:4, lineHeight:1.3 }}>{link.label}</div>
              <div style={{ fontSize:11, color:"rgba(255,255,255,0.45)", lineHeight:1.55 }}>{link.desc}</div>
            </div>
            <span style={{ fontSize:16, color:"rgba(255,255,255,0.25)", flexShrink:0, marginTop:2 }}>→</span>
          </a>
        ))}
      </div>
    </div>
  );
}


// ─── FUEL CALCULATOR ────────────────────────────────────────
function FuelCalc({ destinations }) {
  const [tankSize, setTankSize] = useState(18);
  const [mpg, setMpg] = useState(4.5);
  const [fuelPrice, setFuelPrice] = useState(4.20);
  const [extraCan, setExtraCan] = useState(2.5);
  const [dest, setDest] = useState(destinations[0]);

  const totalFuel = tankSize + extraCan;
  const range = totalFuel * mpg;
  const tripMiles = dest?.roundTripMiles || 40;
  const fuelNeeded = tripMiles / mpg;
  const fuelCost = fuelNeeded * fuelPrice;
  const canMakeIt = range >= tripMiles;
  const buffer = range - tripMiles;
  const bufferPct = Math.round((buffer / range) * 100);

  const SliderRow = ({ label, value, setValue, min, max, step, unit, color }) => (
    <div style={{ marginBottom:16 }}>
      <div style={{ display:"flex", justifyContent:"space-between", marginBottom:8 }}>
        <span style={{ fontSize:12, color:"rgba(255,255,255,0.5)" }}>{label}</span>
        <span style={{ fontSize:14, fontFamily:"'Black Han Sans',sans-serif", color }}>{value}{unit}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value}
        onChange={e => setValue(parseFloat(e.target.value))}
        style={{ width:"100%", accentColor:color, cursor:"pointer" }} />
      <div style={{ display:"flex", justifyContent:"space-between", marginTop:2 }}>
        <span style={{ fontSize:9, color:"rgba(255,255,255,0.2)" }}>{min}{unit}</span>
        <span style={{ fontSize:9, color:"rgba(255,255,255,0.2)" }}>{max}{unit}</span>
      </div>
    </div>
  );

  return (
    <div style={{ padding:"0 16px 100px" }}>
      {/* Destination selector */}
      <div style={{ marginBottom:14 }}>
        <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:1, marginBottom:8 }}>Select Trip</div>
        <div style={{ display:"flex", gap:8, overflowX:"auto", paddingBottom:4 }}>
          {destinations.map(d=>(
            <button key={d.id} onClick={()=>setDest(d)} style={{
              flexShrink:0, padding:"8px 14px", borderRadius:16,
              border:`1.5px solid ${dest?.id===d.id?d.color+"88":"rgba(255,255,255,0.08)"}`,
              background:dest?.id===d.id?`${d.color}18`:"rgba(255,255,255,0.04)",
              color:dest?.id===d.id?d.color:"rgba(255,255,255,0.4)",
              fontSize:12, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap", transition:"all 0.15s"
            }}>{d.emoji} {d.name.split(" ")[0]}</button>
          ))}
        </div>
      </div>

      {/* Result card */}
      <div style={{
        background: canMakeIt
          ? buffer > 10 ? "linear-gradient(135deg,#052e16,#071a0e)" : "linear-gradient(135deg,#3b1d00,#1a0e00)"
          : "linear-gradient(135deg,#3b0000,#1a0000)",
        border:`2px solid ${canMakeIt ? buffer>10?"#16a34a":"#d97706" : "#dc2626"}`,
        borderRadius:22, padding:"18px 20px", marginBottom:18
      }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:14 }}>
          <div>
            <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:4 }}>Trip Fuel Status</div>
            <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:28,
              color:canMakeIt ? buffer>10?"#4ade80":"#fbbf24" : "#f87171" }}>
              {canMakeIt ? buffer > 10 ? "✓ SAFE RANGE" : "⚠ TIGHT — BRING CAN" : "✗ NOT ENOUGH FUEL"}
            </div>
          </div>
          <div style={{ textAlign:"right" }}>
            <div style={{ fontSize:11, color:"rgba(255,255,255,0.35)" }}>Est. Cost</div>
            <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:24, color:"#fbbf24" }}>${fuelCost.toFixed(2)}</div>
          </div>
        </div>

        {/* Fuel gauge bar */}
        <div style={{ marginBottom:10 }}>
          <div style={{ display:"flex", justifyContent:"space-between", marginBottom:5 }}>
            <span style={{ fontSize:11, color:"rgba(255,255,255,0.4)" }}>Fuel needed: {fuelNeeded.toFixed(1)} gal</span>
            <span style={{ fontSize:11, color:"rgba(255,255,255,0.4)" }}>Total available: {totalFuel} gal</span>
          </div>
          <div style={{ background:"rgba(255,255,255,0.08)", borderRadius:8, height:12, overflow:"hidden" }}>
            <div style={{
              height:12, borderRadius:8,
              width:`${Math.min(100, (fuelNeeded / totalFuel) * 100)}%`,
              background:canMakeIt ? buffer>10?"linear-gradient(90deg,#4ade80,#22c55e)":"linear-gradient(90deg,#fbbf24,#f59e0b)" : "linear-gradient(90deg,#f87171,#ef4444)",
              boxShadow:canMakeIt?"0 0 10px #4ade8055":"0 0 10px #f8717155",
              transition:"width 0.4s ease"
            }}/>
          </div>
          {canMakeIt && <div style={{ fontSize:11, color:"rgba(255,255,255,0.35)", marginTop:4 }}>Buffer: ~{buffer.toFixed(0)} miles ({bufferPct}% reserve)</div>}
        </div>

        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:8 }}>
          {[
            {label:"Round Trip",val:`${tripMiles} mi`,color:"#a78bfa"},
            {label:"Total Range",val:`${range.toFixed(0)} mi`,color:"#38bdf8"},
            {label:"Fuel Needed",val:`${fuelNeeded.toFixed(1)} gal`,color:"#fbbf24"},
          ].map(s=>(
            <div key={s.label} style={{ background:"rgba(255,255,255,0.05)", borderRadius:12, padding:"10px 8px", textAlign:"center" }}>
              <div style={{ fontSize:9, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.5, marginBottom:4 }}>{s.label}</div>
              <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:16, color:s.color }}>{s.val}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Sliders */}
      <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:18, padding:"18px 18px" }}>
        <div style={{ fontSize:12, color:"rgba(255,255,255,0.5)", fontWeight:700, textTransform:"uppercase", letterSpacing:0.8, marginBottom:18 }}>⚙️ Your Setup</div>
        <SliderRow label="Main Tank Size" value={tankSize} setValue={setTankSize} min={10} max={30} step={0.5} unit=" gal" color="#38bdf8"/>
        <SliderRow label="Extra Fuel Can" value={extraCan} setValue={setExtraCan} min={0} max={5} step={0.5} unit=" gal" color="#4ade80"/>
        <SliderRow label="MPG (avg cruise)" value={mpg} setValue={setMpg} min={2} max={8} step={0.5} unit=" mpg" color="#a78bfa"/>
        <SliderRow label="Fuel Price" value={fuelPrice} setValue={setFuelPrice} min={3} max={7} step={0.05} unit="/gal" color="#fbbf24"/>
      </div>

      {/* Tips */}
      <div style={{ background:"rgba(251,191,36,0.06)", border:"1px solid rgba(251,191,36,0.15)", borderRadius:16, padding:"14px 16px", marginTop:14 }}>
        <div style={{ fontSize:10, color:"#fbbf24", textTransform:"uppercase", letterSpacing:0.8, fontWeight:700, marginBottom:10 }}>💡 Fuel Tips</div>
        {["Always carry a 25% buffer minimum — currents, headwinds, and hard riding burn 30–40% more than cruise","Never pass the last fuel stop without filling up — even if you think you have enough","For remote trips (Atchafalaya, Isle Au Pitre) carry a full 2.5 gal can no matter what the calculator says","Marine gas prices at ramps are typically $0.50–1.00 more per gallon than road pumps"].map((t,i)=>(
          <div key={i} style={{ display:"flex", gap:8, marginBottom:8 }}>
            <span style={{ color:"#fbbf24", fontSize:12, flexShrink:0 }}>•</span>
            <span style={{ fontSize:12, color:"rgba(255,255,255,0.55)", lineHeight:1.5 }}>{t}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── GEAR CHECKLIST ─────────────────────────────────────────
function GearChecklist({ checked, onToggle }) {
  const [openCat, setOpenCat] = useState("safety");
  const totalItems = GEAR_CATEGORIES.reduce((a,c)=>a+c.items.length,0);
  const pct = Math.round((checked.size/totalItems)*100);
  return (
    <div>
      <div style={{ padding:"0 16px 14px" }}>
        <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:20, padding:"16px 18px" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
            <div>
              <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:18, color:"#fff" }}>Gear Checklist</div>
              <div style={{ fontSize:11, color:"rgba(255,255,255,0.35)", marginTop:2 }}>{checked.size}/{totalItems} items acquired</div>
            </div>
            <div style={{ fontSize:28, fontFamily:"'Black Han Sans',sans-serif", color:pct===100?"#4ade80":pct>60?"#fbbf24":"#f87171" }}>{pct}%</div>
          </div>
          <div style={{ background:"rgba(255,255,255,0.07)", borderRadius:8, height:8, overflow:"hidden" }}>
            <div style={{ height:8, borderRadius:8, width:`${pct}%`, background:"linear-gradient(90deg,#f87171,#fbbf24,#4ade80)", transition:"width 0.5s cubic-bezier(0.34,1.56,0.64,1)", boxShadow:"0 0 12px rgba(251,191,36,0.4)" }}/>
          </div>
          {pct===100 && <div style={{ marginTop:10, textAlign:"center", fontSize:13, color:"#4ade80", fontWeight:700 }}>🎉 Fully kitted out!</div>}
        </div>
      </div>
      <div style={{ padding:"0 16px 100px", display:"flex", flexDirection:"column", gap:8 }}>
        {GEAR_CATEGORIES.map(cat => {
          const catChecked = cat.items.filter(i=>checked.has(i.id)).length;
          const isOpen = openCat===cat.id;
          const allDone = catChecked===cat.items.length;
          return (
            <div key={cat.id} style={{ background:allDone?"linear-gradient(135deg,#071a0e,#050f08)":"linear-gradient(135deg,#0c1b2a,#08111c)", border:`1.5px solid ${allDone?"#16a34a55":cat.color+"44"}`, borderRadius:18, overflow:"hidden" }}>
              <div onClick={()=>setOpenCat(isOpen?null:cat.id)} style={{ padding:"14px 16px", cursor:"pointer", display:"flex", alignItems:"center", gap:12 }}>
                <div style={{ width:40, height:40, borderRadius:12, flexShrink:0, background:`${cat.color}18`, border:`1.5px solid ${cat.color}44`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:20 }}>{allDone?"✅":cat.emoji}</div>
                <div style={{ flex:1 }}>
                  <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:15, color:"#fff", letterSpacing:0.5 }}>{cat.label}</div>
                  <div style={{ fontSize:11, color:allDone?"#4ade80":"rgba(255,255,255,0.35)", marginTop:1 }}>{catChecked}/{cat.items.length} items {allDone?"✓ complete":""}</div>
                </div>
                <div style={{ display:"flex", gap:2 }}>
                  {cat.items.map(item=>(
                    <div key={item.id} style={{ width:5, height:5, borderRadius:"50%", background:checked.has(item.id)?cat.color:"rgba(255,255,255,0.1)", boxShadow:checked.has(item.id)?`0 0 4px ${cat.color}`:"none" }}/>
                  ))}
                </div>
                <span style={{ fontSize:14, color:"rgba(255,255,255,0.3)", marginLeft:6 }}>{isOpen?"▲":"▼"}</span>
              </div>
              {isOpen && (
                <div style={{ borderTop:`1px solid ${cat.color}22`, padding:"8px 12px 12px" }}>
                  {cat.items.map(item=>{
                    const isCh=checked.has(item.id);
                    return (
                      <div key={item.id} onClick={()=>onToggle(item.id)} style={{ display:"flex", alignItems:"flex-start", gap:10, padding:"10px 8px", borderRadius:12, cursor:"pointer", marginBottom:2, background:isCh?`${cat.color}0f`:"transparent", transition:"background 0.15s" }}>
                        <div style={{ width:22, height:22, borderRadius:7, flexShrink:0, marginTop:1, background:isCh?cat.color:"rgba(255,255,255,0.06)", border:`1.5px solid ${isCh?cat.color:"rgba(255,255,255,0.1)"}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:12, color:"#000", fontWeight:700, boxShadow:isCh?`0 0 10px ${cat.color}66`:"none", transition:"all 0.2s" }}>{isCh?"✓":""}</div>
                        <div style={{ flex:1 }}>
                          <span style={{ fontSize:13, color:isCh?"rgba(255,255,255,0.4)":"rgba(255,255,255,0.75)", textDecoration:isCh?"line-through":"none", lineHeight:1.5, transition:"all 0.2s" }}>{item.text}</span>
                          {item.critical&&!isCh&&<span style={{ marginLeft:6, fontSize:10, color:"#f87171", fontWeight:700, background:"#3b000066", border:"1px solid #dc262655", borderRadius:6, padding:"1px 5px" }}>CRITICAL</span>}
                        </div>
                      </div>
                    );
                  })}
                  <button onClick={()=>{ const allCh=cat.items.every(i=>checked.has(i.id)); cat.items.forEach(i=>{ if(allCh?checked.has(i.id):!checked.has(i.id)) onToggle(i.id); }); }} style={{ width:"100%", marginTop:8, padding:"10px", background:`${cat.color}15`, border:`1px solid ${cat.color}44`, borderRadius:12, color:cat.color, fontSize:12, fontWeight:700, cursor:"pointer" }}>
                    {cat.items.every(i=>checked.has(i.id))?"✓ Uncheck All":`Check All ${cat.label}`}
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── TRIP CARDS ─────────────────────────────────────────────
function TripCard({ dest, onClick, done, onDone, idx }) {
  const lv = LEVEL[dest.level];
  return (
    <div onClick={()=>onClick(dest)} style={{ background:done?"linear-gradient(135deg,#071a0e,#050f08)":"linear-gradient(135deg,#0c1b2a,#08111c)", border:`1.5px solid ${done?"#16a34a55":dest.color+"55"}`, borderRadius:22, padding:"18px 18px 16px", cursor:"pointer", position:"relative", overflow:"hidden", boxShadow:done?`0 4px 20px #16a34a18`:`0 4px 24px ${dest.color}15`, animation:`fadeSlide 0.35s ease both`, animationDelay:`${idx*0.045}s` }}>
      <div style={{ position:"absolute", top:0, left:0, right:0, height:3, background:`linear-gradient(90deg,${dest.color},${dest.color}22)`, borderRadius:"22px 22px 0 0" }}/>
      <div style={{ position:"absolute", right:-10, bottom:-10, fontSize:72, opacity:0.06, userSelect:"none", transform:"rotate(-10deg)" }}>{dest.emoji}</div>
      <div style={{ display:"flex", alignItems:"flex-start", gap:12 }}>
        <div style={{ width:50, height:50, borderRadius:16, flexShrink:0, background:`${dest.color}18`, border:`1.5px solid ${dest.color}55`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:24, boxShadow:`0 0 16px ${dest.color}22` }}>{dest.emoji}</div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:17, color:"#fff", letterSpacing:0.5, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{dest.name}</div>
          <div style={{ fontSize:11, color:"rgba(255,255,255,0.35)", marginTop:1 }}>{dest.subtitle}</div>
          <div style={{ display:"flex", gap:6, marginTop:8, flexWrap:"wrap" }}>
            <Pill bg={lv.bg} border={lv.border} color={lv.text}>{lv.dot} {lv.label}</Pill>
            <Pill bg="rgba(255,255,255,0.05)" border="rgba(255,255,255,0.1)" color="rgba(255,255,255,0.45)">🚗 {dest.drive}</Pill>
            <Pill bg="rgba(255,255,255,0.05)" border="rgba(255,255,255,0.1)" color="rgba(255,255,255,0.45)">📅 {dest.month}</Pill>
          </div>
        </div>
        <button onClick={e=>{e.stopPropagation();onDone(dest.id);}} style={{ width:34, height:34, borderRadius:12, border:"none", background:done?"#16a34a33":"rgba(255,255,255,0.06)", color:done?"#4ade80":"rgba(255,255,255,0.25)", fontSize:18, cursor:"pointer", flexShrink:0, display:"flex", alignItems:"center", justifyContent:"center", boxShadow:done?"0 0 12px #16a34a44":"none", transition:"all 0.2s" }}>{done?"✓":"○"}</button>
      </div>
      <div style={{ marginTop:14 }}>
        <div style={{ display:"flex", justifyContent:"space-between", marginBottom:5 }}>
          <span style={{ fontSize:10, color:"rgba(255,255,255,0.25)", textTransform:"uppercase", letterSpacing:0.8 }}>Experience</span>
          <span style={{ fontSize:10, color:dest.color, fontWeight:700 }}>{"★".repeat(dest.experience)}{"☆".repeat(5-dest.experience)}</span>
        </div>
        <XpBar value={dest.experience} color={dest.color}/>
      </div>
    </div>
  );
}

// ─── TRIP DETAIL SHEET ──────────────────────────────────────
function Sheet({ dest, onClose, done, onDone }) {
  const [tab, setTab] = useState("info");
  const lv = LEVEL[dest.level];

  useEffect(() => {
    const handler = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);

  return (
    <div
      style={{ position:"fixed", inset:0, zIndex:200, background:"rgba(0,0,0,0.8)", backdropFilter:"blur(8px)", display:"flex", alignItems:"flex-end" }}
      onClick={onClose}
    >
      <div
        onClick={e=>e.stopPropagation()}
        style={{ width:"100%", maxHeight:"92vh", overflowY:"auto", background:"#080f18", borderRadius:"28px 28px 0 0", border:`1.5px solid ${dest.color}44`, borderBottom:"none", animation:"sheetUp 0.3s cubic-bezier(0.34,1.3,0.64,1) both" }}
      >
        {/* Drag handle */}
        <div style={{ paddingTop:12, textAlign:"center" }}>
          <div style={{ width:40, height:5, borderRadius:3, background:"rgba(255,255,255,0.1)", display:"inline-block" }}/>
        </div>
        <div style={{ background:`linear-gradient(135deg,${dest.color}18 0%,transparent 70%)`, padding:"16px 20px 20px", borderBottom:`1px solid ${dest.color}22`, position:"relative", overflow:"hidden" }}>
          <div style={{ position:"absolute", right:-20, top:-20, fontSize:100, opacity:0.05 }}>{dest.emoji}</div>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
            <div style={{ display:"flex", gap:14, alignItems:"center" }}>
              <div style={{ width:60, height:60, borderRadius:20, flexShrink:0, background:`${dest.color}22`, border:`2px solid ${dest.color}66`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:30, boxShadow:`0 0 24px ${dest.color}33` }}>{dest.emoji}</div>
              <div>
                <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:24, color:"#fff", letterSpacing:0.5 }}>{dest.name}</div>
                <div style={{ fontSize:12, color:"rgba(255,255,255,0.4)", marginBottom:8 }}>{dest.subtitle}</div>
                <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                  <Pill bg={lv.bg} border={lv.border} color={lv.text}>{lv.dot} {lv.label}</Pill>
                  <Pill bg="rgba(255,255,255,0.06)" border="rgba(255,255,255,0.1)" color="rgba(255,255,255,0.45)">🚗 {dest.drive}</Pill>
                </div>
              </div>
            </div>
            <button
              onClick={e=>{e.stopPropagation();onClose();}}
              style={{ width:44, height:44, borderRadius:14, border:"none", background:"rgba(255,255,255,0.12)", color:"#fff", fontSize:20, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, zIndex:10, position:"relative" }}
            >✕</button>
          </div>
        </div>
        <div style={{ display:"flex", padding:"12px 16px 0", gap:6 }}>
          {[["info","📍 Info"],["maps","🗺️ Maps"],["launch","🚤 Launch"],["safety","⚠️ Safety"]].map(([t,l])=>(
            <button key={t} onClick={()=>setTab(t)} style={{ flex:1, padding:"10px 4px", borderRadius:16, border:tab===t?`1.5px solid ${dest.color}99`:"1.5px solid rgba(255,255,255,0.08)", background:tab===t?`${dest.color}20`:"rgba(255,255,255,0.03)", color:tab===t?dest.color:"rgba(255,255,255,0.35)", fontSize:11, fontWeight:700, cursor:"pointer", transition:"all 0.15s" }}>{l}</button>
          ))}
        </div>
        <div style={{ padding:"18px 20px 52px" }}>
          {tab==="info"&&(
            <div>
              <p style={{ fontSize:14, color:"rgba(255,255,255,0.65)", lineHeight:1.7, marginBottom:20 }}>{dest.description}</p>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:10, marginBottom:16 }}>
                {[{label:"Water",val:dest.waterDiff,color:"#38bdf8"},{label:"Remote",val:dest.remoteness,color:"#a78bfa"},{label:"XP",val:dest.experience,color:dest.color}].map(s=>(
                  <div key={s.label} style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:16, padding:"14px 10px", textAlign:"center" }}>
                    <div style={{ fontSize:9, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:8 }}>{s.label}</div>
                    <div style={{ display:"flex", gap:3, justifyContent:"center", marginBottom:6 }}>{[1,2,3,4,5].map(i=>(<div key={i} style={{ width:8, height:8, borderRadius:"50%", background:i<=s.val?s.color:"rgba(255,255,255,0.08)", boxShadow:i<=s.val?`0 0 6px ${s.color}`:"none" }}/>))}</div>
                    <div style={{ fontSize:22, fontFamily:"'Black Han Sans',sans-serif", color:s.color }}>{s.val}<span style={{ fontSize:11, color:"rgba(255,255,255,0.25)" }}>/5</span></div>
                  </div>
                ))}
              </div>
              <div style={{ background:`${dest.color}12`, border:`1px solid ${dest.color}33`, borderRadius:16, padding:"14px 16px", marginBottom:12 }}>
                <div style={{ fontSize:10, color:dest.color, textTransform:"uppercase", letterSpacing:0.8, fontWeight:700, marginBottom:6 }}>🌤 Best Season</div>
                <div style={{ fontSize:13, color:"rgba(255,255,255,0.7)" }}>{dest.bestSeason}</div>
              </div>
              <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:16, padding:"14px 16px" }}>
                <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:6 }}>📂 Category</div>
                <div style={{ fontSize:13, color:"rgba(255,255,255,0.6)" }}>{dest.category}</div>
              </div>
            </div>
          )}
          {tab==="maps"&&(()=>{
            const links = buildMapLinks(dest.id);
            const ramp = RAMP_COORDS[dest.id];
            const water = WATER_COORDS[dest.id];
            return (
              <div>
                {/* Ramp coordinates card */}
                <div style={{ background:`${dest.color}12`, border:`1.5px solid ${dest.color}44`, borderRadius:18, padding:"16px", marginBottom:14 }}>
                  <div style={{ fontSize:10, color:dest.color, textTransform:"uppercase", letterSpacing:0.8, fontWeight:700, marginBottom:10 }}>📍 Launch Ramp</div>
                  <div style={{ fontSize:13, color:"#fff", lineHeight:1.6, marginBottom:8 }}>{ramp.name}</div>
                  <div style={{ fontSize:11, color:"rgba(255,255,255,0.35)", fontFamily:"monospace" }}>
                    {ramp.lat.toFixed(4)}°N, {Math.abs(ramp.lng).toFixed(4)}°W
                  </div>
                </div>

                {/* Navigation buttons */}
                <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:8 }}>🚗 Navigate to Ramp</div>
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:18 }}>
                  <a href={links.appleMaps} target="_blank" rel="noopener noreferrer" style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:6, background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.1)", borderRadius:16, padding:"16px 10px", textDecoration:"none", cursor:"pointer" }}>
                    <span style={{ fontSize:28 }}>🍎</span>
                    <span style={{ fontSize:12, color:"#fff", fontWeight:700 }}>Apple Maps</span>
                    <span style={{ fontSize:10, color:"rgba(255,255,255,0.35)" }}>Turn-by-turn</span>
                  </a>
                  <a href={links.googleMaps} target="_blank" rel="noopener noreferrer" style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:6, background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.1)", borderRadius:16, padding:"16px 10px", textDecoration:"none", cursor:"pointer" }}>
                    <span style={{ fontSize:28 }}>🗺️</span>
                    <span style={{ fontSize:12, color:"#fff", fontWeight:700 }}>Google Maps</span>
                    <span style={{ fontSize:10, color:"rgba(255,255,255,0.35)" }}>Turn-by-turn</span>
                  </a>
                </div>

                {/* Satellite view */}
                <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:8 }}>🛰️ Scope Out the Ramp</div>
                <a href={links.satellite} target="_blank" rel="noopener noreferrer" style={{ display:"flex", alignItems:"center", gap:12, background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.1)", borderRadius:16, padding:"14px 16px", marginBottom:18, textDecoration:"none" }}>
                  <span style={{ fontSize:28 }}>🛰️</span>
                  <div>
                    <div style={{ fontSize:13, color:"#fff", fontWeight:700, marginBottom:2 }}>Satellite View</div>
                    <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)" }}>See the ramp, parking, and water access before you go</div>
                  </div>
                  <span style={{ fontSize:16, color:"rgba(255,255,255,0.3)", marginLeft:"auto" }}>→</span>
                </a>

                {/* Offline map reminder */}
                <div style={{ background:"rgba(251,191,36,0.08)", border:"1px solid rgba(251,191,36,0.25)", borderRadius:14, padding:"12px 14px", marginBottom:18 }}>
                  <div style={{ fontSize:11, color:"#fbbf24", fontWeight:700, marginBottom:4 }}>⬇️ Download Offline Maps Before You Go</div>
                  <div style={{ fontSize:11, color:"rgba(255,255,255,0.5)", lineHeight:1.6, marginBottom:8 }}>
                    Open Navionics or onX Offroad, navigate to this destination, and download the region for offline use. Do this at home on WiFi — not at the ramp.
                  </div>
                  <div style={{ display:"flex", gap:8 }}>
                    <a href="https://webapp.navionics.com" target="_blank" rel="noopener noreferrer" style={{ flex:1, textAlign:"center", background:"rgba(99,102,241,0.15)", border:"1px solid rgba(99,102,241,0.3)", borderRadius:10, padding:"8px", color:"#818cf8", fontSize:11, fontWeight:700, textDecoration:"none" }}>📡 Navionics</a>
                    <a href="https://www.onxmaps.com/offroad/app" target="_blank" rel="noopener noreferrer" style={{ flex:1, textAlign:"center", background:"rgba(251,146,60,0.15)", border:"1px solid rgba(251,146,60,0.3)", borderRadius:10, padding:"8px", color:"#fb923c", fontSize:11, fontWeight:700, textDecoration:"none" }}>🗺️ onX Offroad</a>
                  </div>
                </div>

                {/* On-water charts */}
                <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:8 }}>🧭 On-Water Charts</div>
                <div style={{ display:"flex", flexDirection:"column", gap:10, marginBottom:18 }}>
                  <a href={links.noaaChart} target="_blank" rel="noopener noreferrer" style={{ display:"flex", alignItems:"center", gap:12, background:"rgba(14,165,233,0.08)", border:"1px solid rgba(14,165,233,0.2)", borderRadius:16, padding:"14px 16px", textDecoration:"none" }}>
                    <span style={{ fontSize:24 }}>⚓</span>
                    <div style={{ flex:1 }}>
                      <div style={{ fontSize:13, color:"#38bdf8", fontWeight:700, marginBottom:2 }}>NOAA Nautical Chart</div>
                      <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)" }}>Depth contours, hazards, navigation markers</div>
                    </div>
                    <span style={{ fontSize:16, color:"rgba(14,165,233,0.5)" }}>→</span>
                  </a>
                  <a href={links.navionics} target="_blank" rel="noopener noreferrer" style={{ display:"flex", alignItems:"center", gap:12, background:"rgba(99,102,241,0.08)", border:"1px solid rgba(99,102,241,0.2)", borderRadius:16, padding:"14px 16px", textDecoration:"none" }}>
                    <span style={{ fontSize:24 }}>📡</span>
                    <div style={{ flex:1 }}>
                      <div style={{ fontSize:13, color:"#818cf8", fontWeight:700, marginBottom:2 }}>Navionics Web Chart</div>
                      <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)" }}>Community-updated inshore charts</div>
                    </div>
                    <span style={{ fontSize:16, color:"rgba(99,102,241,0.5)" }}>→</span>
                  </a>
                  <a href={links.windy} target="_blank" rel="noopener noreferrer" style={{ display:"flex", alignItems:"center", gap:12, background:"rgba(34,211,238,0.08)", border:"1px solid rgba(34,211,238,0.2)", borderRadius:16, padding:"14px 16px", textDecoration:"none" }}>
                    <span style={{ fontSize:24 }}>💨</span>
                    <div style={{ flex:1 }}>
                      <div style={{ fontSize:13, color:"#22d3ee", fontWeight:700, marginBottom:2 }}>Windy Marine</div>
                      <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)" }}>Live wind, waves, currents at destination</div>
                    </div>
                    <span style={{ fontSize:16, color:"rgba(34,211,238,0.5)" }}>→</span>
                  </a>
                </div>

                {/* Water coordinates */}
                <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:14, padding:"12px 16px" }}>
                  <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:8 }}>🌊 On-Water Coordinates</div>
                  <div style={{ fontSize:12, color:"rgba(255,255,255,0.5)", fontFamily:"monospace", marginBottom:4 }}>
                    Lat: {water.lat.toFixed(4)}°N
                  </div>
                  <div style={{ fontSize:12, color:"rgba(255,255,255,0.5)", fontFamily:"monospace", marginBottom:8 }}>
                    Lon: {Math.abs(water.lng).toFixed(4)}°W
                  </div>
                  <div style={{ fontSize:11, color:"rgba(255,255,255,0.3)", lineHeight:1.5 }}>
                    Save these coordinates in your offline GPS before leaving home
                  </div>
                </div>
              </div>
            );
          })()}
          {tab==="launch"&&(
            <div>
              <div style={{ background:`${dest.color}12`, border:`1px solid ${dest.color}44`, borderRadius:18, padding:18, marginBottom:14 }}>
                <div style={{ fontSize:10, color:dest.color, textTransform:"uppercase", letterSpacing:0.8, fontWeight:700, marginBottom:10 }}>📍 Launch Point</div>
                <div style={{ fontSize:13, color:"#fff", lineHeight:1.65, marginBottom:10 }}>{dest.launch}</div>
                <div style={{ fontSize:12, color:"#fcd34d", fontWeight:600 }}>{dest.launchType}</div>
              </div>
              <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:18, padding:18, marginBottom:14 }}>
                <div style={{ fontSize:10, color:"rgba(255,255,255,0.35)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:14 }}>📦 Gear Checklist</div>
                {[["Full tank — calculate round trip mileage first","🟢"],["Offline GPS maps downloaded before leaving home","🟢"],["Handheld VHF radio (required for remote/Gulf trips)","🔴"],["Dry bag: phone, ID, cash, registration","🟢"],["First aid kit","🟢"],["Anchor + rope for island stops","🟢"],["2L+ water per person, heavy SPF, hat","🟡"],["Float plan left with someone onshore","🔴"]].map(([item,dot],i)=>(
                  <div key={i} style={{ display:"flex", gap:8, alignItems:"flex-start", marginBottom:10 }}>
                    <span style={{ fontSize:14, flexShrink:0 }}>{dot}</span>
                    <span style={{ fontSize:12, color:"rgba(255,255,255,0.6)", lineHeight:1.55 }}>{item}</span>
                  </div>
                ))}
              </div>
              <div style={{ background:"rgba(14,165,233,0.08)", border:"1px solid rgba(14,165,233,0.2)", borderRadius:18, padding:18 }}>
                <div style={{ fontSize:10, color:"#38bdf8", textTransform:"uppercase", letterSpacing:0.8, fontWeight:700, marginBottom:10 }}>🔗 Useful Links</div>
                {[["NOAA Marine Forecast","https://www.weather.gov/mob/"],["Navionics Charts","https://www.navionics.com"],["LDWF Regulations","https://www.wlf.louisiana.gov"],["Coast Guard Boating Safety","https://www.uscgboating.org"]].map(([lbl,url])=>(
                  <a key={lbl} href={url} target="_blank" rel="noopener noreferrer" style={{ display:"flex", alignItems:"center", gap:8, color:"#38bdf8", fontSize:13, marginBottom:8, textDecoration:"none" }}>
                    <span style={{ fontSize:10, opacity:0.6 }}>→</span>{lbl}
                  </a>
                ))}
              </div>
            </div>
          )}
          {tab==="safety"&&(
            <div>
              <div style={{ background:"#3b0000", border:"1.5px solid #dc262677", borderRadius:16, padding:"14px 16px", marginBottom:16, display:"flex", gap:12, alignItems:"center" }}>
                <span style={{ fontSize:24 }}>🚨</span>
                <div><div style={{ fontSize:13, color:"#f87171", fontWeight:700 }}>Safety Disclaimers</div><div style={{ fontSize:11, color:"rgba(255,255,255,0.4)", marginTop:2 }}>Read all of these before your trip</div></div>
              </div>
              {dest.disclaimers.map((d,i)=>(
                <div key={i} style={{ display:"flex", gap:10, alignItems:"flex-start", background:d.startsWith("🚨")?"#3b0000":"rgba(255,255,255,0.03)", border:`1px solid ${d.startsWith("🚨")?"#dc262655":"rgba(255,255,255,0.07)"}`, borderLeft:`3px solid ${d.startsWith("🚨")?"#ef4444":"#f9731666"}`, borderRadius:12, padding:"12px 14px", marginBottom:8 }}>
                  <span style={{ color:d.startsWith("🚨")?"#ef4444":"#fb923c", fontSize:14, flexShrink:0 }}>!</span>
                  <span style={{ fontSize:13, color:"rgba(255,255,255,0.65)", lineHeight:1.6 }}>{d}</span>
                </div>
              ))}
              <button onClick={()=>{onDone(dest.id);onClose();}} style={{ width:"100%", marginTop:20, padding:16, background:done?"#052e16":"#3b0000", border:`2px solid ${done?"#16a34a":"#dc2626"}`, borderRadius:18, color:done?"#4ade80":"#f87171", fontSize:14, fontWeight:700, letterSpacing:1, cursor:"pointer", textTransform:"uppercase", transition:"all 0.2s" }}>
                {done?"✅ Trip Complete!":"Mark as Complete"}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── LEAVE BY CALCULATOR ────────────────────────────────────

const DRIVE_MINS = {
  1:35, 2:30, 3:40, 4:50, 5:55, 6:60, 7:70, 8:70,
  9:25, 10:90, 11:90, 12:120, 13:120, 14:90, 15:105,
};

const SEASONAL_SUNSETS = {
  1:[17,15], 2:[17,45], 3:[18,15], 4:[19,45], 5:[20,10],
  6:[20,25], 7:[20,20], 8:[19,50], 9:[19,0], 10:[18,10],
  11:[17,15], 12:[17,0],
};

function addMins(date, mins) {
  return new Date(date.getTime() + mins * 60000);
}

function fmtTime(date) {
  if (!date || isNaN(date.getTime())) return "—";
  return date.toLocaleTimeString("en-US", { hour:"numeric", minute:"2-digit", hour12:true });
}

function fmtDuration(mins) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return h > 0 ? (m > 0 ? h+"h "+m+"m" : h+"h") : m+"m";
}

function LeaveByScreen({ destinations }) {
  const [dest, setDest] = useState(destinations[0]);
  const [waterHours, setWaterHours] = useState(4);
  const [rampMins, setRampMins] = useState(15);
  const [sunsetInput, setSunsetInput] = useState(""); // user types actual sunset e.g. "19:48"
  const [currentTime, setCurrentTime] = useState(new Date());

  // Live clock — updates every second
  useEffect(() => {
    const t = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const now = currentTime;
  const driveMins = DRIVE_MINS[dest?.id] || 60;
  const waterMins = Math.round(waterHours * 60);
  const returnBuffer = dest?.level === "advanced" ? 45 : dest?.level === "moderate" ? 30 : 20;
  const trailerLoad = 20;

  // Parse user-entered sunset time — they type "19:48" or "7:48 PM" style
  function parseSunsetInput(str) {
    if (!str) return null;
    const clean = str.trim();
    // Handle HH:MM format
    const match = clean.match(/^(\d{1,2}):(\d{2})$/);
    if (match) {
      const h = parseInt(match[1]);
      const m = parseInt(match[2]);
      if (h >= 0 && h <= 23 && m >= 0 && m <= 59) {
        const d = new Date(); d.setHours(h, m, 0, 0); return d;
      }
    }
    return null;
  }

  const sunsetFromInput = parseSunsetInput(sunsetInput);
  // Fall back to seasonal estimate if no valid input
  const monthNum = now.getMonth() + 1;
  const [defH, defM] = SEASONAL_SUNSETS[monthNum];
  const sunset = sunsetFromInput || (() => { const d = new Date(); d.setHours(defH, defM, 0, 0); return d; })();
  const usingEstimate = !sunsetFromInput;

  const offWater   = addMins(sunset, -15);
  const startRtn   = addMins(offWater, -returnBuffer);
  const startRide  = addMins(startRtn, -waterMins);
  const arriveRamp = addMins(startRide, -rampMins);
  const leaveHome  = addMins(arriveRamp, -driveMins);
  const wakeUp     = addMins(leaveHome, -60);
  const homeBy     = addMins(offWater, trailerLoad + driveMins);

  const isLate = leaveHome < now;
  const minsUntilLeave = Math.round((leaveHome - now) / 60000);
  const maxWaterMins = Math.max(0, (offWater - now) / 60000 - driveMins - rampMins - returnBuffer);
  const maxWaterHours = Math.floor(maxWaterMins / 30) / 2;

  // Time remaining until off-water hard stop
  const minsUntilOffWater = Math.round((offWater - now) / 60000);

  const timeline = [
    { time: wakeUp,     label: "⏰ Wake Up",              color: "#a78bfa" },
    { time: leaveHome,  label: "🚗 Leave Abita Springs",  color: "#38bdf8" },
    { time: arriveRamp, label: "🅿️ Arrive Ramp",          color: "#22d3ee" },
    { time: startRide,  label: "🚤 Launch",               color: dest?.color || "#00e5a0" },
    { time: startRtn,   label: "↩️ Start Return",          color: "#fbbf24" },
    { time: offWater,   label: "🛑 Off Water — Hard Stop", color: "#f87171" },
    { time: homeBy,     label: "🏠 Home By",              color: "#4ade80" },
  ];

  const monthNames = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

  return (
    <div style={{ padding:"0 16px 100px" }}>
      {/* Destination */}
      <div style={{ marginBottom:14 }}>
        <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:1, marginBottom:8 }}>🏝️ Destination</div>
        <div style={{ display:"flex", gap:8, overflowX:"auto", paddingBottom:4, WebkitOverflowScrolling:"touch" }}>
          {destinations.map(d=>(
            <button key={d.id} onClick={()=>setDest(d)} style={{ flexShrink:0, padding:"8px 14px", borderRadius:16, border:`1.5px solid ${dest?.id===d.id?d.color+"88":"rgba(255,255,255,0.08)"}`, background:dest?.id===d.id?d.color+"18":"rgba(255,255,255,0.04)", color:dest?.id===d.id?d.color:"rgba(255,255,255,0.4)", fontSize:12, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap", transition:"all 0.15s" }}>{d.emoji} {d.name.split(" ")[0]}</button>
          ))}
        </div>
      </div>


      {/* Live clock */}
      <div style={{ background:"linear-gradient(135deg,rgba(56,189,248,0.1),rgba(14,165,233,0.05))", border:"1px solid rgba(56,189,248,0.2)", borderRadius:16, padding:"14px 18px", marginBottom:14, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <div>
          <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:4 }}>📱 Current Time</div>
          <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:28, color:"#38bdf8", letterSpacing:1 }}>
            {now.toLocaleTimeString("en-US", { hour:"numeric", minute:"2-digit", second:"2-digit", hour12:true })}
          </div>
        </div>
        <div style={{ textAlign:"right" }}>
          <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", marginBottom:4 }}>Hard stop in</div>
          <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:20, color: minsUntilOffWater < 60 ? "#f87171" : minsUntilOffWater < 120 ? "#fbbf24" : "#4ade80" }}>
            {minsUntilOffWater <= 0 ? "PASSED" : minsUntilOffWater >= 60 ? `${Math.floor(minsUntilOffWater/60)}h ${minsUntilOffWater%60}m` : `${minsUntilOffWater}m`}
          </div>
          <div style={{ fontSize:9, color:"rgba(255,255,255,0.25)", marginTop:2 }}>until off-water deadline</div>
        </div>
      </div>

      {/* Sunset time input */}
      <div style={{ background:"rgba(255,255,255,0.04)", border:`1px solid ${sunsetFromInput?"rgba(251,146,60,0.4)":"rgba(255,255,255,0.08)"}`, borderRadius:16, padding:"14px 16px", marginBottom:14 }}>
        <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:10 }}>
          🌇 Today's Sunset Time
        </div>
        <div style={{ display:"flex", gap:10, alignItems:"center" }}>
          <input
            type="time"
            value={sunsetInput}
            onChange={e => setSunsetInput(e.target.value)}
            placeholder="e.g. 19:48"
            style={{ flex:1, background:"rgba(255,255,255,0.06)", border:`1.5px solid ${sunsetFromInput?"#fb923c":"rgba(255,255,255,0.15)"}`, borderRadius:12, padding:"12px 14px", color:"#fff", fontSize:16, outline:"none", fontFamily:"'Barlow',sans-serif" }}
          />
          {sunsetInput && (
            <button onClick={()=>setSunsetInput("")} style={{ padding:"12px 14px", borderRadius:12, border:"none", background:"rgba(255,255,255,0.07)", color:"rgba(255,255,255,0.4)", fontSize:12, cursor:"pointer" }}>Clear</button>
          )}
        </div>
        <div style={{ marginTop:8, fontSize:11, lineHeight:1.5 }}>
          {sunsetFromInput ? (
            <span style={{ color:"#fb923c" }}>✓ Using {fmtTime(sunset)} — check NOAA or your weather app for today's exact sunset</span>
          ) : (
            <span style={{ color:"rgba(255,255,255,0.3)" }}>
              Using seasonal estimate: <strong style={{ color:"rgba(255,255,255,0.5)" }}>{fmtTime(sunset)}</strong> for {monthNames[monthNum-1]}. Enter today's actual sunset above for precision.
            </span>
          )}
        </div>
      </div>

      {/* Sliders */}
      <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:18, padding:"16px", marginBottom:14 }}>
        {[
          { label:"⏱ Hours on Water", val:waterHours, setVal:setWaterHours, min:0.5, max:10, step:0.5, color:dest?.color||"#00e5a0", fmt:v=>v+"h" },
          { label:"🚤 Ramp Setup Time", val:rampMins, setVal:setRampMins, min:10, max:45, step:5, color:"#22d3ee", fmt:v=>v+"m" },
        ].map(s=>(
          <div key={s.label} style={{ marginBottom:16 }}>
            <div style={{ display:"flex", justifyContent:"space-between", marginBottom:8 }}>
              <span style={{ fontSize:12, color:"rgba(255,255,255,0.5)" }}>{s.label}</span>
              <span style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:20, color:s.color }}>{s.fmt(s.val)}</span>
            </div>
            <input type="range" min={s.min} max={s.max} step={s.step} value={s.val}
              onChange={e=>s.setVal(s.step<1?parseFloat(e.target.value):parseInt(e.target.value))}
              style={{ width:"100%", accentColor:s.color }}/>
            <div style={{ display:"flex", justifyContent:"space-between", marginTop:3 }}>
              <span style={{ fontSize:9, color:"rgba(255,255,255,0.2)" }}>{s.min}{s.fmt(s.min).replace(/[\d.]+/,"")}</span>
              {s.label.includes("Water") && maxWaterHours > 0 && maxWaterHours < 10 && (
                <span style={{ fontSize:9, color:"#fbbf24" }}>Max today: {maxWaterHours}h</span>
              )}
              <span style={{ fontSize:9, color:"rgba(255,255,255,0.2)" }}>{s.max}{s.fmt(s.max).replace(/[\d.]+/,"")}</span>
            </div>
          </div>
        ))}
        {/* Leave time countdown */}
        {!isLate && (
          <div style={{ background:"rgba(56,189,248,0.08)", border:"1px solid rgba(56,189,248,0.15)", borderRadius:12, padding:"10px 14px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
            <span style={{ fontSize:12, color:"rgba(255,255,255,0.5)" }}>⏳ Leave in</span>
            <span style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:18, color: minsUntilLeave < 60 ? "#f87171" : minsUntilLeave < 120 ? "#fbbf24" : "#38bdf8" }}>
              {minsUntilLeave <= 0 ? "NOW" : minsUntilLeave >= 60 ? `${Math.floor(minsUntilLeave/60)}h ${minsUntilLeave%60}m` : `${minsUntilLeave}m`}
            </span>
          </div>
        )}
      </div>

      {/* Main result card — always shows, dynamically updates */}
      <div style={{ background:`linear-gradient(135deg,${isLate?"rgba(239,68,68,0.12)":"rgba(56,189,248,0.1)"},rgba(0,0,0,0.15))`, border:`2px solid ${isLate?"rgba(239,68,68,0.45)":(dest?.color||"#38bdf8")+"55"}`, borderRadius:22, padding:"20px", marginBottom:14 }}>
        {isLate ? (
          <div style={{ textAlign:"center" }}>
            <div style={{ fontSize:32, marginBottom:8 }}>⛔</div>
            <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:22, color:"#f87171", marginBottom:8 }}>Too Late Today for {waterHours}h</div>
            <div style={{ fontSize:12, color:"rgba(255,255,255,0.5)", lineHeight:1.6, marginBottom:12 }}>
              Needed to leave by {fmtTime(leaveHome)}. Sunset is {fmtTime(sunset)}.
              {maxWaterHours > 0 ? ` You can still fit ${maxWaterHours}h today.` : " No riding time remaining today."}
            </div>
            {maxWaterHours >= 0.5 && (
              <button onClick={()=>setWaterHours(maxWaterHours)} style={{ padding:"10px 20px", borderRadius:14, border:"none", background:"rgba(251,191,36,0.2)", color:"#fbbf24", fontSize:12, fontWeight:700, cursor:"pointer" }}>
                Switch to {maxWaterHours}h →
              </button>
            )}
          </div>
        ) : (
          <>
            <div style={{ textAlign:"center", marginBottom:16 }}>
              <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)", textTransform:"uppercase", letterSpacing:1, marginBottom:4 }}>Leave Abita Springs By</div>
              <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:56, color:dest?.color||"#38bdf8", lineHeight:1, letterSpacing:1 }}>
                {fmtTime(leaveHome)}
              </div>
              <div style={{ fontSize:12, color:"rgba(255,255,255,0.4)", marginTop:6 }}>
                {waterHours}h riding · Sunset {fmtTime(sunset)} · Off water by {fmtTime(offWater)}
              </div>
            </div>
            <div style={{ background:"rgba(239,68,68,0.1)", border:"1px solid rgba(239,68,68,0.2)", borderRadius:12, padding:"9px 14px", marginBottom:16, display:"flex", gap:8, alignItems:"center" }}>
              <span>⚖️</span>
              <span style={{ fontSize:11, color:"#f87171" }}>LA law: PWC must be off water by sunset. Hard stop {fmtTime(offWater)}.</span>
            </div>
            <div style={{ display:"flex", flexDirection:"column" }}>
              {timeline.map((item,i)=>(
                <div key={i} style={{ display:"flex", alignItems:"center", gap:12 }}>
                  <div style={{ display:"flex", flexDirection:"column", alignItems:"center", width:28 }}>
                    <div style={{ width:11, height:11, borderRadius:"50%", background:item.color, boxShadow:`0 0 8px ${item.color}88` }}/>
                    {i<timeline.length-1&&<div style={{ width:2, height:26, background:"rgba(255,255,255,0.07)", margin:"2px 0" }}/>}
                  </div>
                  <div style={{ flex:1, paddingBottom:i<timeline.length-1?8:0, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                    <span style={{ fontSize:12, color:"rgba(255,255,255,0.55)" }}>{item.label}</span>
                    <span style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:16, color:item.color }}>{fmtTime(item.time)}</span>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Stats grid */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:14 }}>
        {[
          { label:"Drive Each Way", val:fmtDuration(driveMins),    color:"#38bdf8", icon:"🚗" },
          { label:"Ramp Setup",     val:fmtDuration(rampMins),     color:"#22d3ee", icon:"🚤" },
          { label:"Ride Time",      val:fmtDuration(waterMins),    color:dest?.color||"#00e5a0", icon:"🏄" },
          { label:"Return Buffer",  val:fmtDuration(returnBuffer), color:"#fbbf24", icon:"↩️" },
          { label:"Total Day",      val:fmtDuration(driveMins*2+rampMins+waterMins+returnBuffer+trailerLoad), color:"#a78bfa", icon:"⏱" },
          { label:"Sunset",         val:fmtTime(sunset),           color:"#fb923c", icon:"🌇" },
        ].map(s=>(
          <div key={s.label} style={{ background:"rgba(255,255,255,0.04)", border:`1px solid ${s.color}22`, borderRadius:14, padding:"12px 14px" }}>
            <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.5, marginBottom:6 }}>{s.icon} {s.label}</div>
            <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:18, color:s.color }}>{s.val}</div>
          </div>
        ))}
      </div>

    </div>
  );
}



// ─── SEASONAL ALERTS DATA ───────────────────────────────────
const SEASONAL_DATA = {
  1:  { label:"Jan", bugs:1, jellyfish:0, gators:1, redtide:0, fishing:3, notes:"Cool and calm — excellent visibility, low crowds, great gator sightings. Wear layers." },
  2:  { label:"Feb", bugs:1, jellyfish:0, gators:1, redtide:0, fishing:3, notes:"Still cool, great for swamp riding. Occasional fog — use caution on open water." },
  3:  { label:"Mar", bugs:2, jellyfish:0, gators:2, redtide:0, fishing:4, notes:"Spring green-up. Atchafalaya flood season begins — best month for flooded forest riding." },
  4:  { label:"Apr", bugs:3, jellyfish:1, gators:3, redtide:1, fishing:5, notes:"Prime month — warm water, fishing peaks, manageable bugs. Watch afternoon storms." },
  5:  { label:"May", bugs:3, jellyfish:2, gators:4, redtide:1, fishing:5, notes:"Excellent Gulf conditions for offshore crossings. Gators nesting — give wide berth to banks." },
  6:  { label:"Jun", bugs:5, jellyfish:3, gators:5, redtide:2, fishing:4, notes:"Hurricane season starts. Gators most aggressive during nesting. Off open water by noon — storms build fast." },
  7:  { label:"Jul", bugs:5, jellyfish:4, gators:4, redtide:2, fishing:3, notes:"Peak heat. Calm Gulf mornings are excellent but get off water early. Jellyfish heavy in Gulf." },
  8:  { label:"Aug", bugs:5, jellyfish:5, gators:3, redtide:2, fishing:3, notes:"Best month for Ship Island crossing (calm Gulf) but plan return by 12:30pm. Peak jellyfish season." },
  9:  { label:"Sep", bugs:4, jellyfish:3, gators:3, redtide:1, fishing:5, notes:"Redfish peak season — Half Moon Island, Isle Au Pitre at their best. Hurricane risk still high." },
  10: { label:"Oct", bugs:3, jellyfish:2, gators:2, redtide:1, fishing:5, notes:"Best all-around month of the year. Cooler temps, great fishing, manageable bugs, lower hurricane risk." },
  11: { label:"Nov", bugs:2, jellyfish:1, gators:1, redtide:0, fishing:4, notes:"Waterfowl migration peaks — Lake Borgne and Big Branch are spectacular. Cold fronts arrive — watch weather." },
  12: { label:"Dec", bugs:1, jellyfish:0, gators:1, redtide:0, fishing:3, notes:"Short days — plan early and use Leave By calculator. Beautiful clear winter riding. Dress warm." },
};

const ALERT_CATEGORIES = [
  { key:"bugs",      label:"Bug Intensity",   icon:"🦟", low:"Low",  high:"Extreme",  colors:["#4ade80","#86efac","#fbbf24","#fb923c","#ef4444"] },
  { key:"jellyfish", label:"Jellyfish",        icon:"🪼", low:"None", high:"Heavy",    colors:["#4ade80","#86efac","#fbbf24","#fb923c","#ef4444"] },
  { key:"gators",    label:"Gator Activity",   icon:"🐊", low:"Low",  high:"Nesting",  colors:["#4ade80","#86efac","#fbbf24","#fb923c","#ef4444"] },
  { key:"redtide",   label:"Red Tide Risk",    icon:"🌊", low:"None", high:"High",     colors:["#4ade80","#fbbf24","#fb923c","#ef4444","#ef4444"] },
  { key:"fishing",   label:"Fishing Quality",  icon:"🎣", low:"Poor", high:"Prime",    colors:["#ef4444","#fb923c","#fbbf24","#86efac","#4ade80"] },
];

const DEST_SEASONAL = {
  1:  [null,null,null,null,null,null,null,null,null,null,null,null], // all months generic
  // Per-destination overrides can go here
};

function SeasonalScreen({ destinations }) {
  const now = new Date();
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [dest, setDest] = useState(null); // null = global view

  const data = SEASONAL_DATA[month];
  const monthNames = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  const fullMonthNames = ["January","February","March","April","May","June","July","August","September","October","November","December"];

  // Which destinations are recommended this month
  const goodThisMonth = destinations.filter(d => {
    const bugOk = data.bugs <= 3;
    const fishGood = data.fishing >= 4;
    const stormLow = month < 6 || month > 9;
    return d.month === fullMonthNames[month-1] || (bugOk && fishGood) || stormLow;
  });

  function AlertBar({ value, max=5, colors }) {
    return (
      <div style={{ display:"flex", gap:3, flex:1 }}>
        {Array.from({length:max}).map((_,i)=>(
          <div key={i} style={{ flex:1, height:8, borderRadius:3,
            background: i < value ? colors[Math.min(value-1, colors.length-1)] : "rgba(255,255,255,0.08)",
            boxShadow: i < value ? `0 0 6px ${colors[Math.min(value-1,colors.length-1)]}88` : "none",
            transition:"all 0.2s"
          }}/>
        ))}
      </div>
    );
  }

  // Hurricane season warning
  const hurricaneSeason = month >= 6 && month <= 11;
  const peakHurricane = month >= 8 && month <= 10;

  return (
    <div style={{ padding:"0 16px 100px" }}>
      {/* Month selector */}
      <div style={{ marginBottom:14 }}>
        <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:1, marginBottom:8 }}>📅 Select Month</div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(6,1fr)", gap:6 }}>
          {monthNames.map((m,i)=>{
            const mn = i+1;
            const d = SEASONAL_DATA[mn];
            const isNow = mn === now.getMonth()+1;
            const isSel = mn === month;
            // Color code by overall conditions
            const overallScore = (6-d.bugs) + (6-d.jellyfish) + (6-d.gators) + d.fishing;
            const bg = overallScore >= 18 ? "#4ade80" : overallScore >= 14 ? "#fbbf24" : "#f87171";
            return (
              <button key={m} onClick={()=>setMonth(mn)} style={{
                padding:"8px 4px", borderRadius:12, border:`1.5px solid ${isSel?bg+"99":"rgba(255,255,255,0.08)"}`,
                background: isSel ? `${bg}22` : "rgba(255,255,255,0.04)",
                color: isSel ? bg : "rgba(255,255,255,0.4)",
                fontSize:11, fontWeight:700, cursor:"pointer", position:"relative",
                transition:"all 0.15s"
              }}>
                {m}
                {isNow && <div style={{ position:"absolute", top:3, right:3, width:5, height:5, borderRadius:"50%", background:"#38bdf8" }}/>}
              </button>
            );
          })}
        </div>
        <div style={{ fontSize:10, color:"rgba(255,255,255,0.2)", marginTop:6, textAlign:"right" }}>🔵 = current month</div>
      </div>

      {/* Month hero */}
      <div style={{ background:"linear-gradient(135deg,rgba(255,255,255,0.06),rgba(255,255,255,0.02))", border:"1px solid rgba(255,255,255,0.08)", borderRadius:20, padding:"18px 18px", marginBottom:14 }}>
        <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:28, color:"#fff", marginBottom:6 }}>{fullMonthNames[month-1]}</div>
        <div style={{ fontSize:13, color:"rgba(255,255,255,0.6)", lineHeight:1.65 }}>{data.notes}</div>
      </div>

      {/* Hurricane warning */}
      {hurricaneSeason && (
        <div style={{ background: peakHurricane?"#3b0000":"#3b1d00", border:`1.5px solid ${peakHurricane?"#dc262677":"#d9770677"}`, borderRadius:16, padding:"12px 16px", marginBottom:14, display:"flex", gap:10, alignItems:"flex-start" }}>
          <span style={{ fontSize:20 }}>🌀</span>
          <div>
            <div style={{ fontSize:13, color:peakHurricane?"#f87171":"#fcd34d", fontWeight:700, marginBottom:3 }}>
              {peakHurricane?"⚠️ Peak Hurricane Season":"Hurricane Season Active"}
            </div>
            <div style={{ fontSize:12, color:"rgba(255,255,255,0.5)", lineHeight:1.5 }}>
              {peakHurricane
                ? "August–October is peak season. Check NHC.NOAA.gov before every trip. Have an evacuation plan."
                : "Atlantic hurricane season June–November. Monitor forecasts closely. Cancel trips if any tropical systems are active."}
            </div>
            <a href="https://www.nhc.noaa.gov" target="_blank" rel="noopener noreferrer"
              style={{ display:"inline-block", marginTop:6, fontSize:11, color:"#38bdf8" }}>
              → NHC Live Tropical Outlook
            </a>
          </div>
        </div>
      )}

      {/* Alert bars */}
      <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:18, padding:"16px", marginBottom:14 }}>
        <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:14 }}>🌡️ Conditions This Month</div>
        {ALERT_CATEGORIES.map(cat=>{
          const val = data[cat.key];
          const color = cat.colors[Math.min(val-1, cat.colors.length-1)] || "#4ade80";
          const label = val === 0 ? cat.low : val >= 5 ? cat.high : val <= 2 ? "Low–Moderate" : val === 3 ? "Moderate" : "High";
          return (
            <div key={cat.key} style={{ marginBottom:14 }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:6 }}>
                <div style={{ display:"flex", gap:8, alignItems:"center" }}>
                  <span style={{ fontSize:16 }}>{cat.icon}</span>
                  <span style={{ fontSize:12, color:"rgba(255,255,255,0.6)" }}>{cat.label}</span>
                </div>
                <span style={{ fontSize:12, fontWeight:700, color: val===0?"#4ade80":color }}>{label}</span>
              </div>
              <AlertBar value={val} colors={cat.colors}/>
            </div>
          );
        })}
      </div>

      {/* Best destinations this month */}
      <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:18, padding:"16px", marginBottom:14 }}>
        <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:12 }}>⭐ Recommended Trips This Month</div>
        {destinations.filter(d=>d.month===fullMonthNames[month-1]).map(d=>(
          <div key={d.id} style={{ display:"flex", gap:10, alignItems:"center", background:`${d.color}0f`, border:`1px solid ${d.color}33`, borderRadius:12, padding:"10px 12px", marginBottom:8 }}>
            <span style={{ fontSize:20 }}>{d.emoji}</span>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:13, color:"#fff", fontWeight:600 }}>{d.name}</div>
              <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)" }}>{d.subtitle} · {d.drive} drive</div>
            </div>
            <span style={{ fontSize:10, fontWeight:700, padding:"3px 8px", borderRadius:12, background:`${d.color}22`, color:d.color }}>PLANNED</span>
          </div>
        ))}
        {destinations.filter(d=>d.month===fullMonthNames[month-1]).length === 0 && (
          <div style={{ fontSize:12, color:"rgba(255,255,255,0.35)", textAlign:"center", padding:"8px 0" }}>No scheduled trips this month — check the Trips tab to plan one</div>
        )}
      </div>

      {/* Monthly tips */}
      <div style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:16, padding:"14px 16px" }}>
        <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:10 }}>💡 Tips for {fullMonthNames[month-1]}</div>
        {[
          data.bugs >= 4 ? "🦟 Heavy bug season — 100% DEET and permethrin-treated clothing mandatory" : data.bugs >= 3 ? "🦟 Moderate bugs — bring DEET spray" : "🦟 Low bug pressure — minimal repellent needed",
          data.jellyfish >= 4 ? "🪼 Heavy jellyfish in Gulf waters — wear a full wetsuit if swimming" : data.jellyfish >= 2 ? "🪼 Some jellyfish in Gulf — check before swimming" : "🪼 Jellyfish not a concern this month",
          data.gators >= 5 ? "🐊 Gator nesting season — maintain strict 30ft distance from all banks" : data.gators >= 3 ? "🐊 Gators active — do not idle near banks" : "🐊 Gator activity low — normal caution applies",
          data.fishing >= 5 ? "🎣 Prime fishing month — grab your rods" : data.fishing >= 4 ? "🎣 Good fishing conditions" : "🎣 Slower fishing month — focus on riding",
          month >= 6 && month <= 9 ? "⛈️ Summer storm pattern — be off open water by noon, check radar hourly" : null,
          month >= 11 || month <= 2 ? "🧊 Cold weather — dress in layers, wetsuit for winter swamp rides" : null,
        ].filter(Boolean).map((tip,i)=>(
          <div key={i} style={{ fontSize:12, color:"rgba(255,255,255,0.55)", lineHeight:1.6, marginBottom:8, paddingLeft:4, borderLeft:"2px solid rgba(255,255,255,0.08)", paddingTop:2, paddingBottom:2 }}>{tip}</div>
        ))}
      </div>
    </div>
  );
}

// ─── TRIP JOURNAL & SCHEDULER ───────────────────────────────
function JournalScreen({ destinations, done, onDone }) {
  const [journalEntries, setJournalEntries] = useState([]);
  const [scheduled, setScheduled] = useState([]);
  const [view, setView] = useState("upcoming");
  const [editEntry, setEditEntry] = useState(null);
  const [storageReady, setStorageReady] = useState(false);

  // New trip log form state
  const [logDest, setLogDest] = useState(destinations[0]);
  const [logDate, setLogDate] = useState(new Date().toISOString().slice(0,10));
  const [logRating, setLogRating] = useState(5);
  const [logConditions, setLogConditions] = useState("good");
  const [logNotes, setLogNotes] = useState("");
  const [logHighlight, setLogHighlight] = useState("");
  const [logWouldReturn, setLogWouldReturn] = useState(true);

  // Schedule form state
  const [schedDest, setSchedDest] = useState(destinations[0]);
  const [schedDate, setSchedDate] = useState("");
  const [schedTime, setSchedTime] = useState("07:00");
  const [schedRiders, setSchedRiders] = useState(2);
  const [schedNotes, setSchedNotes] = useState("");

  // Load journal and scheduled trips from storage on mount
  useEffect(() => {
    async function load() {
      try {
        const [jRes, sRes] = await Promise.all([
          Promise.resolve((() => { try { const v = localStorage.getItem("pwc_journal_entries"); return v ? {value:v} : null; } catch(e) { return null; } })()),
          Promise.resolve((() => { try { const v = localStorage.getItem("pwc_scheduled_trips"); return v ? {value:v} : null; } catch(e) { return null; } })()),
        ]);
        if (jRes?.value) setJournalEntries(JSON.parse(jRes.value));
        if (sRes?.value) setScheduled(JSON.parse(sRes.value));
      } catch(e) { console.warn("Journal load error:", e); }
      setStorageReady(true);
    }
    load();
  }, []);

  // Save helpers
  async function persistEntries(entries) {
    try { localStorage.setItem("pwc_journal_entries", JSON.stringify(entries)); } catch(e) {}
  }
  async function persistScheduled(trips) {
    try { localStorage.setItem("pwc_scheduled_trips", JSON.stringify(trips)); } catch(e) {}
  }

  function saveLog() {
    if (!logDest || !logDate) return;
    const entry = {
      id: Date.now(),
      destId: logDest.id,
      destName: logDest.name,
      destEmoji: logDest.emoji,
      destColor: logDest.color,
      date: logDate,
      rating: logRating,
      conditions: logConditions,
      notes: logNotes,
      highlight: logHighlight,
      wouldReturn: logWouldReturn,
    };
    const next = [entry, ...journalEntries];
    setJournalEntries(next);
    persistEntries(next);
    onDone(logDest.id);
    setLogNotes(""); setLogHighlight(""); setLogRating(5); setLogConditions("good");
    setView("log");
  }

  function saveSchedule() {
    if (!schedDest || !schedDate) return;
    const entry = {
      id: Date.now(),
      destId: schedDest.id,
      destName: schedDest.name,
      destEmoji: schedDest.emoji,
      destColor: schedDest.color,
      date: schedDate,
      time: schedTime,
      riders: schedRiders,
      notes: schedNotes,
    };
    const next = [...scheduled, entry].sort((a,b)=>a.date.localeCompare(b.date));
    setScheduled(next);
    persistScheduled(next);
    setSchedNotes(""); setSchedRiders(2);
    setView("upcoming");
  }

  function deleteSchedule(id) {
    const next = scheduled.filter(s=>s.id!==id);
    setScheduled(next);
    persistScheduled(next);
  }

  function deleteLog(id) {
    const next = journalEntries.filter(e=>e.id!==id);
    setJournalEntries(next);
    persistEntries(next);
  }

  const upcoming = scheduled.filter(s => s.date >= new Date().toISOString().slice(0,10));
  const past = scheduled.filter(s => s.date < new Date().toISOString().slice(0,10));

  const conditionColors = { great:"#4ade80", good:"#86efac", ok:"#fbbf24", rough:"#fb923c", cancelled:"#f87171" };
  const conditionLabels = { great:"🟢 Great", good:"🟢 Good", ok:"🟡 OK", rough:"🟠 Rough", cancelled:"🔴 Cancelled" };

  if (!storageReady) return (
    <div style={{ padding:"60px 20px", textAlign:"center" }}>
      <div style={{ fontSize:24, marginBottom:8, animation:"pulse 1.5s infinite" }}>📓</div>
      <div style={{ fontSize:12, color:"rgba(255,255,255,0.3)" }}>Loading your journal...</div>
    </div>
  );

  const DestPicker = ({ value, onChange }) => (
    <div style={{ display:"flex", gap:6, overflowX:"auto", paddingBottom:4 }}>
      {destinations.map(d=>(
        <button key={d.id} onClick={()=>onChange(d)} style={{
          flexShrink:0, padding:"7px 12px", borderRadius:14,
          border:`1.5px solid ${value?.id===d.id?d.color+"88":"rgba(255,255,255,0.08)"}`,
          background:value?.id===d.id?`${d.color}18`:"rgba(255,255,255,0.04)",
          color:value?.id===d.id?d.color:"rgba(255,255,255,0.4)",
          fontSize:11, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap", transition:"all 0.15s"
        }}>{d.emoji} {d.name.split(" ")[0]}</button>
      ))}
    </div>
  );

  return (
    <div style={{ padding:"0 16px 100px" }}>
      {/* Sub-nav */}
      <div style={{ display:"flex", gap:6, marginBottom:16 }}>
        {[["upcoming","📅 Upcoming"],["log","📓 Trip Log"],["new","✏️ Log Trip"],["newSchedule","➕ Schedule"]].map(([v,l])=>(
          <button key={v} onClick={()=>setView(v)} style={{
            flex:1, padding:"9px 4px", borderRadius:14, border:"none", cursor:"pointer",
            fontSize:10, fontWeight:700, textTransform:"uppercase", letterSpacing:0.3,
            background:view===v?"rgba(255,255,255,0.12)":"rgba(255,255,255,0.04)",
            color:view===v?"#fff":"rgba(255,255,255,0.35)",
            borderBottom:view===v?"2px solid #38bdf8":"2px solid transparent",
            transition:"all 0.15s"
          }}>{l}</button>
        ))}
      </div>

      {/* ── UPCOMING TRIPS ── */}
      {view==="upcoming" && (
        <div>
          {upcoming.length === 0 && (
            <div style={{ textAlign:"center", padding:"40px 20px" }}>
              <div style={{ fontSize:40, marginBottom:12 }}>📅</div>
              <div style={{ fontSize:14, color:"rgba(255,255,255,0.4)", marginBottom:16 }}>No trips scheduled yet</div>
              <button onClick={()=>setView("newSchedule")} style={{ padding:"12px 24px", borderRadius:16, border:"none", background:"#38bdf8", color:"#060c14", fontSize:13, fontWeight:700, cursor:"pointer" }}>
                + Schedule Your First Trip
              </button>
            </div>
          )}
          {upcoming.map(s=>{
            const d = destinations.find(x=>x.id===s.destId);
            const tripDate = new Date(s.date+"T12:00:00");
            const daysAway = Math.ceil((tripDate - new Date()) / 86400000);
            return (
              <div key={s.id} style={{ background:`${s.destColor}12`, border:`1.5px solid ${s.destColor}44`, borderRadius:20, padding:"16px", marginBottom:12, position:"relative" }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:10 }}>
                  <div style={{ display:"flex", gap:10, alignItems:"center" }}>
                    <div style={{ width:46, height:46, borderRadius:14, background:`${s.destColor}22`, border:`1.5px solid ${s.destColor}55`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:22 }}>{s.destEmoji}</div>
                    <div>
                      <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:17, color:"#fff" }}>{s.destName}</div>
                      <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)" }}>
                        {new Date(s.date+"T12:00:00").toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric"})} at {s.time} · {s.riders} rider{s.riders>1?"s":""}
                      </div>
                    </div>
                  </div>
                  <div style={{ textAlign:"right" }}>
                    <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:22, color:daysAway<=3?"#f87171":daysAway<=7?"#fbbf24":s.destColor }}>
                      {daysAway === 0 ? "TODAY" : daysAway === 1 ? "TOMORROW" : `${daysAway}d`}
                    </div>
                  </div>
                </div>
                {s.notes && <div style={{ fontSize:12, color:"rgba(255,255,255,0.5)", marginBottom:10, lineHeight:1.5 }}>{s.notes}</div>}
                <div style={{ display:"flex", gap:8 }}>
                  <button onClick={()=>deleteSchedule(s.id)} style={{ flex:1, padding:"8px", borderRadius:10, border:"1px solid rgba(239,68,68,0.3)", background:"rgba(239,68,68,0.08)", color:"#f87171", fontSize:11, fontWeight:700, cursor:"pointer" }}>Remove</button>
                  <button onClick={()=>{setLogDest(d||destinations[0]);setLogDate(s.date);setView("new");}} style={{ flex:2, padding:"8px", borderRadius:10, border:`1px solid ${s.destColor}44`, background:`${s.destColor}15`, color:s.destColor, fontSize:11, fontWeight:700, cursor:"pointer" }}>✏️ Log This Trip</button>
                </div>
              </div>
            );
          })}
          {past.length > 0 && (
            <div style={{ marginTop:16 }}>
              <div style={{ fontSize:10, color:"rgba(255,255,255,0.25)", textTransform:"uppercase", letterSpacing:1, marginBottom:8 }}>Past Scheduled</div>
              {past.map(s=>(
                <div key={s.id} style={{ display:"flex", gap:10, alignItems:"center", background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.06)", borderRadius:14, padding:"12px 14px", marginBottom:8, opacity:0.6 }}>
                  <span style={{ fontSize:20 }}>{s.destEmoji}</span>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:12, color:"rgba(255,255,255,0.5)" }}>{s.destName}</div>
                    <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)" }}>{new Date(s.date+"T12:00:00").toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})}</div>
                  </div>
                  <button onClick={()=>deleteSchedule(s.id)} style={{ padding:"4px 8px", borderRadius:8, border:"none", background:"rgba(255,255,255,0.06)", color:"rgba(255,255,255,0.3)", fontSize:10, cursor:"pointer" }}>✕</button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── TRIP LOG ── */}
      {view==="log" && (
        <div>
          {journalEntries.length === 0 && (
            <div style={{ textAlign:"center", padding:"40px 20px" }}>
              <div style={{ fontSize:40, marginBottom:12 }}>📓</div>
              <div style={{ fontSize:14, color:"rgba(255,255,255,0.4)", marginBottom:16 }}>No trips logged yet</div>
              <button onClick={()=>setView("new")} style={{ padding:"12px 24px", borderRadius:16, border:"none", background:"#00e5a0", color:"#060c14", fontSize:13, fontWeight:700, cursor:"pointer" }}>
                + Log Your First Trip
              </button>
            </div>
          )}
          {journalEntries.map(entry=>(
            <div key={entry.id} style={{ background:`${entry.destColor}10`, border:`1.5px solid ${entry.destColor}33`, borderRadius:20, padding:"16px", marginBottom:12 }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:10 }}>
                <div style={{ display:"flex", gap:10, alignItems:"center" }}>
                  <div style={{ width:44, height:44, borderRadius:13, background:`${entry.destColor}22`, border:`1.5px solid ${entry.destColor}55`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:20 }}>{entry.destEmoji}</div>
                  <div>
                    <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:16, color:"#fff" }}>{entry.destName}</div>
                    <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)" }}>{new Date(entry.date+"T12:00:00").toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric",year:"numeric"})}</div>
                  </div>
                </div>
                <button onClick={()=>deleteLog(entry.id)} style={{ width:28, height:28, borderRadius:8, border:"none", background:"rgba(255,255,255,0.06)", color:"rgba(255,255,255,0.3)", fontSize:14, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>✕</button>
              </div>
              {/* Rating stars */}
              <div style={{ display:"flex", gap:3, marginBottom:8 }}>
                {[1,2,3,4,5].map(i=>(
                  <span key={i} style={{ fontSize:16, color:i<=entry.rating?"#fbbf24":"rgba(255,255,255,0.15)" }}>★</span>
                ))}
                <span style={{ fontSize:11, color:conditionColors[entry.conditions]||"#fff", marginLeft:8, fontWeight:700 }}>{conditionLabels[entry.conditions]}</span>
              </div>
              {entry.highlight && (
                <div style={{ background:"rgba(255,255,255,0.05)", borderRadius:10, padding:"8px 12px", marginBottom:8, borderLeft:`3px solid ${entry.destColor}` }}>
                  <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", marginBottom:3 }}>HIGHLIGHT</div>
                  <div style={{ fontSize:13, color:"rgba(255,255,255,0.8)" }}>"{entry.highlight}"</div>
                </div>
              )}
              {entry.notes && <div style={{ fontSize:12, color:"rgba(255,255,255,0.5)", lineHeight:1.55 }}>{entry.notes}</div>}
              <div style={{ marginTop:8, fontSize:11, color:entry.wouldReturn?"#4ade80":"rgba(255,255,255,0.3)" }}>
                {entry.wouldReturn?"✓ Would return":"✗ Wouldn't return"}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── LOG A TRIP ── */}
      {view==="new" && (
        <div>
          <div style={{ fontSize:13, color:"rgba(255,255,255,0.5)", marginBottom:16 }}>Log a completed trip to your journal</div>

          <Field label="Destination">
            <DestPicker value={logDest} onChange={setLogDest}/>
          </Field>

          <Field label="Trip Date">
            <input type="date" value={logDate} onChange={e=>setLogDate(e.target.value)}
              style={{ width:"100%", background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:10, padding:"10px 12px", color:"#fff", fontSize:14, outline:"none", fontFamily:"'Barlow',sans-serif" }}/>
          </Field>

          <Field label="Rating">
            <div style={{ display:"flex", gap:8 }}>
              {[1,2,3,4,5].map(i=>(
                <button key={i} onClick={()=>setLogRating(i)} style={{ flex:1, padding:"10px", borderRadius:12, border:`1.5px solid ${i<=logRating?"#fbbf24":"rgba(255,255,255,0.1)"}`, background:i<=logRating?"rgba(251,191,36,0.15)":"rgba(255,255,255,0.04)", fontSize:18, cursor:"pointer" }}>
                  {i<=logRating?"★":"☆"}
                </button>
              ))}
            </div>
          </Field>

          <Field label="Conditions">
            <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
              {Object.entries(conditionLabels).map(([k,l])=>(
                <button key={k} onClick={()=>setLogConditions(k)} style={{ padding:"8px 14px", borderRadius:20, border:`1.5px solid ${logConditions===k?(conditionColors[k]||"#fff")+"88":"rgba(255,255,255,0.1)"}`, background:logConditions===k?`${conditionColors[k]}22`:"rgba(255,255,255,0.04)", color:logConditions===k?(conditionColors[k]||"#fff"):"rgba(255,255,255,0.4)", fontSize:12, fontWeight:700, cursor:"pointer" }}>{l}</button>
              ))}
            </div>
          </Field>

          <Field label="Best Moment (optional)">
            <textarea value={logHighlight} onChange={e=>setLogHighlight(e.target.value)} placeholder='e.g. "Saw a bald eagle land 20ft away in the Atchafalaya"' rows={2}
              style={{ width:"100%", background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:10, padding:"10px 12px", color:"#fff", fontSize:13, outline:"none", resize:"none", fontFamily:"'Barlow',sans-serif" }}/>
          </Field>

          <Field label="Notes (optional)">
            <textarea value={logNotes} onChange={e=>setLogNotes(e.target.value)} placeholder="Conditions, what you'd do differently, things to remember..." rows={3}
              style={{ width:"100%", background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:10, padding:"10px 12px", color:"#fff", fontSize:13, outline:"none", resize:"none", fontFamily:"'Barlow',sans-serif" }}/>
          </Field>

          <Field label="Would Return?">
            <div style={{ display:"flex", gap:8 }}>
              {[[true,"✓ Yes","#4ade80"],[false,"✗ No","#f87171"]].map(([val,lbl,col])=>(
                <button key={String(val)} onClick={()=>setLogWouldReturn(val)} style={{ flex:1, padding:"10px", borderRadius:12, border:`1.5px solid ${logWouldReturn===val?col+"88":"rgba(255,255,255,0.1)"}`, background:logWouldReturn===val?`${col}18`:"rgba(255,255,255,0.04)", color:logWouldReturn===val?col:"rgba(255,255,255,0.4)", fontSize:13, fontWeight:700, cursor:"pointer" }}>{lbl}</button>
              ))}
            </div>
          </Field>

          <button onClick={saveLog} style={{ width:"100%", marginTop:8, padding:"16px", borderRadius:18, border:"none", background:"linear-gradient(135deg,#00e5a0,#38bdf8)", color:"#060c14", fontSize:14, fontWeight:700, cursor:"pointer", letterSpacing:0.5 }}>
            💾 Save Trip Log
          </button>
        </div>
      )}

      {/* ── SCHEDULE A TRIP ── */}
      {view==="newSchedule" && (
        <div>
          <div style={{ fontSize:13, color:"rgba(255,255,255,0.5)", marginBottom:16 }}>Plan an upcoming trip and add it to your schedule</div>

          <Field label="Destination">
            <DestPicker value={schedDest} onChange={setSchedDest}/>
          </Field>

          <Field label="Trip Date">
            <input type="date" value={schedDate} onChange={e=>setSchedDate(e.target.value)} min={new Date().toISOString().slice(0,10)}
              style={{ width:"100%", background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:10, padding:"10px 12px", color:"#fff", fontSize:14, outline:"none", fontFamily:"'Barlow',sans-serif" }}/>
          </Field>

          <Field label="Launch Time">
            <input type="time" value={schedTime} onChange={e=>setSchedTime(e.target.value)}
              style={{ width:"100%", background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:10, padding:"10px 12px", color:"#fff", fontSize:14, outline:"none", fontFamily:"'Barlow',sans-serif" }}/>
          </Field>

          <Field label={`Riders: ${schedRiders}`}>
            <input type="range" min={1} max={10} value={schedRiders} onChange={e=>setSchedRiders(parseInt(e.target.value))}
              style={{ width:"100%", accentColor:schedDest?.color||"#38bdf8", cursor:"pointer" }}/>
            <div style={{ display:"flex", justifyContent:"space-between", marginTop:4 }}>
              <span style={{ fontSize:9, color:"rgba(255,255,255,0.2)" }}>1</span>
              <span style={{ fontSize:9, color:"rgba(255,255,255,0.2)" }}>10</span>
            </div>
          </Field>

          <Field label="Notes (optional)">
            <textarea value={schedNotes} onChange={e=>setSchedNotes(e.target.value)} placeholder="Who's coming, what to bring, meeting point..." rows={3}
              style={{ width:"100%", background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:10, padding:"10px 12px", color:"#fff", fontSize:13, outline:"none", resize:"none", fontFamily:"'Barlow',sans-serif" }}/>
          </Field>

          {/* Preview */}
          {schedDate && schedDest && (
            <div style={{ background:`${schedDest.color}12`, border:`1px solid ${schedDest.color}33`, borderRadius:16, padding:"14px 16px", marginBottom:14 }}>
              <div style={{ fontSize:10, color:schedDest.color, textTransform:"uppercase", letterSpacing:0.8, fontWeight:700, marginBottom:8 }}>Trip Preview</div>
              <div style={{ fontSize:13, color:"rgba(255,255,255,0.7)", lineHeight:1.6 }}>
                {schedDest.emoji} <strong style={{ color:"#fff" }}>{schedDest.name}</strong><br/>
                📅 {new Date(schedDate+"T12:00:00").toLocaleDateString("en-US",{weekday:"long",month:"long",day:"numeric",year:"numeric"})}<br/>
                🕐 Launch at {schedTime} · {schedRiders} rider{schedRiders>1?"s":""}<br/>
                🚗 Drive: {schedDest.drive} from Abita Springs
              </div>
            </div>
          )}

          <button onClick={saveSchedule} disabled={!schedDate||!schedDest} style={{ width:"100%", padding:"16px", borderRadius:18, border:"none", background:schedDate&&schedDest?"linear-gradient(135deg,#38bdf8,#818cf8)":"rgba(255,255,255,0.08)", color:schedDate&&schedDest?"#060c14":"rgba(255,255,255,0.3)", fontSize:14, fontWeight:700, cursor:schedDate&&schedDest?"pointer":"default", letterSpacing:0.5, transition:"all 0.2s" }}>
            📅 Add to Schedule
          </button>
        </div>
      )}
    </div>
  );
}

// Simple field wrapper for forms
function Field({ label, children }) {
  return (
    <div style={{ marginBottom:16 }}>
      <div style={{ fontSize:10, color:"rgba(255,255,255,0.35)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:8 }}>{label}</div>
      {children}
    </div>
  );
}

// ─── SIGHTINGS DATA ─────────────────────────────────────────
const SIGHTINGS = [
  // WILDLIFE
  { id:"w1",  cat:"Wildlife",    emoji:"🐊", name:"Bull Gator",              desc:"Large male alligator, typically 10ft+. Common in Honey Island, Atchafalaya, Barataria.",       rarity:"common",   dests:[1,2,3,7,8,10,15] },
  { id:"w2",  cat:"Wildlife",    emoji:"🦅", name:"Bald Eagle",              desc:"Often seen perched in dead cypress trees. Atchafalaya Basin is prime eagle territory.",        rarity:"uncommon", dests:[1,3,9,15] },
  { id:"w3",  cat:"Wildlife",    emoji:"🐬", name:"Bottlenose Dolphin",      desc:"Coastal rides — Grand Isle, Ship Island, Cat Island crossings. Often bow-ride boats.",        rarity:"uncommon", dests:[5,7,8,11,12,13,14] },
  { id:"w4",  cat:"Wildlife",    emoji:"🦩", name:"Roseate Spoonbill",       desc:"Hot pink wading bird. Spotted in coastal marsh and Barataria. Unmistakable in flight.",       rarity:"uncommon", dests:[7,8,10,12] },
  { id:"w5",  cat:"Wildlife",    emoji:"🦦", name:"River Otter",             desc:"Playful and fast. Watch near cypress knees and log piles in swamp areas.",                    rarity:"uncommon", dests:[1,2,3,15] },
  { id:"w6",  cat:"Wildlife",    emoji:"🐢", name:"Loggerhead Sea Turtle",   desc:"Gulf crossings — may surface near your ski. Protected species. Do not approach.",            rarity:"rare",     dests:[12,13,14] },
  { id:"w7",  cat:"Wildlife",    emoji:"🐟", name:"Bull Redfish (Slot)",     desc:"30\"+ slot red on a sight-cast. Half Moon Island and Isle Au Pitre are legendary for these.", rarity:"uncommon", dests:[6,7,10,12] },
  { id:"w8",  cat:"Wildlife",    emoji:"🦭", name:"West Indian Manatee",     desc:"Slow-moving, gentle giants occasionally spotted in warm Louisiana coastal waters.",           rarity:"rare",     dests:[5,7,8,12] },
  { id:"w9",  cat:"Wildlife",    emoji:"🐦", name:"Brown Pelican",           desc:"Louisiana's state bird. Flocks dive-bomb schools of fish along the coast.",                   rarity:"common",   dests:[7,8,10,12,13,14] },
  { id:"w10", cat:"Wildlife",    emoji:"🐍", name:"Water Moccasin",          desc:"Thick-bodied cottonmouth on floating debris. Do not approach — highly venomous.",            rarity:"common",   dests:[1,2,3,10,15] },
  { id:"w11", cat:"Wildlife",    emoji:"🦆", name:"Mottled Duck Flock",      desc:"Louisiana's resident duck. Large flocks in marsh areas year-round.",                         rarity:"common",   dests:[7,8,9,10] },
  { id:"w12", cat:"Wildlife",    emoji:"🦈", name:"Bull Shark",              desc:"Gulf waters and even river mouths. Spotted occasionally on offshore crossings.",              rarity:"rare",     dests:[12,13,14] },
  { id:"w13", cat:"Wildlife",    emoji:"🐸", name:"Pig Frog Chorus",         desc:"Deafening pig-like croaking on warm evenings in the Atchafalaya and Manchac.",               rarity:"common",   dests:[1,2,15] },
  { id:"w14", cat:"Wildlife",    emoji:"🦐", name:"Crawfish Boat Fleet",     desc:"Commercial crawfish trappers working the Atchafalaya in spring — give them wide clearance.", rarity:"seasonal", dests:[15] },

  // LANDMARKS & SITES
  { id:"l1",  cat:"Landmarks",   emoji:"🏰", name:"Fort Massachusetts",      desc:"1859 Civil War era fort on Ship Island. Walk through it after the Gulf crossing.",           rarity:"unique",   dests:[13] },
  { id:"l2",  cat:"Landmarks",   emoji:"⚓", name:"Raised Shrimp Trawler",   desc:"Rusted ghost shrimp boats run aground in the marsh — eerie and photogenic.",                rarity:"uncommon", dests:[7,8,10] },
  { id:"l3",  cat:"Landmarks",   emoji:"🛢️", name:"Offshore Platform View",  desc:"Visible on the horizon from Grand Isle and Fourchon — ghost rigs from the oil patch.",      rarity:"common",   dests:[12] },
  { id:"l4",  cat:"Landmarks",   emoji:"🌉", name:"Manchac Swamp Bridge",    desc:"I-55 spans the entire swamp — ride underneath the longest bridge over water in the US.",     rarity:"unique",   dests:[2] },
  { id:"l5",  cat:"Landmarks",   emoji:"🏚️", name:"Katrina Ghost Camps",     desc:"Flooded and abandoned fishing camps from Hurricane Katrina — hauntingly beautiful.",        rarity:"uncommon", dests:[7,8] },
  { id:"l6",  cat:"Landmarks",   emoji:"🌊", name:"Caminada Restoration",    desc:"13 miles of engineered beach — see the restored dune system up close from the Gulf side.",   rarity:"unique",   dests:[12] },
  { id:"l7",  cat:"Landmarks",   emoji:"🪵", name:"Ancient Cypress Snag",    desc:"Massive 500+ year old dead cypress skeleton standing in open water. Atchafalaya Basin.",    rarity:"uncommon", dests:[15] },
  { id:"l8",  cat:"Landmarks",   emoji:"🏠", name:"Floating Fishing Camp",   desc:"Camps built on floating platforms tethered to the marsh. Some have been there 50+ years.",  rarity:"uncommon", dests:[1,10,15] },
  { id:"l9",  cat:"Landmarks",   emoji:"💡", name:"Chandeleur Sound View",   desc:"On a clear day from Isle Au Pitre, you can see the Chandeleur chain on the horizon.",       rarity:"rare",     dests:[7] },
  { id:"l10", cat:"Landmarks",   emoji:"⛽", name:"Henderson Levee Sunset",  desc:"Watching the sun set from the Atchafalaya Basin is one of Louisiana's great sights.",       rarity:"common",   dests:[15] },

  // HISTORICAL
  { id:"h1",  cat:"Historical",  emoji:"🏴‍☠️", name:"Jean Lafitte Territory",  desc:"The Barataria Basin was Lafitte's pirate smuggling hub in the 1800s. You're riding his routes.", rarity:"unique", dests:[10] },
  { id:"h2",  cat:"Historical",  emoji:"🎖️", name:"WWII Sub Net Remains",    desc:"Remnants of submarine nets stretched across the Mississippi Sound near Ship Island.",      rarity:"rare",     dests:[13] },
  { id:"h3",  cat:"Historical",  emoji:"🌿", name:"Honey Island Legend Site", desc:"Site of the famous Honey Island Swamp Monster sightings — reported since the 1960s.",      rarity:"unique",   dests:[1] },
  { id:"h4",  cat:"Historical",  emoji:"🎣", name:"Old Trappers Canal",       desc:"Hand-dug canals from the fur trapping era still navigate the marsh. Now used by fishermen.", rarity:"uncommon", dests:[7,8,10] },
  { id:"h5",  cat:"Historical",  emoji:"🌊", name:"Katrina Flood Line",       desc:"High water marks from Hurricane Katrina still visible on surviving structures.",            rarity:"uncommon", dests:[5,8] },
  { id:"h6",  cat:"Historical",  emoji:"⚓", name:"Spanish Fort Ruins",       desc:"Old Spanish colonial fort ruins near Lake Pontchartrain — visible from the water.",         rarity:"rare",     dests:[5] },
  { id:"h7",  cat:"Historical",  emoji:"🛤️", name:"Atchafalaya Levee System", desc:"The Old River Control Structure — one of the most critical flood control systems on Earth.", rarity:"unique",   dests:[15] },
  { id:"h8",  cat:"Historical",  emoji:"🪵", name:"Old Growth Cypress Stump", desc:"Logging-era stumps from the 1800s–1900s still dot the basin floor. Look in shallow areas.", rarity:"common",  dests:[1,2,15] },

  // NATURAL PHENOMENA
  { id:"n1",  cat:"Phenomena",   emoji:"✨", name:"Bioluminescent Wake",      desc:"Paddle slowly at night in the marsh — your wake may glow with bioluminescent plankton.",   rarity:"rare",     dests:[7,8,12] },
  { id:"n2",  cat:"Phenomena",   emoji:"🌫️", name:"Swamp Fog at Sunrise",    desc:"Ground fog rising off warm water in cool mornings. Manchac and Honey Island are surreal.", rarity:"seasonal", dests:[1,2,3,15] },
  { id:"n3",  cat:"Phenomena",   emoji:"🎨", name:"Cypress Knees Maze",      desc:"Riding slowly through a forest of cypress knees at high water. Atchafalaya spring flood.",  rarity:"seasonal", dests:[15] },
  { id:"n4",  cat:"Phenomena",   emoji:"🌸", name:"Lotus Bloom Field",        desc:"Massive American lotus blooms covering open marsh water in July–August.",                   rarity:"seasonal", dests:[3,10,15] },
  { id:"n5",  cat:"Phenomena",   emoji:"🌅", name:"Gulf Sunrise at Sea",      desc:"Watch the sun rise over open Gulf water during an early crossing to Ship or Cat Island.",   rarity:"uncommon", dests:[13,14] },
  { id:"n6",  cat:"Phenomena",   emoji:"🐦", name:"Murmuration of Blackbirds",desc:"Thousands of red-winged blackbirds moving as one unit over the marsh in fall.",            rarity:"seasonal", dests:[7,8,9,10] },
  { id:"n7",  cat:"Phenomena",   emoji:"⚡", name:"Thunderstorm on the Gulf", desc:"Watching a Gulf storm build from a safe distance on shore is genuinely awe-inspiring.",    rarity:"seasonal", dests:[12,13,14] },
  { id:"n8",  cat:"Phenomena",   emoji:"🌈", name:"Double Rainbow Over Marsh",desc:"After a summer storm — the flat Louisiana marsh gives a full arc view of the rainbow.",    rarity:"uncommon", dests:[7,8,10,15] },
];

// ─── ACHIEVEMENTS DATA ───────────────────────────────────────
const ACHIEVEMENTS = [
  // Trip milestones
  { id:"a1",  emoji:"🚀", name:"First Launch",          desc:"Complete your first trip",                     check:(done,_,sightings)=>done.size>=1 },
  { id:"a2",  emoji:"🏄", name:"Riding Regular",        desc:"Complete 5 trips",                             check:(done)=>done.size>=5 },
  { id:"a3",  emoji:"🗺️", name:"Half the Map",          desc:"Complete 8 trips",                             check:(done)=>done.size>=8 },
  { id:"a4",  emoji:"🏆", name:"Gulf Coast Legend",     desc:"Complete all 15 destinations",                 check:(done)=>done.size>=15 },
  { id:"a5",  emoji:"🟢", name:"Easy Rider",            desc:"Complete all Easy trips",                      check:(done,dests)=>dests.filter(d=>d.level==="easy").every(d=>done.has(d.id)) },
  { id:"a6",  emoji:"🟡", name:"Going Moderate",        desc:"Complete all Moderate trips",                  check:(done,dests)=>dests.filter(d=>d.level==="moderate").every(d=>done.has(d.id)) },
  { id:"a7",  emoji:"🔴", name:"Advanced Rider",        desc:"Complete all Advanced trips",                  check:(done,dests)=>dests.filter(d=>d.level==="advanced").every(d=>done.has(d.id)) },
  // Destination-specific
  { id:"a8",  emoji:"⛵", name:"Gulf Crosser",           desc:"Complete Ship Island — 12 miles offshore",     check:(done)=>done.has(13) },
  { id:"a9",  emoji:"🌲", name:"Swamp King",             desc:"Complete Atchafalaya Basin",                   check:(done)=>done.has(15) },
  { id:"a10", emoji:"🌙", name:"Hidden Gem Hunter",      desc:"Complete Half Moon Island",                    check:(done)=>done.has(6) },
  { id:"a11", emoji:"🗺️", name:"Cartographer",           desc:"Complete Isle Au Pitre",                       check:(done)=>done.has(7) },
  { id:"a12", emoji:"🏖️", name:"Beach Day",              desc:"Complete Grand Isle",                          check:(done)=>done.has(12) },
  // Sightings
  { id:"a13", emoji:"🦅", name:"Eagle Eye",              desc:"Spot a Bald Eagle",                            check:(_,__,s)=>s.has("w2") },
  { id:"a14", emoji:"🐬", name:"Dolphin Rider",          desc:"See dolphins on a Gulf crossing",               check:(_,__,s)=>s.has("w3") },
  { id:"a15", emoji:"🐢", name:"Turtle Watcher",         desc:"Spot a sea turtle",                            check:(_,__,s)=>s.has("w6") },
  { id:"a16", emoji:"🦩", name:"Flamingo Fan",           desc:"Spot a Roseate Spoonbill",                     check:(_,__,s)=>s.has("w4") },
  { id:"a17", emoji:"🦈", name:"Shark Spotter",          desc:"Spot a bull shark",                            check:(_,__,s)=>s.has("w12") },
  { id:"a18", emoji:"✨", name:"Night Glow",             desc:"See bioluminescent wake",                      check:(_,__,s)=>s.has("n1") },
  { id:"a19", emoji:"🏴‍☠️", name:"Pirate Waters",        desc:"Ride the Barataria Basin",                     check:(done)=>done.has(10) },
  { id:"a20", emoji:"🌫️", name:"Ghost Rider",            desc:"Ride through swamp fog at sunrise",             check:(_,__,s)=>s.has("n2") },
  // Combo
  { id:"a21", emoji:"🌊", name:"Coastal Conqueror",      desc:"Complete all Gulf/coastal trips (6 total)",    check:(done)=>([7,8,10,12,13,14].every(id=>done.has(id))) },
  { id:"a22", emoji:"🌿", name:"Swamp Master",           desc:"Complete all swamp/marsh trips (6 total)",     check:(done)=>([1,2,3,9,10,15].every(id=>done.has(id))) },
  { id:"a23", emoji:"🏝️", name:"Island Hopper",          desc:"Complete all island trips (6 total)",          check:(done)=>([4,5,6,11,13,14].every(id=>done.has(id))) },
  { id:"a24", emoji:"📓", name:"Documenter",             desc:"Log 5 trips in your journal",                  check:(_,__,___,journal)=>journal>=5 },
  { id:"a25", emoji:"👁️", name:"Naturalist",             desc:"Check off 10 sightings",                      check:(_,__,s)=>s.size>=10 },
  { id:"a26", emoji:"🌟", name:"Bucket Lister",          desc:"Check off 20 sightings",                      check:(_,__,s)=>s.size>=20 },
];

// ─── ACHIEVEMENTS SCREEN ─────────────────────────────────────
function AchievementsScreen({ done, destinations, sightingsChecked, journalCount, streak, toggleSighting }) {
  const [tab, setTab] = useState("badges");
  const [sightCatFilter, setSightCatFilter] = useState("All");
  const [sightDestFilter, setSightDestFilter] = useState(null); // null = all destinations

  const unlocked = ACHIEVEMENTS.filter(a => a.check(done, destinations, sightingsChecked, journalCount));
  const locked   = ACHIEVEMENTS.filter(a => !a.check(done, destinations, sightingsChecked, journalCount));
  const pct = Math.round((unlocked.length / ACHIEVEMENTS.length) * 100);

  const sightCats = ["All", "Wildlife", "Landmarks", "Historical", "Phenomena"];

  // Filter by both category AND destination
  const filteredSights = SIGHTINGS.filter(s => {
    const catMatch = sightCatFilter === "All" || s.cat === sightCatFilter;
    const destMatch = !sightDestFilter || s.dests.includes(sightDestFilter.id);
    return catMatch && destMatch;
  });

  const rarityConfig = {
    common:   { label:"Common",        color:"#86efac" },
    uncommon: { label:"Uncommon",      color:"#38bdf8" },
    rare:     { label:"Rare",          color:"#a78bfa" },
    seasonal: { label:"Seasonal",      color:"#fbbf24" },
    unique:   { label:"One of a Kind", color:"#f472b6" },
  };

  return (
    <div style={{ padding:"0 16px 100px" }}>
      {/* Stats row */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:10, marginBottom:16 }}>
        {[
          { label:"Badges",  val:`${unlocked.length}/${ACHIEVEMENTS.length}`, color:"#e8c547", icon:"🏅" },
          { label:"Sightings", val:`${sightingsChecked.size}/${SIGHTINGS.length}`, color:"#a78bfa", icon:"👁️" },
          { label:"Streak",  val:`${streak}d`, color:"#f87171", icon:"🔥" },
        ].map(s=>(
          <div key={s.label} style={{ background:"rgba(255,255,255,0.04)", border:`1px solid ${s.color}33`, borderRadius:16, padding:"12px 10px", textAlign:"center" }}>
            <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.6, marginBottom:6 }}>{s.icon} {s.label}</div>
            <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:20, color:s.color }}>{s.val}</div>
          </div>
        ))}
      </div>

      {/* Badge progress bar */}
      <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:16, padding:"14px 16px", marginBottom:14 }}>
        <div style={{ display:"flex", justifyContent:"space-between", marginBottom:8 }}>
          <span style={{ fontSize:12, color:"rgba(255,255,255,0.5)", fontWeight:600 }}>🏅 Badge Progress</span>
          <span style={{ fontSize:12, fontWeight:700, color:"#e8c547" }}>{pct}%</span>
        </div>
        <div style={{ background:"rgba(255,255,255,0.07)", borderRadius:8, height:8, overflow:"hidden" }}>
          <div style={{ height:8, borderRadius:8, width:`${pct}%`, background:"linear-gradient(90deg,#e8c547,#fb923c)", transition:"width 0.5s ease", boxShadow:"0 0 12px #e8c54755" }}/>
        </div>
      </div>

      {/* Streak card */}
      <div style={{ background: streak > 0 ? "linear-gradient(135deg,rgba(248,113,113,0.12),rgba(251,146,60,0.08))" : "rgba(255,255,255,0.03)", border:`1.5px solid ${streak>0?"#f8717144":"rgba(255,255,255,0.07)"}`, borderRadius:18, padding:"16px", marginBottom:14 }}>
        <div style={{ display:"flex", gap:12, alignItems:"center" }}>
          <div style={{ fontSize:40 }}>{streak>=30?"🔥🔥🔥":streak>=14?"🔥🔥":streak>0?"🔥":"💤"}</div>
          <div>
            <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:26, color:streak>0?"#f87171":"rgba(255,255,255,0.3)" }}>
              {streak > 0 ? `${streak} Day Streak` : "No Active Streak"}
            </div>
            <div style={{ fontSize:12, color:"rgba(255,255,255,0.4)", marginTop:2 }}>
              {streak === 0 ? "Log a trip to start your streak" : streak >= 30 ? "Legendary — one month of riding!" : streak >= 14 ? "Two weeks strong 💪" : streak >= 7 ? "One week solid!" : "Keep it going!"}
            </div>
          </div>
        </div>
      </div>

      {/* Sub-tabs */}
      <div style={{ display:"flex", gap:6, marginBottom:14 }}>
        {[["badges","🏅 Badges"],["sightings","👁️ Sightings"]].map(([v,l])=>(
          <button key={v} onClick={()=>setTab(v)} style={{ flex:1, padding:"10px 8px", borderRadius:14, border:"none", cursor:"pointer", fontSize:12, fontWeight:700, background:tab===v?"rgba(255,255,255,0.1)":"rgba(255,255,255,0.04)", color:tab===v?"#fff":"rgba(255,255,255,0.35)", borderBottom:tab===v?"2px solid #e8c547":"2px solid transparent", transition:"all 0.15s" }}>{l}</button>
        ))}
      </div>

      {/* ── BADGES ── */}
      {tab==="badges" && (
        <div>
          {unlocked.length > 0 && (
            <>
              <div style={{ fontSize:10, color:"#4ade80", textTransform:"uppercase", letterSpacing:1, marginBottom:10, fontWeight:700 }}>✓ Unlocked ({unlocked.length})</div>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:20 }}>
                {unlocked.map(a=>(
                  <div key={a.id} style={{ background:"linear-gradient(135deg,rgba(232,197,71,0.15),rgba(232,197,71,0.05))", border:"1.5px solid #e8c54755", borderRadius:18, padding:"16px 12px", textAlign:"center", position:"relative" }}>
                    <div style={{ position:"absolute", top:8, right:8, width:8, height:8, borderRadius:"50%", background:"#4ade80", boxShadow:"0 0 8px #4ade80" }}/>
                    <div style={{ fontSize:32, marginBottom:8 }}>{a.emoji}</div>
                    <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:13, color:"#e8c547", letterSpacing:0.3, marginBottom:4 }}>{a.name}</div>
                    <div style={{ fontSize:10, color:"rgba(255,255,255,0.45)", lineHeight:1.4 }}>{a.desc}</div>
                  </div>
                ))}
              </div>
            </>
          )}
          {locked.length > 0 && (
            <>
              <div style={{ fontSize:10, color:"rgba(255,255,255,0.25)", textTransform:"uppercase", letterSpacing:1, marginBottom:10 }}>🔒 Locked ({locked.length})</div>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
                {locked.map(a=>(
                  <div key={a.id} style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:18, padding:"16px 12px", textAlign:"center", opacity:0.6 }}>
                    <div style={{ fontSize:32, marginBottom:8, filter:"grayscale(1)", opacity:0.4 }}>{a.emoji}</div>
                    <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:13, color:"rgba(255,255,255,0.4)", letterSpacing:0.3, marginBottom:4 }}>{a.name}</div>
                    <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", lineHeight:1.4 }}>{a.desc}</div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      )}

      {/* ── SIGHTINGS ── */}
      {tab==="sightings" && (
        <div>
          {/* Trip filter */}
          <div style={{ marginBottom:12 }}>
            <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:8 }}>🏝️ Filter by Trip</div>
            <div style={{ display:"flex", gap:6, overflowX:"auto", paddingBottom:4, WebkitOverflowScrolling:"touch" }}>
              <button onClick={()=>setSightDestFilter(null)} style={{ flexShrink:0, padding:"7px 12px", borderRadius:16, border:`1.5px solid ${!sightDestFilter?"rgba(255,255,255,0.5)":"rgba(255,255,255,0.08)"}`, background:!sightDestFilter?"rgba(255,255,255,0.1)":"rgba(255,255,255,0.04)", color:!sightDestFilter?"#fff":"rgba(255,255,255,0.4)", fontSize:11, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap" }}>🌊 All Trips</button>
              {destinations.map(d=>(
                <button key={d.id} onClick={()=>setSightDestFilter(sightDestFilter?.id===d.id?null:d)} style={{ flexShrink:0, padding:"7px 12px", borderRadius:16, border:`1.5px solid ${sightDestFilter?.id===d.id?d.color+"88":"rgba(255,255,255,0.08)"}`, background:sightDestFilter?.id===d.id?d.color+"18":"rgba(255,255,255,0.04)", color:sightDestFilter?.id===d.id?d.color:"rgba(255,255,255,0.4)", fontSize:11, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap", transition:"all 0.15s" }}>
                  {d.emoji} {d.name.split(" ")[0]}
                </button>
              ))}
            </div>
          </div>

          {/* Category filter */}
          <div style={{ marginBottom:14 }}>
            <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:8 }}>📂 Category</div>
            <div style={{ display:"flex", gap:6, overflowX:"auto", paddingBottom:4 }}>
              {sightCats.map(c=>(
                <button key={c} onClick={()=>setSightCatFilter(c)} style={{ flexShrink:0, padding:"7px 14px", borderRadius:20, border:"none", cursor:"pointer", fontSize:11, fontWeight:700, background:sightCatFilter===c?"#fff":"rgba(255,255,255,0.07)", color:sightCatFilter===c?"#060c14":"rgba(255,255,255,0.45)", transition:"all 0.15s" }}>{c}</button>
              ))}
            </div>
          </div>

          {/* Active filter summary */}
          {sightDestFilter && (
            <div style={{ background:`${sightDestFilter.color}12`, border:`1px solid ${sightDestFilter.color}33`, borderRadius:12, padding:"10px 14px", marginBottom:12, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
              <span style={{ fontSize:12, color:sightDestFilter.color, fontWeight:700 }}>
                {sightDestFilter.emoji} {sightDestFilter.name} — {filteredSights.length} sighting{filteredSights.length!==1?"s":""}
              </span>
              <button onClick={()=>setSightDestFilter(null)} style={{ fontSize:11, color:"rgba(255,255,255,0.4)", background:"none", border:"none", cursor:"pointer" }}>Clear ✕</button>
            </div>
          )}

          <div style={{ fontSize:11, color:"rgba(255,255,255,0.3)", marginBottom:10 }}>
            {sightingsChecked.size} of {SIGHTINGS.length} total checked · showing {filteredSights.length}
          </div>

          {filteredSights.length === 0 && (
            <div style={{ textAlign:"center", padding:"30px 20px" }}>
              <div style={{ fontSize:32, marginBottom:8 }}>🔍</div>
              <div style={{ fontSize:13, color:"rgba(255,255,255,0.35)" }}>No sightings match this filter</div>
            </div>
          )}

          <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
            {filteredSights.map(s=>{
              const checked = sightingsChecked.has(s.id);
              const rar = rarityConfig[s.rarity];
              return (
                <div key={s.id} style={{ background:checked?"rgba(34,197,94,0.08)":"rgba(255,255,255,0.03)", border:`1px solid ${checked?"#16a34a44":"rgba(255,255,255,0.07)"}`, borderRadius:16, padding:"14px 14px", display:"flex", gap:12, alignItems:"flex-start", transition:"all 0.2s", cursor:"pointer" }}
                  onClick={()=>toggleSighting(s.id)}>
                  <div style={{ fontSize:28, flexShrink:0 }}>{s.emoji}</div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:4 }}>
                      <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:14, color:checked?"#4ade80":"#fff", letterSpacing:0.3 }}>{s.name}</div>
                      <span style={{ fontSize:9, fontWeight:700, padding:"2px 7px", borderRadius:10, background:`${rar.color}22`, color:rar.color, flexShrink:0, marginLeft:6 }}>{rar.label}</span>
                    </div>
                    <div style={{ fontSize:11, color:"rgba(255,255,255,0.45)", lineHeight:1.55, marginBottom:6 }}>{s.desc}</div>
                    <div style={{ display:"flex", gap:4, flexWrap:"wrap" }}>
                      {s.dests.map(id=>{
                        const d = destinations.find(x=>x.id===id);
                        return d ? (
                          <span key={id} title={d.name} style={{ fontSize:13, opacity:sightDestFilter&&sightDestFilter.id===id?1:0.5 }}>{d.emoji}</span>
                        ) : null;
                      })}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── WATER TEMP & RIVER GAUGES ──────────────────────────────

// USGS gauge site numbers per destination
const USGS_GAUGES = {
  1:  { id:"07374525", name:"Pearl River at Pearlington" },
  2:  { id:"07374000", name:"Amite River near Denham Springs" },
  3:  { id:"07374000", name:"Amite River near Denham Springs" },
  4:  { id:"02492000", name:"Pearl River near Bogalusa" },
  5:  { id:"07374525", name:"Pearl River at Pearlington" },
  6:  { id:"02492000", name:"Pearl River near Bogalusa" },
  7:  { id:"07380120", name:"Bayou Lafourche at Larose" },
  8:  { id:"07374525", name:"Pearl River at Pearlington" },
  9:  { id:"07374525", name:"Pearl River at Pearlington" },
  10: { id:"07380249", name:"Bayou Barataria near Lafitte" },
  11: { id:"02481510", name:"Biloxi River near Wortham" },
  12: { id:"07380760", name:"Bayou Lafourche at Golden Meadow" },
  13: { id:"02481510", name:"Biloxi River near Wortham" },
  14: { id:"02481510", name:"Biloxi River near Wortham" },
  15: { id:"07381490", name:"Atchafalaya River at Morgan City" },
};

function WaterScreen({ destinations }) {
  const [dest, setDest] = useState(destinations[0]);

  const gauge = USGS_GAUGES[dest?.id];

  // NOAA water temp station IDs per destination
  const WATER_TEMP_STATIONS = {
    1:"8761927", 2:"8761927", 3:"8761927", 4:"8747437", 5:"8761927",
    6:"8747437", 7:"8761927", 8:"8761927", 9:"8761927", 10:"8760922",
    11:"8741533", 12:"8760922", 13:"8741533", 14:"8741533", 15:"8764227",
  };

  const tempStation = dest ? WATER_TEMP_STATIONS[dest.id] : "8761927";

  const conditionTips = dest ? [
    dest.waterDiff >= 4
      ? { icon:"⚠️", text:"Offshore — check wave height in addition to wind. Seas over 1ft make PWC crossings very rough.", color:"#f87171" }
      : dest.waterDiff >= 3
      ? { icon:"🌊", text:"Coastal destination — wind-driven chop can build quickly. Check Windy for current wave height.", color:"#fbbf24" }
      : { icon:"✅", text:"Protected inland waters — river stage and current flow are the main concerns here.", color:"#4ade80" },
    dest.id === 15
      ? { icon:"🌲", text:"Atchafalaya spring flood (Mar–May): high water opens the flooded forest but current is fast. Check USACE levels.", color:"#2dd4bf" }
      : null,
  ].filter(Boolean) : [];

  const links = dest ? [
    {
      label:`🌡️ Water Temperature — ${gauge.name.split(" at ")[1] || gauge.name}`,
      url:`https://tidesandcurrents.noaa.gov/physocean.html?bdate=today&unit=1&shift=0&stn=${tempStation}&type=WaterTemperature`,
      icon:"🌡️",
      desc:`Live water temperature from the nearest NOAA tide station to ${dest.name}. Check before choosing a wetsuit — South Louisiana water ranges from ~55°F in February to 88°F in August.`,
      color:"#fb923c",
      highlight:true,
    },
    {
      label:`📊 River Gauge — ${gauge.name}`,
      url:`https://waterdata.usgs.gov/monitoring-location/${gauge.id}/`,
      icon:"📊",
      desc:`Live flow rate (CFS) and river stage (ft) at ${gauge.name}. High flow means stronger current and potentially flooded access. Low flow means more shallow spots. Check before any river or swamp trip.`,
      color:"#a78bfa",
      highlight:true,
    },
    {
      label:"USGS National Water Dashboard",
      url:"https://dashboard.waterdata.usgs.gov/app/nwd/en/?region=lower48&aoi=default",
      icon:"🗺️",
      desc:"Interactive map of all active USGS gauges. Zoom to South Louisiana to see every gauge at once with color-coded flood status.",
      color:"#38bdf8",
    },
    {
      label:"Louisiana River Levels — NWS",
      url:"https://www.weather.gov/lmk/rivers",
      icon:"🌊",
      desc:"NWS river stage forecasts for Louisiana. Shows flood stage warnings and projected water levels over the next several days.",
      color:"#4ade80",
    },
    ...(dest.id === 15 ? [{
      label:"Atchafalaya Water Levels — USACE",
      url:"https://www.mvn.usace.army.mil/Missions/Engineering/Stage-Discharge/",
      icon:"🌲",
      desc:"Army Corps of Engineers stage data for the Atchafalaya River. Essential for spring flood season — tells you if the flooded forest is rideable.",
      color:"#2dd4bf",
    }] : []),
  ] : [];

  return (
    <div style={{ padding:"0 16px 100px" }}>
      {/* Destination selector */}
      <div style={{ marginBottom:14 }}>
        <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:1, marginBottom:8 }}>Select Destination</div>
        <div style={{ display:"flex", gap:8, overflowX:"auto", paddingBottom:4, WebkitOverflowScrolling:"touch" }}>
          {destinations.map(d=>(
            <button key={d.id} onClick={()=>setDest(d)} style={{ flexShrink:0, padding:"8px 14px", borderRadius:16, border:`1.5px solid ${dest?.id===d.id?d.color+"88":"rgba(255,255,255,0.08)"}`, background:dest?.id===d.id?d.color+"18":"rgba(255,255,255,0.04)", color:dest?.id===d.id?d.color:"rgba(255,255,255,0.4)", fontSize:12, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap", transition:"all 0.15s" }}>{d.emoji} {d.name.split(" ")[0]}</button>
          ))}
        </div>
      </div>

      {dest && (
        <>
          {/* Destination header */}
          <div style={{ background:`${dest.color}12`, border:`1.5px solid ${dest.color}33`, borderRadius:16, padding:"12px 16px", marginBottom:14, display:"flex", gap:10, alignItems:"center" }}>
            <span style={{ fontSize:22 }}>{dest.emoji}</span>
            <div>
              <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:15, color:"#fff" }}>{dest.name}</div>
              <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)" }}>Gauge: {gauge.name}</div>
            </div>
          </div>

          {/* Condition tips */}
          {conditionTips.map((tip,i)=>(
            <div key={i} style={{ background:`${tip.color}0f`, border:`1px solid ${tip.color}33`, borderRadius:12, padding:"10px 14px", marginBottom:10, display:"flex", gap:8, alignItems:"flex-start" }}>
              <span style={{ fontSize:16, flexShrink:0 }}>{tip.icon}</span>
              <span style={{ fontSize:12, color:"rgba(255,255,255,0.6)", lineHeight:1.55 }}>{tip.text}</span>
            </div>
          ))}

          {/* Wetsuit guide */}
          <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:16, padding:"14px 16px", marginBottom:16 }}>
            <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:10 }}>🌡️ Wetsuit Guide — South Louisiana Water Temps</div>
            {[
              {range:"Below 60°F", months:"Jan–Feb",       rec:"Drysuit recommended",        color:"#818cf8"},
              {range:"60–68°F",    months:"Mar / Nov–Dec", rec:"3mm wetsuit recommended",    color:"#38bdf8"},
              {range:"68–75°F",    months:"Apr / Oct",     rec:"Wetsuit optional",           color:"#4ade80"},
              {range:"75°F+",      months:"May–Sep",       rec:"No wetsuit needed",          color:"#fbbf24"},
            ].map(r=>(
              <div key={r.range} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"7px 0", borderBottom:"1px solid rgba(255,255,255,0.05)" }}>
                <div>
                  <span style={{ fontSize:12, color:"#fff" }}>{r.range}</span>
                  <span style={{ fontSize:10, color:"rgba(255,255,255,0.3)", marginLeft:8 }}>{r.months}</span>
                </div>
                <span style={{ fontSize:11, fontWeight:700, color:r.color }}>{r.rec}</span>
              </div>
            ))}
          </div>

          {/* External links */}
          <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
            {links.map((link,i)=>(
              <a key={i} href={link.url} target="_blank" rel="noopener noreferrer"
                style={{ display:"flex", gap:12, alignItems:"flex-start", background:link.highlight?`${link.color}14`:`${link.color}0a`, border:`${link.highlight?"2px":"1.5px"} solid ${link.color}${link.highlight?"66":"33"}`, borderRadius:18, padding:"14px 16px", textDecoration:"none", WebkitTapHighlightColor:"transparent" }}>
                <div style={{ width:42, height:42, borderRadius:13, background:`${link.color}18`, border:`1.5px solid ${link.color}44`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:20, flexShrink:0 }}>{link.icon}</div>
                <div style={{ flex:1 }}>
                  <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:13, color:link.color, letterSpacing:0.3, marginBottom:4, lineHeight:1.3 }}>{link.label}</div>
                  <div style={{ fontSize:11, color:"rgba(255,255,255,0.45)", lineHeight:1.55 }}>{link.desc}</div>
                </div>
                <span style={{ fontSize:16, color:"rgba(255,255,255,0.25)", flexShrink:0, marginTop:2 }}>→</span>
              </a>
            ))}
          </div>
        </>
      )}
    </div>
  );
}


// ─── FISHING & SOLUNAR ──────────────────────────────────────

// Louisiana fishing seasons and regulations
const FISHING_REGS = [
  { species:"Speckled Trout",   emoji:"🐟", season:"Year-round",  limit:"25/day", size:`12" min`, bestMonths:[3,4,5,9,10,11], bestDests:[7,8,10,12], gear:"Light spinning, 1/4oz jigs, live shrimp", notes:"Slot limit 12\"–25\". Only 1 over 25\". Best in grass flats and marsh edges.", color:"#38bdf8" },
  { species:"Redfish",          emoji:"🔴", season:"Year-round",  limit:"5/day",  size:`18\"–27\" slot`, bestMonths:[9,10,11,4,5], bestDests:[6,7,10,12], gear:"Medium spinning, gold spoons, soft plastics, live crab", notes:"Must be within slot 18\"–27\". Only 1 over 27\". Fall bull reds stack up at Half Moon and Isle Au Pitre.", color:"#f87171" },
  { species:"Flounder",         emoji:"🫓", season:"Year-round",  limit:"10/day", size:`12\" min`, bestMonths:[9,10,11], bestDests:[7,8,12], gear:"Bouncing jigs on bottom, live finger mullet", notes:"Best in fall during migration. Look for them in channel edges and cuts.", color:"#fbbf24" },
  { species:"Largemouth Bass",  emoji:"🎣", season:"Year-round",  limit:"10/day", size:`12\" min`, bestMonths:[3,4,5,10,11], bestDests:[1,2,3,15], gear:"Plastic worms, spinner baits, topwater frogs", notes:"Atchafalaya spring flood is world-class largemouth bass fishing in flooded timber.", color:"#4ade80" },
  { species:"Striped Bass",     emoji:"⚡", season:"Year-round",  limit:"25/day", size:`10\" min`, bestMonths:[2,3,4,11,12], bestDests:[1,3,15], gear:"Small jigs, live shad, crankbaits", notes:"Pearl River and Atchafalaya have good striper populations in winter and spring.", color:"#a78bfa" },
  { species:"White Perch",      emoji:"🐡", season:"Year-round",  limit:"25/day", size:"None", bestMonths:[1,2,3,11,12], bestDests:[1,2,3], gear:"Small jigs, live crickets, small spinners", notes:"Excellent winter fish when other species are slow. Common throughout swamp areas.", color:"#86efac" },
  { species:"Sheepshead",       emoji:"🦷", season:"Year-round",  limit:"15/day", size:`12\" min`, bestMonths:[2,3,4], bestDests:[12,13,14], gear:"Fiddler crabs, shrimp on bottom near structure", notes:"Around jetties, pilings, and oyster reefs. Ship Island jetty rocks are excellent.", color:"#fb923c" },
  { species:"Cobia",            emoji:"🐠", season:"Mar–Oct",     limit:"2/day",  size:`33\" min`, bestMonths:[3,4,5,6], bestDests:[12,13,14], gear:"Live eels, bucktail jigs, sight-cast near surface", notes:"Follow cownose rays in spring migration along the coast. Offshore platforms are hot spots.", color:"#f472b6" },
  { species:"Red Snapper",      emoji:"🍎", season:"See NOAA",    limit:"2/day",  size:`16\" min`, bestMonths:[6,7,8], bestDests:[12,13,14], gear:"Heavy bottom rigs, squid, whole fish", notes:"Federal waters. Season dates change annually — always check NOAA before targeting snapper.", color:"#ef4444" },
  { species:"Catfish",          emoji:"😺", season:"Year-round",  limit:"25/day", size:"None", bestMonths:[5,6,7,8], bestDests:[1,2,3,15], gear:"Stink bait, chicken liver, cut shad on bottom", notes:"Blue cats get massive in the Atchafalaya. Night fishing in summer is excellent.", color:"#d97706" },
];

// Solunar calculation — simple major/minor period approximation
function getSolunarPeriods(date) {
  const d = new Date(date + "T12:00:00");
  const dayOfYear = Math.floor((d - new Date(d.getFullYear(), 0, 0)) / 86400000);
  // Moon phase approximation (0-29.5 day cycle)
  const moonPhase = ((dayOfYear + 3) % 29.53) / 29.53;
  const moonIllum = Math.round(Math.abs(Math.cos(moonPhase * Math.PI * 2)) * 100);

  // Peak activity: new moon (0%) and full moon (100%) = best fishing
  const lunarScore = moonIllum > 85 || moonIllum < 15 ? "Prime" :
                     moonIllum > 65 || moonIllum < 35 ? "Good" : "Moderate";
  const lunarColor = lunarScore === "Prime" ? "#4ade80" : lunarScore === "Good" ? "#fbbf24" : "#a78bfa";

  // Major periods (~6hr apart, minor 3hr offset)
  const baseHour = (dayOfYear * 0.8) % 12;
  const major1 = Math.floor(baseHour);
  const major2 = (major1 + 12) % 24;
  const minor1 = (major1 + 6) % 24;
  const minor2 = (major1 + 18) % 24;

  function fmtHr(h) {
    const ampm = h >= 12 ? "PM" : "AM";
    const hr = h % 12 || 12;
    return `${hr}:00 ${ampm}`;
  }

  const phaseLabel = moonIllum > 85 ? "Full Moon 🌕" :
                     moonIllum > 65 ? "Waxing Gibbous 🌔" :
                     moonIllum > 35 ? "Quarter Moon 🌓" :
                     moonIllum > 15 ? "Waxing Crescent 🌒" : "New Moon 🌑";

  return { major1:fmtHr(major1), major2:fmtHr(major2), minor1:fmtHr(minor1), minor2:fmtHr(minor2), moonIllum, phaseLabel, lunarScore, lunarColor };
}

function FishingScreen({ destinations }) {
  const [tab, setTab] = useState("regs");
  const [solDate, setSolDate] = useState(new Date().toISOString().slice(0,10));
  const [filterDest, setFilterDest] = useState(null);
  const currentMonth = new Date().getMonth() + 1;

  const sol = getSolunarPeriods(solDate);

  const filteredRegs = filterDest
    ? FISHING_REGS.filter(r => r.bestDests.includes(filterDest.id))
    : FISHING_REGS;

  const inSeason = FISHING_REGS.filter(r => r.bestMonths.includes(currentMonth));

  return (
    <div style={{ padding:"0 16px 100px" }}>
      {/* Sub-tabs */}
      <div style={{ display:"flex", gap:6, marginBottom:14 }}>
        {[["regs","🎣 Regulations"],["solunar","🌕 Solunar"],["now","⭐ In Season"]].map(([v,l])=>(
          <button key={v} onClick={()=>setTab(v)} style={{ flex:1, padding:"10px 4px", borderRadius:14, border:"none", cursor:"pointer", fontSize:11, fontWeight:700, background:tab===v?"rgba(255,255,255,0.1)":"rgba(255,255,255,0.04)", color:tab===v?"#fff":"rgba(255,255,255,0.35)", borderBottom:tab===v?"2px solid #4ade80":"2px solid transparent", transition:"all 0.15s" }}>{l}</button>
        ))}
      </div>

      {/* ── REGULATIONS ── */}
      {tab==="regs" && (
        <div>
          {/* Filter by destination */}
          <div style={{ marginBottom:12 }}>
            <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:1, marginBottom:8 }}>Filter by Destination</div>
            <div style={{ display:"flex", gap:6, overflowX:"auto", paddingBottom:4 }}>
              <button onClick={()=>setFilterDest(null)} style={{ flexShrink:0, padding:"7px 14px", borderRadius:16, border:`1.5px solid ${!filterDest?"#4ade8088":"rgba(255,255,255,0.08)"}`, background:!filterDest?"rgba(74,222,128,0.12)":"rgba(255,255,255,0.04)", color:!filterDest?"#4ade80":"rgba(255,255,255,0.4)", fontSize:11, fontWeight:700, cursor:"pointer" }}>🌊 All</button>
              {destinations.map(d=>(
                <button key={d.id} onClick={()=>setFilterDest(d)} style={{ flexShrink:0, padding:"7px 12px", borderRadius:16, border:`1.5px solid ${filterDest?.id===d.id?d.color+"88":"rgba(255,255,255,0.08)"}`, background:filterDest?.id===d.id?`${d.color}18`:"rgba(255,255,255,0.04)", color:filterDest?.id===d.id?d.color:"rgba(255,255,255,0.4)", fontSize:11, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap" }}>{d.emoji} {d.name.split(" ")[0]}</button>
              ))}
            </div>
          </div>

          <div style={{ background:"rgba(74,222,128,0.06)", border:"1px solid rgba(74,222,128,0.15)", borderRadius:14, padding:"10px 14px", marginBottom:14, display:"flex", gap:8, alignItems:"center" }}>
            <span>⚖️</span>
            <span style={{ fontSize:11, color:"rgba(255,255,255,0.5)", lineHeight:1.5 }}>Louisiana resident basic fishing license covers all species below in state waters. Always verify current LDWF regulations before fishing.</span>
          </div>

          <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
            {filteredRegs.map(r=>{
              const isGoodNow = r.bestMonths.includes(currentMonth);
              return (
                <div key={r.species} style={{ background:`${r.color}0a`, border:`1.5px solid ${r.color}33`, borderRadius:18, overflow:"hidden" }}>
                  <div style={{ padding:"14px 16px 10px" }}>
                    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:8 }}>
                      <div style={{ display:"flex", gap:10, alignItems:"center" }}>
                        <span style={{ fontSize:24 }}>{r.emoji}</span>
                        <div>
                          <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:16, color:"#fff", letterSpacing:0.3 }}>{r.species}</div>
                          <div style={{ fontSize:11, color:r.color, fontWeight:700 }}>{r.season}</div>
                        </div>
                      </div>
                      {isGoodNow && <span style={{ fontSize:10, fontWeight:700, padding:"3px 8px", borderRadius:10, background:"rgba(74,222,128,0.15)", color:"#4ade80", border:"1px solid rgba(74,222,128,0.3)" }}>IN SEASON</span>}
                    </div>
                    <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:8 }}>
                      {[["Bag Limit",r.limit],["Min Size",r.size]].map(([lbl,val])=>(
                        <div key={lbl} style={{ background:"rgba(255,255,255,0.05)", borderRadius:10, padding:"8px 10px" }}>
                          <div style={{ fontSize:9, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.5, marginBottom:3 }}>{lbl}</div>
                          <div style={{ fontSize:13, color:"#fff", fontWeight:700 }}>{val}</div>
                        </div>
                      ))}
                    </div>
                    <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)", lineHeight:1.55, marginBottom:6 }}>
                      <span style={{ color:r.color }}>🎣 Gear:</span> {r.gear}
                    </div>
                    <div style={{ fontSize:11, color:"rgba(255,255,255,0.5)", lineHeight:1.55 }}>{r.notes}</div>
                    <div style={{ display:"flex", gap:4, marginTop:8, flexWrap:"wrap" }}>
                      {r.bestDests.map(id=>{
                        const d = destinations.find(x=>x.id===id);
                        return d ? <span key={id} style={{ fontSize:14 }} title={d.name}>{d.emoji}</span> : null;
                      })}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <a href="https://www.wlf.louisiana.gov/page/recreational-fishing" target="_blank" rel="noopener noreferrer"
            style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:8, background:"rgba(74,222,128,0.08)", border:"1px solid rgba(74,222,128,0.2)", borderRadius:14, padding:"12px", color:"#4ade80", fontSize:13, fontWeight:700, textDecoration:"none", marginTop:14 }}>
            → Full LDWF Regulations
          </a>
        </div>
      )}

      {/* ── SOLUNAR ── */}
      {tab==="solunar" && (
        <div>
          <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:16, padding:"14px 16px", marginBottom:14 }}>
            <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:8 }}>📅 Select Date</div>
            <input type="date" value={solDate} onChange={e=>setSolDate(e.target.value)} style={{ width:"100%", background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:10, padding:"10px 12px", color:"#fff", fontSize:14, outline:"none", fontFamily:"'Barlow',sans-serif" }}/>
          </div>

          {/* Moon phase */}
          <div style={{ background:`${sol.lunarColor}12`, border:`1.5px solid ${sol.lunarColor}44`, borderRadius:20, padding:"20px", marginBottom:14, textAlign:"center" }}>
            <div style={{ fontSize:40, marginBottom:8 }}>{sol.phaseLabel.split(" ")[0] === "Full" ? "🌕" : sol.phaseLabel.split(" ")[0] === "New" ? "🌑" : "🌓"}</div>
            <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:18, color:"#fff", marginBottom:4 }}>{sol.phaseLabel}</div>
            <div style={{ fontSize:13, color:"rgba(255,255,255,0.5)", marginBottom:12 }}>{sol.moonIllum}% illumination</div>
            <div style={{ display:"inline-flex", gap:8, alignItems:"center", background:`${sol.lunarColor}18`, border:`1px solid ${sol.lunarColor}44`, borderRadius:20, padding:"6px 16px" }}>
              <div style={{ width:8, height:8, borderRadius:"50%", background:sol.lunarColor, boxShadow:`0 0 8px ${sol.lunarColor}` }}/>
              <span style={{ fontSize:13, fontWeight:700, color:sol.lunarColor }}>{sol.lunarScore} Fishing</span>
            </div>
          </div>

          {/* Major/minor periods */}
          <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:18, padding:"16px", marginBottom:14 }}>
            <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:14 }}>⏰ Peak Activity Windows</div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:10 }}>
              {[
                { label:"Major Period 1", time:sol.major1, color:"#4ade80", desc:"High activity (2hr window)" },
                { label:"Major Period 2", time:sol.major2, color:"#4ade80", desc:"High activity (2hr window)" },
                { label:"Minor Period 1", time:sol.minor1, color:"#fbbf24", desc:"Moderate activity (1hr window)" },
                { label:"Minor Period 2", time:sol.minor2, color:"#fbbf24", desc:"Moderate activity (1hr window)" },
              ].map(p=>(
                <div key={p.label} style={{ background:`${p.color}0f`, border:`1px solid ${p.color}33`, borderRadius:14, padding:"12px 10px" }}>
                  <div style={{ fontSize:9, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.5, marginBottom:6 }}>{p.label}</div>
                  <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:20, color:p.color, marginBottom:4 }}>{p.time}</div>
                  <div style={{ fontSize:10, color:"rgba(255,255,255,0.35)" }}>{p.desc}</div>
                </div>
              ))}
            </div>
            <div style={{ background:"rgba(255,255,255,0.04)", borderRadius:12, padding:"10px 14px" }}>
              <div style={{ fontSize:11, color:"rgba(255,255,255,0.5)", lineHeight:1.6 }}>
                🎣 <strong style={{ color:"rgba(255,255,255,0.7)" }}>Pro tip:</strong> Start fishing 30 minutes before each major period. Combine with incoming tide for best results. Note: these are approximations — actual peak times vary by location.
              </div>
            </div>
          </div>

          <a href="https://www.solunarforecast.com" target="_blank" rel="noopener noreferrer"
            style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:8, background:"rgba(74,222,128,0.08)", border:"1px solid rgba(74,222,128,0.2)", borderRadius:14, padding:"12px", color:"#4ade80", fontSize:13, fontWeight:700, textDecoration:"none" }}>
            → Full Solunar Forecast
          </a>
        </div>
      )}

      {/* ── IN SEASON NOW ── */}
      {tab==="now" && (
        <div>
          <div style={{ background:"rgba(74,222,128,0.08)", border:"1px solid rgba(74,222,128,0.2)", borderRadius:16, padding:"14px 16px", marginBottom:14 }}>
            <div style={{ fontSize:14, color:"#4ade80", fontWeight:700, marginBottom:4 }}>
              ⭐ Best fishing this month
            </div>
            <div style={{ fontSize:12, color:"rgba(255,255,255,0.5)" }}>
              {inSeason.length} species at peak activity right now
            </div>
          </div>
          <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
            {inSeason.map(r=>(
              <div key={r.species} style={{ background:`${r.color}12`, border:`1.5px solid ${r.color}44`, borderRadius:16, padding:"14px 16px", display:"flex", gap:12, alignItems:"flex-start" }}>
                <span style={{ fontSize:28, flexShrink:0 }}>{r.emoji}</span>
                <div style={{ flex:1 }}>
                  <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:16, color:"#fff", marginBottom:2 }}>{r.species}</div>
                  <div style={{ fontSize:11, color:r.color, marginBottom:4, fontWeight:700 }}>Limit: {r.limit} · Min: {r.size}</div>
                  <div style={{ fontSize:11, color:"rgba(255,255,255,0.45)", lineHeight:1.5 }}>{r.gear}</div>
                  <div style={{ display:"flex", gap:4, marginTop:6 }}>
                    {r.bestDests.map(id=>{
                      const d = destinations.find(x=>x.id===id);
                      return d ? <span key={id} style={{ fontSize:14 }} title={d.name}>{d.emoji}</span> : null;
                    })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── PERMITS & CREDENTIALS ──────────────────────────────────

const PERMIT_ITEMS = [
  { id:"nasbla",  emoji:"🎓", title:"NASBLA Boater Education Cert",    coverage:"All 50 states + federal waters", required:"All trips", notes:"Carry a copy on every trip. Required for PWC in LA and MS.", color:"#4ade80" },
  { id:"laboat",  emoji:"🚤", title:"LA Vessel Registration (Ski 1)",  coverage:"Must be displayed on hull",      required:"All LA trips", notes:"Decals must be current and visible. Paper copy onboard.", color:"#a78bfa" },
  { id:"laboat2", emoji:"🚤", title:"LA Vessel Registration (Ski 2)",  coverage:"Must be displayed on hull",      required:"All LA trips", notes:"Decals must be current and visible. Paper copy onboard.", color:"#a78bfa" },
  { id:"lafish",  emoji:"🎣", title:"LA Basic Fishing License",        coverage:"All LA fresh & saltwater species",required:"When fishing in LA", notes:"Covers speckled trout, redfish, bass, catfish, and all other LA species.", color:"#38bdf8" },
  { id:"wma",     emoji:"🌿", title:"LA WMA Access Permit",            coverage:"All state WMA managed waters",   required:"Big Branch, Pearl River WMA, Atchafalaya WMA", notes:"Required to access state wildlife management areas.", color:"#86efac" },
  { id:"msfish",  emoji:"🐟", title:"MS Non-Resident Fishing License", coverage:"MS state waters",                required:"Half Moon, Deer Island, Ship Island, Cat Island", notes:"Get at mdwfp.com or Walmart before MS trips.", color:"#fbbf24", link:"https://www.mdwfp.com/license/" },
  { id:"msboat",  emoji:"📄", title:"MS Vessel Registration",         coverage:"Required if launching in MS",    required:"When launching from MS ramps", notes:"LA registration may not cover MS launches — verify before trailering to MS.", color:"#fb923c" },
];

const PRE_TRIP_ITEMS = [
  { id:"tc1", text:"Boating cert accessible (phone or card)" },
  { id:"tc2", text:"Both vessel registrations onboard" },
  { id:"tc3", text:"LA fishing license (if fishing)" },
  { id:"tc4", text:"WMA permit (if entering WMA waters)" },
  { id:"tc5", text:"MS fishing license (if crossing into MS)" },
  { id:"tc6", text:"Float plan filed with someone onshore" },
  { id:"tc7", text:"Emergency contacts saved offline" },
];

function PermitsScreen() {
  const [statuses, setStatuses] = useState(() =>
    Object.fromEntries(PERMIT_ITEMS.map(p => [p.id, "unknown"]))
  );
  const [tab, setTab] = useState("status");

  const cycleStatus = id => {
    setStatuses(prev => {
      const cycle = { unknown:"active", active:"expiring", expiring:"needed", needed:"unknown" };
      return { ...prev, [id]: cycle[prev[id]] };
    });
  };

  const STATUS_CFG = {
    active:   { label:"✓ Current",   color:"#4ade80", bg:"rgba(74,222,128,0.12)",  border:"rgba(74,222,128,0.3)"  },
    expiring: { label:"⚠ Expiring",  color:"#fbbf24", bg:"rgba(251,191,36,0.12)",  border:"rgba(251,191,36,0.3)"  },
    needed:   { label:"✗ Needed",    color:"#f87171", bg:"rgba(248,113,113,0.12)", border:"rgba(248,113,113,0.3)" },
    unknown:  { label:"? Unverified",color:"rgba(255,255,255,0.3)", bg:"rgba(255,255,255,0.05)", border:"rgba(255,255,255,0.1)" },
  };

  const activeCount  = Object.values(statuses).filter(s=>s==="active").length;
  const issueCount   = Object.values(statuses).filter(s=>s==="needed"||s==="expiring").length;
  const unknownCount = Object.values(statuses).filter(s=>s==="unknown").length;
  const allGood      = activeCount === PERMIT_ITEMS.length;

  return (
    <div style={{ padding:"0 16px 100px" }}>

      {/* Overall status card */}
      <div style={{
        background: allGood ? "linear-gradient(135deg,rgba(74,222,128,0.12),rgba(34,197,94,0.06))"
          : issueCount > 0 ? "linear-gradient(135deg,rgba(248,113,113,0.1),rgba(239,68,68,0.05))"
          : "linear-gradient(135deg,rgba(251,191,36,0.1),rgba(245,158,11,0.05))",
        border: `1.5px solid ${allGood?"rgba(74,222,128,0.3)":issueCount>0?"rgba(248,113,113,0.3)":"rgba(251,191,36,0.3)"}`,
        borderRadius:20, padding:"16px 18px", marginBottom:14
      }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12 }}>
          <div>
            <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:22, color: allGood?"#4ade80":issueCount>0?"#f87171":"#fbbf24" }}>
              {allGood ? "✅ All Clear" : issueCount > 0 ? "🚨 Action Needed" : "⚠️ Unverified Items"}
            </div>
            <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)", marginTop:2 }}>
              {allGood ? "All permits current — ready to ride" : unknownCount > 0 ? `${unknownCount} item${unknownCount>1?"s":""} not yet verified` : `${issueCount} item${issueCount>1?"s":""} need attention`}
            </div>
          </div>
          <div style={{ fontSize:40 }}>{allGood?"🏄":issueCount>0?"⛔":"🔍"}</div>
        </div>
        <div style={{ display:"flex", gap:8 }}>
          {[
            { label:"Current", val:activeCount,  color:"#4ade80" },
            { label:"Issues",  val:issueCount,   color:"#f87171" },
            { label:"Unknown", val:unknownCount, color:"rgba(255,255,255,0.3)" },
          ].map(s=>(
            <div key={s.label} style={{ flex:1, background:"rgba(255,255,255,0.06)", borderRadius:12, padding:"8px", textAlign:"center" }}>
              <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:20, color:s.color }}>{s.val}</div>
              <div style={{ fontSize:9, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.5 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Sub-tabs — status only now, checklist moved to Preflight */}
      <div style={{ background:"rgba(56,189,248,0.06)", border:"1px solid rgba(56,189,248,0.15)", borderRadius:12, padding:"10px 14px", marginBottom:14 }}>
        <div style={{ fontSize:11, color:"rgba(255,255,255,0.5)", lineHeight:1.5 }}>
          ✅ Pre-trip legal checklist has moved to the <strong style={{ color:"#38bdf8" }}>Preflight</strong> screen under "Permits & Legal"
        </div>
      </div>

      {/* ── STATUS TAB ── */}
      {tab==="status" && (
        <div>
          <div style={{ background:"rgba(56,189,248,0.06)", border:"1px solid rgba(56,189,248,0.15)", borderRadius:12, padding:"10px 14px", marginBottom:14 }}>
            <div style={{ fontSize:11, color:"rgba(255,255,255,0.5)", lineHeight:1.5 }}>
              💡 Tap any permit to cycle its status: <span style={{ color:"#4ade80" }}>Current</span> → <span style={{ color:"#fbbf24" }}>Expiring</span> → <span style={{ color:"#f87171" }}>Needed</span> → Unverified
            </div>
          </div>

          <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
            {PERMIT_ITEMS.map(p => {
              const s = STATUS_CFG[statuses[p.id]];
              return (
                <div key={p.id} onClick={()=>cycleStatus(p.id)} style={{ background:`${p.color}08`, border:`1.5px solid ${p.color}33`, borderRadius:18, padding:"14px 16px", cursor:"pointer", transition:"all 0.2s", WebkitTapHighlightColor:"transparent" }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:8 }}>
                    <div style={{ display:"flex", gap:10, alignItems:"center", flex:1 }}>
                      <div style={{ width:40, height:40, borderRadius:12, background:`${p.color}18`, border:`1.5px solid ${p.color}44`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:20, flexShrink:0 }}>{p.emoji}</div>
                      <div style={{ flex:1, minWidth:0 }}>
                        <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:14, color:"#fff", letterSpacing:0.3, lineHeight:1.2 }}>{p.title}</div>
                        <div style={{ fontSize:10, color:"rgba(255,255,255,0.35)", marginTop:2 }}>Required for: {p.required}</div>
                      </div>
                    </div>
                    <span style={{ fontSize:11, fontWeight:700, padding:"4px 10px", borderRadius:20, background:s.bg, color:s.color, border:`1px solid ${s.border}`, flexShrink:0, marginLeft:8, whiteSpace:"nowrap" }}>{s.label}</span>
                  </div>
                  <div style={{ fontSize:11, color:"rgba(255,255,255,0.45)", lineHeight:1.5, marginBottom:4 }}>{p.notes}</div>
                  <div style={{ fontSize:10, color:p.color, opacity:0.7 }}>Coverage: {p.coverage}</div>
                  {p.link && statuses[p.id]==="needed" && (
                    <a href={p.link} target="_blank" rel="noopener noreferrer" onClick={e=>e.stopPropagation()} style={{ display:"inline-block", marginTop:8, fontSize:12, color:p.color, fontWeight:700, textDecoration:"none" }}>→ Get this license</a>
                  )}
                </div>
              );
            })}
          </div>

          {/* LA PWC laws */}
          <div style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:16, padding:"14px 16px", marginTop:14 }}>
            <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:10 }}>⚖️ Key Louisiana PWC Laws</div>
            {[
              "No PWC operation after sunset or before sunrise",
              "PFD must be worn — not just onboard — at all times on a PWC",
              "Kill switch lanyard must be attached to operator at all times",
              "No wake jumping within 100 feet of another vessel",
              "No riding within 50 feet of swimmers, docks, or anchored vessels",
              "Operator must be 16+ (14–15 with NASBLA cert and adult supervision)",
            ].map((law,i)=>(
              <div key={i} style={{ display:"flex", gap:8, alignItems:"flex-start", marginBottom:8 }}>
                <span style={{ color:"#f87171", fontSize:11, flexShrink:0, marginTop:1 }}>⚖</span>
                <span style={{ fontSize:12, color:"rgba(255,255,255,0.55)", lineHeight:1.5 }}>{law}</span>
              </div>
            ))}
            <a href="https://www.wlf.louisiana.gov/page/boating-laws-and-regulations" target="_blank" rel="noopener noreferrer" style={{ display:"block", marginTop:8, color:"#38bdf8", fontSize:12 }}>→ Full LA Boating Laws</a>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── VHF GUIDE & MARINA FINDER ──────────────────────────────

const VHF_CHANNELS = [
  { ch:"16",    name:"Distress / Hailing",     color:"#f87171", critical:true,  desc:"ALWAYS monitor this channel. International distress frequency. Hail all vessels and Coast Guard here first. Never use for long conversations." },
  { ch:"22A",   name:"Coast Guard Working",    color:"#f87171", critical:true,  desc:"After hailing on 16, Coast Guard will direct you here. Primary CG communications channel in the Gulf and inland waters." },
  { ch:"9",     name:"Recreational Hailing",   color:"#fbbf24", critical:false, desc:"Alternate hailing channel for recreational boats. Less busy than 16. Many boaters monitor this alongside 16." },
  { ch:"68",    name:"Non-Commercial Working", color:"#38bdf8", critical:false, desc:"Popular recreational working channel. Switch here after making contact on 16 or 9 for conversations." },
  { ch:"69",    name:"Non-Commercial Working", color:"#38bdf8", critical:false, desc:"Another common recreational working channel throughout the Gulf Coast and inland waterways." },
  { ch:"71",    name:"Non-Commercial Working", color:"#38bdf8", critical:false, desc:"Commonly used in the Mississippi River corridor and Atchafalaya Basin area." },
  { ch:"72",    name:"Non-Commercial Working", color:"#38bdf8", critical:false, desc:"Ship-to-ship only. No ship-to-shore. Popular in Biloxi Sound and MS Gulf Coast area." },
  { ch:"78A",   name:"Non-Commercial Working", color:"#38bdf8", critical:false, desc:"Used along the Gulf Coast for recreational boat-to-boat communications." },
  { ch:"WX1",   name:"NOAA Weather",           color:"#a78bfa", critical:false, desc:"Continuous NOAA weather broadcast. Check before every trip. Coverage for Gulf of Mexico, Lake Pontchartrain, and coastal LA/MS." },
  { ch:"WX2",   name:"NOAA Weather Alt",       color:"#a78bfa", critical:false, desc:"Alternate NOAA weather channel. Try this if WX1 is weak in your area." },
  { ch:"14",    name:"Vessel Traffic / Port",  color:"#fb923c", critical:false, desc:"Used by commercial vessel traffic services. Monitor when near commercial shipping channels like MRGO and Mississippi River." },
  { ch:"13",    name:"Bridge-to-Bridge",       color:"#fb923c", critical:false, desc:"Used by commercial vessels and bridges. Monitor when approaching drawbridges on the Intracoastal Waterway." },
];

const MARINAS = [
  { id:"m1",  name:"Hopedale Marina",              emoji:"⚓", area:"St. Bernard Parish", dist:[7,8], fuel:true,  bait:true,  slips:true,  ramp:true,  food:false, phone:"(504) 676-4633", color:"#fb923c", note:"Best full-service launch for Isle Au Pitre and Lake Borgne. Live bait, fuel, cabin rentals." },
  { id:"m2",  name:"Shell Beach Boat Ramp",         emoji:"🚤", area:"St. Bernard Parish", dist:[8],   fuel:false, bait:false, slips:false, ramp:true,  food:false, phone:"—", color:"#38bdf8", note:"Free public ramp. Good access point for Lake Borgne and MRGO corridor." },
  { id:"m3",  name:"Lafitte Harbor Marina",         emoji:"⚓", area:"Lafitte / Barataria", dist:[10],  fuel:true,  bait:true,  slips:true,  ramp:true,  food:false, phone:"(504) 689-3271", color:"#4ade80", note:"Full service. Best launch for Barataria Basin. Buy fuel here before heading deep into the marsh." },
  { id:"m4",  name:"Grand Isle Marina",             emoji:"🏖️", area:"Grand Isle, LA",     dist:[12],  fuel:true,  bait:true,  slips:true,  ramp:true,  food:true,  phone:"(985) 787-2303", color:"#fb7185", note:"Main marina on Grand Isle. Fuel, bait, overnight slips, and nearby restaurants." },
  { id:"m5",  name:"Port Fourchon Marina",          emoji:"🛢️", area:"Lafourche Parish",   dist:[12],  fuel:true,  bait:true,  slips:true,  ramp:true,  food:false, phone:"(985) 396-2166", color:"#fbbf24", note:"Industrial marina but has public ramp and fuel. Jumping-off point for Gulf rides." },
  { id:"m6",  name:"Bridge Side Marina",            emoji:"🌉", area:"Grand Isle, LA",     dist:[12],  fuel:true,  bait:true,  slips:false, ramp:true,  food:false, phone:"(985) 787-2214", color:"#fb923c", note:"Smaller marina on the north side of Grand Isle. Good fuel and bait stop." },
  { id:"m7",  name:"Lake Catherine Island Marina",  emoji:"🌊", area:"New Orleans East",   dist:[5],   fuel:true,  bait:true,  slips:true,  ramp:true,  food:false, phone:"(504) 254-4075", color:"#22d3ee", note:"Best launch for Rabbit Island and Rigolets area. Fuel, live bait, overnight lodging available." },
  { id:"m8",  name:"Crawford Landing",              emoji:"🌿", area:"Slidell / Pearl River", dist:[1],  fuel:false, bait:false, slips:false, ramp:true,  food:false, phone:"—", color:"#00e5a0", note:"Free public ramp. Primary launch for Honey Island Swamp and Pearl River system." },
  { id:"m9",  name:"Atchafalaya Basin Landing",     emoji:"🌲", area:"Henderson, LA",      dist:[15],  fuel:true,  bait:true,  slips:false, ramp:true,  food:false, phone:"(337) 228-7124", color:"#2dd4bf", note:"3-lane ramp, $5 launch fee or $100 annual pass. Fuel on site. Primary Atchafalaya Basin access." },
  { id:"m10", name:"Cypress Cove Landing",          emoji:"🍃", area:"Henderson, LA",      dist:[15],  fuel:false, bait:false, slips:false, ramp:true,  food:true,  phone:"(337) 228-7787", color:"#34d399", note:"24/7 public ramp. Adjacent to a waterfront restaurant. Alternative Atchafalaya launch." },
  { id:"m11", name:"Ocean Springs Harbor",          emoji:"⛵", area:"Ocean Springs, MS",  dist:[13],  fuel:true,  bait:true,  slips:true,  ramp:true,  food:false, phone:"(228) 818-5790", color:"#f87171", note:"Main launch for Ship Island crossing. Full service marina with fuel." },
  { id:"m12", name:"Gulfport Small Craft Harbor",  emoji:"🌊", area:"Gulfport, MS",        dist:[13,14],fuel:true, bait:true,  slips:true,  ramp:true,  food:true,  phone:"(228) 868-5715", color:"#ef4444", note:"Large harbor. Good launch for both Ship Island and Cat Island crossings." },
  { id:"m13", name:"Biloxi Small Craft Harbor",    emoji:"🎰", area:"Biloxi, MS",          dist:[11],  fuel:true,  bait:true,  slips:true,  ramp:true,  food:true,  phone:"(228) 374-3105", color:"#fde68a", note:"Launch for Deer Island. Busy with casino traffic — use caution leaving the harbor." },
  { id:"m14", name:"Pass Christian Harbor",         emoji:"⚓", area:"Pass Christian, MS", dist:[14],  fuel:true,  bait:false, slips:true,  ramp:true,  food:false, phone:"(228) 452-3855", color:"#f472b6", note:"Best launch for Cat Island. Quieter than Gulfport, good fuel." },
];

function VhfScreen({ destinations }) {
  const [tab, setTab] = useState("vhf");
  const [marinaFilter, setMarinaFilter] = useState(null);

  const filteredMarinas = marinaFilter
    ? MARINAS.filter(m => m.dist.includes(marinaFilter.id))
    : MARINAS;

  const AmenityBadge = ({ label, active, color }) => (
    <span style={{ fontSize:10, fontWeight:700, padding:"2px 7px", borderRadius:8, background:active?`${color}22`:"rgba(255,255,255,0.05)", color:active?color:"rgba(255,255,255,0.2)", border:`1px solid ${active?color+"44":"rgba(255,255,255,0.08)"}` }}>{label}</span>
  );

  return (
    <div style={{ padding:"0 16px 100px" }}>
      <div style={{ display:"flex", gap:6, marginBottom:14 }}>
        {[["vhf","📻 VHF Guide"],["marinas","⚓ Marinas"]].map(([v,l])=>(
          <button key={v} onClick={()=>setTab(v)} style={{ flex:1, padding:"10px 8px", borderRadius:14, border:"none", cursor:"pointer", fontSize:12, fontWeight:700, background:tab===v?"rgba(255,255,255,0.1)":"rgba(255,255,255,0.04)", color:tab===v?"#fff":"rgba(255,255,255,0.35)", borderBottom:tab===v?"2px solid #f87171":"2px solid transparent", transition:"all 0.15s" }}>{l}</button>
        ))}
      </div>

      {/* ── VHF CHANNELS ── */}
      {tab==="vhf" && (
        <div>
          {/* Emergency banner */}
          <div style={{ background:"#3b0000", border:"2px solid #dc262688", borderRadius:18, padding:"16px 18px", marginBottom:16 }}>
            <div style={{ display:"flex", gap:10, alignItems:"center", marginBottom:8 }}>
              <span style={{ fontSize:28 }}>🚨</span>
              <div>
                <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:22, color:"#f87171", letterSpacing:1 }}>CHANNEL 16</div>
                <div style={{ fontSize:11, color:"rgba(255,255,255,0.5)" }}>International Distress & Hailing</div>
              </div>
            </div>
            <div style={{ fontSize:12, color:"rgba(255,255,255,0.6)", lineHeight:1.6, marginBottom:10 }}>
              Monitor Channel 16 at ALL times when on the water. This is the universal distress frequency — any vessel in trouble broadcasts a MAYDAY here.
            </div>
            <div style={{ background:"rgba(239,68,68,0.12)", borderRadius:10, padding:"10px 12px" }}>
              <div style={{ fontSize:11, color:"#fca5a5", fontWeight:700, marginBottom:4 }}>MAYDAY Call Format:</div>
              <div style={{ fontSize:11, color:"rgba(255,255,255,0.6)", fontFamily:"monospace", lineHeight:1.8 }}>
                "MAYDAY MAYDAY MAYDAY"<br/>
                "This is [vessel name]"<br/>
                "Position: [GPS coords or landmark]"<br/>
                "Nature of distress: [what's wrong]"<br/>
                "Number of persons aboard: [#]"<br/>
                "MAYDAY [vessel name] over"
              </div>
            </div>
          </div>

          {/* Coast Guard contacts */}
          <div style={{ background:"rgba(248,113,113,0.08)", border:"1px solid rgba(248,113,113,0.2)", borderRadius:16, padding:"14px 16px", marginBottom:14 }}>
            <div style={{ fontSize:10, color:"#f87171", textTransform:"uppercase", letterSpacing:0.8, fontWeight:700, marginBottom:10 }}>🇺🇸 Coast Guard Contacts</div>
            {[
              { label:"New Orleans Sector", phone:"(504) 589-6225", coverage:"Lake Pontchartrain, Barataria, MRGO, Gulf of Mexico LA" },
              { label:"Mobile Sector", phone:"(251) 441-5211", coverage:"MS Gulf Coast, Ship Island, Cat Island, Biloxi Sound" },
              { label:"Emergency (all areas)", phone:"VHF Ch 16 or 911", coverage:"Any emergency on water" },
            ].map((c,i)=>(
              <div key={i} style={{ marginBottom: i < 2 ? 10 : 0, paddingBottom: i < 2 ? 10 : 0, borderBottom: i < 2 ? "1px solid rgba(255,255,255,0.06)" : "none" }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
                  <div>
                    <div style={{ fontSize:12, color:"#fff", fontWeight:700 }}>{c.label}</div>
                    <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)", marginTop:2, lineHeight:1.4 }}>{c.coverage}</div>
                  </div>
                  <a href={`tel:${c.phone.replace(/\D/g,"")}`} style={{ fontSize:12, color:"#f87171", fontWeight:700, textDecoration:"none", flexShrink:0, marginLeft:8 }}>{c.phone}</a>
                </div>
              </div>
            ))}
          </div>

          {/* Channel guide */}
          <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
            {VHF_CHANNELS.map(ch=>(
              <div key={ch.ch} style={{ background:`${ch.color}08`, border:`1px solid ${ch.color}33`, borderRadius:16, padding:"14px 16px", display:"flex", gap:12, alignItems:"flex-start" }}>
                <div style={{ width:44, height:44, borderRadius:14, background:`${ch.color}18`, border:`1.5px solid ${ch.color}44`, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                  <span style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:14, color:ch.color }}>{ch.ch}</span>
                </div>
                <div style={{ flex:1 }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
                    <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:14, color:"#fff", letterSpacing:0.3 }}>{ch.name}</div>
                    {ch.critical && <span style={{ fontSize:9, fontWeight:700, padding:"2px 7px", borderRadius:8, background:"rgba(248,113,113,0.15)", color:"#f87171", border:"1px solid rgba(248,113,113,0.3)" }}>MONITOR</span>}
                  </div>
                  <div style={{ fontSize:12, color:"rgba(255,255,255,0.5)", lineHeight:1.55 }}>{ch.desc}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Tips */}
          <div style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:16, padding:"14px 16px", marginTop:14 }}>
            <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:10 }}>💡 VHF Radio Tips</div>
            {[
              "Always identify your vessel name when calling — required by FCC",
              "Keep transmissions short — 3 minutes max, then wait before retransmitting",
              "Use low power (1W) for short range, high power (25W) for emergencies",
              "Handheld VHF range is ~5 miles. Fixed-mount is better for offshore trips",
              "Recomended radio: Standard Horizon HX40 or Uniden MHS75 (~$100–130)",
              "File a float plan before every trip and check in when you return",
            ].map((t,i)=>(
              <div key={i} style={{ display:"flex", gap:8, marginBottom:8, alignItems:"flex-start" }}>
                <span style={{ color:"#38bdf8", fontSize:12, flexShrink:0 }}>•</span>
                <span style={{ fontSize:12, color:"rgba(255,255,255,0.55)", lineHeight:1.5 }}>{t}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── MARINAS ── */}
      {tab==="marinas" && (
        <div>
          {/* Filter by dest */}
          <div style={{ marginBottom:12 }}>
            <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:1, marginBottom:8 }}>Filter by Destination</div>
            <div style={{ display:"flex", gap:6, overflowX:"auto", paddingBottom:4 }}>
              <button onClick={()=>setMarinaFilter(null)} style={{ flexShrink:0, padding:"7px 14px", borderRadius:16, border:`1.5px solid ${!marinaFilter?"#38bdf888":"rgba(255,255,255,0.08)"}`, background:!marinaFilter?"rgba(56,189,248,0.12)":"rgba(255,255,255,0.04)", color:!marinaFilter?"#38bdf8":"rgba(255,255,255,0.4)", fontSize:11, fontWeight:700, cursor:"pointer" }}>⚓ All</button>
              {destinations.map(d=>(
                <button key={d.id} onClick={()=>setMarinaFilter(d)} style={{ flexShrink:0, padding:"7px 12px", borderRadius:16, border:`1.5px solid ${marinaFilter?.id===d.id?d.color+"88":"rgba(255,255,255,0.08)"}`, background:marinaFilter?.id===d.id?`${d.color}18`:"rgba(255,255,255,0.04)", color:marinaFilter?.id===d.id?d.color:"rgba(255,255,255,0.4)", fontSize:11, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap" }}>{d.emoji}</button>
              ))}
            </div>
          </div>

          <div style={{ fontSize:11, color:"rgba(255,255,255,0.3)", marginBottom:12 }}>{filteredMarinas.length} marina{filteredMarinas.length!==1?"s":""} shown</div>

          <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
            {filteredMarinas.map(m=>(
              <div key={m.id} style={{ background:`${m.color}08`, border:`1.5px solid ${m.color}33`, borderRadius:18, padding:"14px 16px" }}>
                <div style={{ display:"flex", gap:10, alignItems:"flex-start", marginBottom:10 }}>
                  <div style={{ width:42, height:42, borderRadius:13, background:`${m.color}18`, border:`1.5px solid ${m.color}44`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:20, flexShrink:0 }}>{m.emoji}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:15, color:"#fff", letterSpacing:0.3, lineHeight:1.2 }}>{m.name}</div>
                    <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)", marginTop:2 }}>{m.area}</div>
                  </div>
                  {m.phone !== "—" && (
                    <a href={`tel:${m.phone.replace(/\D/g,"")}`} style={{ fontSize:11, color:"#4ade80", fontWeight:700, textDecoration:"none", flexShrink:0 }}>{m.phone}</a>
                  )}
                </div>

                {/* Amenity badges */}
                <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom:10 }}>
                  <AmenityBadge label="⛽ Fuel"  active={m.fuel}  color="#fbbf24"/>
                  <AmenityBadge label="🦐 Bait"  active={m.bait}  color="#4ade80"/>
                  <AmenityBadge label="🚤 Ramp"  active={m.ramp}  color="#38bdf8"/>
                  <AmenityBadge label="🛥 Slips" active={m.slips} color="#a78bfa"/>
                  <AmenityBadge label="🍔 Food"  active={m.food}  color="#fb923c"/>
                </div>

                <div style={{ fontSize:11, color:"rgba(255,255,255,0.5)", lineHeight:1.55, marginBottom:10 }}>{m.note}</div>

                {/* Destination tags */}
                <div style={{ display:"flex", gap:4, flexWrap:"wrap" }}>
                  {m.dist.map(id=>{
                    const d = destinations.find(x=>x.id===id);
                    return d ? <span key={id} title={d.name} style={{ fontSize:14 }}>{d.emoji}</span> : null;
                  })}
                </div>

                {/* Maps link */}
                <a href={`https://www.google.com/maps/search/${encodeURIComponent(m.name+" "+m.area)}`} target="_blank" rel="noopener noreferrer"
                  style={{ display:"flex", alignItems:"center", gap:6, marginTop:10, fontSize:12, color:m.color, fontWeight:700, textDecoration:"none" }}>
                  🗺️ Open in Maps
                </a>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── FLOAT PLAN GENERATOR ───────────────────────────────────
function FloatPlanScreen({ destinations }) {
  const now = new Date();
  const todayStr = now.toISOString().slice(0,10);
  const timeStr = now.toTimeString().slice(0,5);

  const [tripDate,    setTripDate]    = useState(todayStr);
  const [launchTime,  setLaunchTime]  = useState(timeStr);
  const [returnTime,  setReturnTime]  = useState("17:00");
  const [dest,        setDest]        = useState(destinations[0]);
  const [riderName,   setRiderName]   = useState("");
  const [riderPhone,  setRiderPhone]  = useState("");
  const [buddy2Name,  setBuddy2Name]  = useState("");
  const [buddy2Phone, setBuddy2Phone] = useState("");
  const [ski1Reg,     setSki1Reg]     = useState("");
  const [ski1Color,   setSki1Color]   = useState("");
  const [ski2Reg,     setSki2Reg]     = useState("");
  const [ski2Color,   setSki2Color]   = useState("");
  const [contactName, setContactName] = useState("");
  const [contactPhone,setContactPhone]= useState("");
  const [notes,       setNotes]       = useState("");
  const [generated,   setGenerated]   = useState(false);
  const [savedPlans,  setSavedPlans]  = useState([]);
  const [view,        setView]        = useState("form"); // form | preview | saved

  const fmtDate = (d) => new Date(d+"T12:00:00").toLocaleDateString("en-US",{weekday:"long",month:"long",day:"numeric",year:"numeric"});
  const fmtTime12 = (t) => { const [h,m]=t.split(":").map(Number); const ap=h>=12?"PM":"AM"; return `${h%12||12}:${String(m).padStart(2,"0")} ${ap}`; };

  function generatePlan() {
    if (!riderName || !contactName || !contactPhone) return;
    setGenerated(true);
    setView("preview");
  }

  function savePlan() {
    const plan = {
      id: Date.now(),
      date: tripDate,
      dest: dest?.name,
      riderName,
      contactName,
      contactPhone,
      launchTime,
      returnTime,
      created: new Date().toLocaleString("en-US",{month:"short",day:"numeric",hour:"numeric",minute:"2-digit"}),
    };
    setSavedPlans(prev=>[plan,...prev].slice(0,10));
    setView("saved");
  }

  const InputRow = ({label, value, onChange, placeholder, type="text"}) => (
    <div style={{ marginBottom:12 }}>
      <div style={{ fontSize:10, color:"rgba(255,255,255,0.35)", textTransform:"uppercase", letterSpacing:0.7, marginBottom:6 }}>{label}</div>
      <input type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}
        style={{ width:"100%", background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:12, padding:"11px 14px", color:"#fff", fontSize:13, outline:"none", fontFamily:"'Barlow',sans-serif" }}/>
    </div>
  );

  return (
    <div style={{ padding:"0 16px 100px" }}>
      {/* Sub-nav */}
      <div style={{ display:"flex", gap:6, marginBottom:16 }}>
        {[["form","📝 Create"],["preview","👁 Preview"],["saved","📂 Saved"]].map(([v,l])=>(
          <button key={v} onClick={()=>setView(v)} style={{ flex:1, padding:"10px 4px", borderRadius:14, border:"none", cursor:"pointer", fontSize:11, fontWeight:700, background:view===v?"rgba(255,255,255,0.1)":"rgba(255,255,255,0.04)", color:view===v?"#fff":"rgba(255,255,255,0.35)", borderBottom:view===v?"2px solid #38bdf8":"2px solid transparent", transition:"all 0.15s" }}>{l}</button>
        ))}
      </div>

      {/* ── FORM ── */}
      {view==="form" && (
        <div>
          {/* What is a float plan callout */}
          <div style={{ background:"rgba(56,189,248,0.08)", border:"1px solid rgba(56,189,248,0.2)", borderRadius:14, padding:"12px 16px", marginBottom:18 }}>
            <div style={{ fontSize:12, color:"#38bdf8", fontWeight:700, marginBottom:4 }}>What is a Float Plan?</div>
            <div style={{ fontSize:11, color:"rgba(255,255,255,0.5)", lineHeight:1.6 }}>
              A float plan tells someone onshore where you're going, when you're leaving, when to expect you back, and who to call if you don't return. Text or email it to your contact before launching. The Coast Guard recommends this on every trip.
            </div>
          </div>

          {/* Trip info */}
          <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:18, padding:"16px", marginBottom:14 }}>
            <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:14, fontWeight:700 }}>📍 Trip Details</div>

            <div style={{ marginBottom:12 }}>
              <div style={{ fontSize:10, color:"rgba(255,255,255,0.35)", textTransform:"uppercase", letterSpacing:0.7, marginBottom:8 }}>Destination</div>
              <div style={{ display:"flex", gap:6, overflowX:"auto", paddingBottom:4 }}>
                {destinations.map(d=>(
                  <button key={d.id} onClick={()=>setDest(d)} style={{ flexShrink:0, padding:"7px 12px", borderRadius:14, border:`1.5px solid ${dest?.id===d.id?d.color+"88":"rgba(255,255,255,0.08)"}`, background:dest?.id===d.id?d.color+"18":"rgba(255,255,255,0.04)", color:dest?.id===d.id?d.color:"rgba(255,255,255,0.4)", fontSize:11, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap" }}>{d.emoji} {d.name.split(" ")[0]}</button>
                ))}
              </div>
            </div>

            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:12 }}>
              <div>
                <div style={{ fontSize:10, color:"rgba(255,255,255,0.35)", textTransform:"uppercase", letterSpacing:0.7, marginBottom:6 }}>Date</div>
                <input type="date" value={tripDate} onChange={e=>setTripDate(e.target.value)} style={{ width:"100%", background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:10, padding:"10px 10px", color:"#fff", fontSize:13, outline:"none", fontFamily:"'Barlow',sans-serif" }}/>
              </div>
              <div>
                <div style={{ fontSize:10, color:"rgba(255,255,255,0.35)", textTransform:"uppercase", letterSpacing:0.7, marginBottom:6 }}>Launch Time</div>
                <input type="time" value={launchTime} onChange={e=>setLaunchTime(e.target.value)} style={{ width:"100%", background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:10, padding:"10px 10px", color:"#fff", fontSize:13, outline:"none", fontFamily:"'Barlow',sans-serif" }}/>
              </div>
            </div>

            <div>
              <div style={{ fontSize:10, color:"rgba(255,255,255,0.35)", textTransform:"uppercase", letterSpacing:0.7, marginBottom:6 }}>Expected Return Time</div>
              <input type="time" value={returnTime} onChange={e=>setReturnTime(e.target.value)} style={{ width:"100%", background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:10, padding:"10px 10px", color:"#fff", fontSize:13, outline:"none", fontFamily:"'Barlow',sans-serif" }}/>
            </div>
          </div>

          {/* Riders */}
          <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:18, padding:"16px", marginBottom:14 }}>
            <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:14, fontWeight:700 }}>🏄 Riders</div>
            <InputRow label="Rider 1 Name *" value={riderName} onChange={setRiderName} placeholder="Your full name"/>
            <InputRow label="Rider 1 Phone" value={riderPhone} onChange={setRiderPhone} placeholder="(555) 555-5555" type="tel"/>
            <InputRow label="Rider 2 Name" value={buddy2Name} onChange={setBuddy2Name} placeholder="Riding buddy (optional)"/>
            <InputRow label="Rider 2 Phone" value={buddy2Phone} onChange={setBuddy2Phone} placeholder="(555) 555-5555" type="tel"/>
          </div>

          {/* Vessels */}
          <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:18, padding:"16px", marginBottom:14 }}>
            <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:14, fontWeight:700 }}>🚤 Vessels</div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:10 }}>
              <div>
                <div style={{ fontSize:10, color:"rgba(255,255,255,0.35)", textTransform:"uppercase", letterSpacing:0.7, marginBottom:6 }}>Ski 1 Registration</div>
                <input value={ski1Reg} onChange={e=>setSki1Reg(e.target.value)} placeholder="LA-1234-AB" style={{ width:"100%", background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:10, padding:"10px 10px", color:"#fff", fontSize:13, outline:"none", fontFamily:"'Barlow',sans-serif" }}/>
              </div>
              <div>
                <div style={{ fontSize:10, color:"rgba(255,255,255,0.35)", textTransform:"uppercase", letterSpacing:0.7, marginBottom:6 }}>Ski 1 Color</div>
                <input value={ski1Color} onChange={e=>setSki1Color(e.target.value)} placeholder="e.g. Black/Red" style={{ width:"100%", background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:10, padding:"10px 10px", color:"#fff", fontSize:13, outline:"none", fontFamily:"'Barlow',sans-serif" }}/>
              </div>
            </div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
              <div>
                <div style={{ fontSize:10, color:"rgba(255,255,255,0.35)", textTransform:"uppercase", letterSpacing:0.7, marginBottom:6 }}>Ski 2 Registration</div>
                <input value={ski2Reg} onChange={e=>setSki2Reg(e.target.value)} placeholder="LA-5678-CD" style={{ width:"100%", background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:10, padding:"10px 10px", color:"#fff", fontSize:13, outline:"none", fontFamily:"'Barlow',sans-serif" }}/>
              </div>
              <div>
                <div style={{ fontSize:10, color:"rgba(255,255,255,0.35)", textTransform:"uppercase", letterSpacing:0.7, marginBottom:6 }}>Ski 2 Color</div>
                <input value={ski2Color} onChange={e=>setSki2Color(e.target.value)} placeholder="e.g. White/Blue" style={{ width:"100%", background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:10, padding:"10px 10px", color:"#fff", fontSize:13, outline:"none", fontFamily:"'Barlow',sans-serif" }}/>
              </div>
            </div>
          </div>

          {/* Emergency contact */}
          <div style={{ background:"rgba(248,113,113,0.06)", border:"1px solid rgba(248,113,113,0.2)", borderRadius:18, padding:"16px", marginBottom:14 }}>
            <div style={{ fontSize:11, color:"#f87171", textTransform:"uppercase", letterSpacing:0.8, marginBottom:14, fontWeight:700 }}>🚨 Onshore Contact *</div>
            <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)", marginBottom:12, lineHeight:1.5 }}>This person must be reachable. They call the Coast Guard if you don't return by your expected time.</div>
            <InputRow label="Contact Name *" value={contactName} onChange={setContactName} placeholder="Who to call if you don't return"/>
            <InputRow label="Contact Phone *" value={contactPhone} onChange={setContactPhone} placeholder="(555) 555-5555" type="tel"/>
          </div>

          {/* Notes */}
          <div style={{ marginBottom:18 }}>
            <div style={{ fontSize:10, color:"rgba(255,255,255,0.35)", textTransform:"uppercase", letterSpacing:0.7, marginBottom:6 }}>📝 Additional Notes</div>
            <textarea value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Planned route, known hazards, special equipment, medical conditions..." rows={3}
              style={{ width:"100%", background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:12, padding:"11px 14px", color:"#fff", fontSize:13, outline:"none", resize:"none", fontFamily:"'Barlow',sans-serif" }}/>
          </div>

          <button
            onClick={generatePlan}
            disabled={!riderName||!contactName||!contactPhone}
            style={{ width:"100%", padding:"16px", borderRadius:18, border:"none",
              background:riderName&&contactName&&contactPhone?"linear-gradient(135deg,#38bdf8,#818cf8)":"rgba(255,255,255,0.08)",
              color:riderName&&contactName&&contactPhone?"#060c14":"rgba(255,255,255,0.3)",
              fontSize:14, fontWeight:700, cursor:riderName&&contactName&&contactPhone?"pointer":"default",
              letterSpacing:0.5, transition:"all 0.2s"
            }}>
            📋 Generate Float Plan
          </button>
        </div>
      )}

      {/* ── PREVIEW ── */}
      {view==="preview" && (
        <div>
          {!generated ? (
            <div style={{ textAlign:"center", padding:"40px 20px" }}>
              <div style={{ fontSize:40, marginBottom:12 }}>📋</div>
              <div style={{ fontSize:14, color:"rgba(255,255,255,0.4)", marginBottom:16 }}>Fill out the form first</div>
              <button onClick={()=>setView("form")} style={{ padding:"12px 24px", borderRadius:16, border:"none", background:"#38bdf8", color:"#060c14", fontSize:13, fontWeight:700, cursor:"pointer" }}>← Go to Form</button>
            </div>
          ) : (
            <div>
              {/* The actual float plan card */}
              <div style={{ background:"#fff", borderRadius:18, padding:"20px", marginBottom:14, color:"#111" }}>
                {/* Header */}
                <div style={{ textAlign:"center", borderBottom:"2px solid #111", paddingBottom:12, marginBottom:16 }}>
                  <div style={{ fontSize:11, letterSpacing:2, textTransform:"uppercase", color:"#666", marginBottom:4 }}>USCG RECOMMENDED</div>
                  <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:24, letterSpacing:1, color:"#111" }}>FLOAT PLAN</div>
                  <div style={{ fontSize:11, color:"#888", marginTop:4 }}>PWC Pro · Generated {new Date().toLocaleString("en-US",{month:"short",day:"numeric",year:"numeric",hour:"numeric",minute:"2-digit"})}</div>
                </div>

                {/* Trip */}
                <Section title="TRIP INFORMATION" color="#1d4ed8">
                  <Row label="Destination" value={`${dest?.emoji} ${dest?.name} — ${dest?.subtitle}`}/>
                  <Row label="Launch Ramp" value={dest?.launch?.split(",").slice(0,2).join(",")}/>
                  <Row label="Date" value={fmtDate(tripDate)}/>
                  <Row label="Departure" value={fmtTime12(launchTime)}/>
                  <Row label="Expected Return" value={fmtTime12(returnTime)}/>
                  <Row label="Overdue — Call CG At" value={(() => {
                    const [h,m] = returnTime.split(":").map(Number);
                    const d = new Date(); d.setHours(h,m+60,0,0);
                    return fmtTime12(`${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}`);
                  })()} highlight/>
                </Section>

                {/* Riders */}
                <Section title="PERSONS ABOARD" color="#059669">
                  <Row label="Rider 1" value={`${riderName}${riderPhone?" · "+riderPhone:""}`}/>
                  {buddy2Name && <Row label="Rider 2" value={`${buddy2Name}${buddy2Phone?" · "+buddy2Phone:""}`}/>}
                </Section>

                {/* Vessels */}
                <Section title="VESSELS" color="#7c3aed">
                  {ski1Reg && <Row label="Ski 1" value={`Reg: ${ski1Reg}${ski1Color?" · "+ski1Color:""}`}/>}
                  {ski2Reg && <Row label="Ski 2" value={`Reg: ${ski2Reg}${ski2Color?" · "+ski2Color:""}`}/>}
                  {!ski1Reg && !ski2Reg && <Row label="Vessels" value="No registration numbers entered"/>}
                </Section>

                {/* Emergency */}
                <Section title="EMERGENCY CONTACT" color="#dc2626">
                  <Row label="Contact" value={contactName} highlight/>
                  <Row label="Phone" value={contactPhone} highlight/>
                  <Row label="Coast Guard" value="VHF Ch 16 · (504) 589-6225 · 911"/>
                </Section>

                {notes && (
                  <Section title="NOTES" color="#92400e">
                    <div style={{ fontSize:12, color:"#333", lineHeight:1.6 }}>{notes}</div>
                  </Section>
                )}

                {/* Instructions to contact */}
                <div style={{ background:"#fef3c7", border:"1px solid #f59e0b", borderRadius:10, padding:"10px 14px", marginTop:12 }}>
                  <div style={{ fontSize:11, fontWeight:700, color:"#92400e", marginBottom:4 }}>Instructions for {contactName}:</div>
                  <div style={{ fontSize:11, color:"#78350f", lineHeight:1.6 }}>
                    If I have not contacted you by <strong>{fmtTime12(returnTime)}</strong>, wait 1 hour then call the US Coast Guard at <strong>(504) 589-6225</strong> or VHF Channel 16, or call 911. Provide them this float plan.
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div style={{ display:"flex", gap:10, marginBottom:14 }}>
                <button onClick={savePlan} style={{ flex:1, padding:"14px", borderRadius:16, border:"none", background:"linear-gradient(135deg,#4ade80,#22c55e)", color:"#060c14", fontSize:13, fontWeight:700, cursor:"pointer" }}>
                  💾 Save Plan
                </button>
                <button onClick={()=>setView("form")} style={{ flex:1, padding:"14px", borderRadius:16, border:"1px solid rgba(255,255,255,0.15)", background:"rgba(255,255,255,0.06)", color:"rgba(255,255,255,0.7)", fontSize:13, fontWeight:700, cursor:"pointer" }}>
                  ✏️ Edit
                </button>
              </div>

              <div style={{ background:"rgba(56,189,248,0.08)", border:"1px solid rgba(56,189,248,0.2)", borderRadius:14, padding:"12px 16px", textAlign:"center" }}>
                <div style={{ fontSize:12, color:"#38bdf8", fontWeight:700, marginBottom:4 }}>📤 Share This Plan</div>
                <div style={{ fontSize:11, color:"rgba(255,255,255,0.5)", lineHeight:1.5 }}>
                  Screenshot this plan and text it to <strong style={{ color:"#fff" }}>{contactName || "your contact"}</strong> before you launch. They need it on their phone, not yours.
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── SAVED PLANS ── */}
      {view==="saved" && (
        <div>
          {savedPlans.length === 0 ? (
            <div style={{ textAlign:"center", padding:"40px 20px" }}>
              <div style={{ fontSize:40, marginBottom:12 }}>📂</div>
              <div style={{ fontSize:14, color:"rgba(255,255,255,0.4)", marginBottom:16 }}>No saved float plans yet</div>
              <button onClick={()=>setView("form")} style={{ padding:"12px 24px", borderRadius:16, border:"none", background:"#38bdf8", color:"#060c14", fontSize:13, fontWeight:700, cursor:"pointer" }}>Create First Plan</button>
            </div>
          ) : (
            <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
              <div style={{ fontSize:11, color:"rgba(255,255,255,0.3)", marginBottom:4 }}>Last {savedPlans.length} float plan{savedPlans.length>1?"s":""}</div>
              {savedPlans.map(p=>(
                <div key={p.id} style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:16, padding:"14px 16px" }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:8 }}>
                    <div>
                      <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:15, color:"#fff" }}>{p.dest}</div>
                      <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)", marginTop:2 }}>{fmtDate(p.date)}</div>
                    </div>
                    <div style={{ fontSize:10, color:"rgba(255,255,255,0.25)" }}>Created {p.created}</div>
                  </div>
                  <div style={{ display:"flex", gap:8, fontSize:11, color:"rgba(255,255,255,0.5)" }}>
                    <span>🚗 Launch {fmtTime12(p.launchTime)}</span>
                    <span>·</span>
                    <span>🏠 Return {fmtTime12(p.returnTime)}</span>
                  </div>
                  <div style={{ marginTop:8, fontSize:11, color:"rgba(255,255,255,0.4)" }}>
                    Contact: <span style={{ color:"#f87171", fontWeight:700 }}>{p.contactName} · {p.contactPhone}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// Float plan sub-components
function Section({ title, color, children }) {
  return (
    <div style={{ marginBottom:14 }}>
      <div style={{ fontSize:10, fontWeight:700, letterSpacing:1, textTransform:"uppercase", color, borderBottom:`2px solid ${color}`, paddingBottom:4, marginBottom:8 }}>{title}</div>
      {children}
    </div>
  );
}

function Row({ label, value, highlight }) {
  return (
    <div style={{ display:"flex", gap:8, marginBottom:5, alignItems:"flex-start" }}>
      <span style={{ fontSize:11, color:"#666", minWidth:110, flexShrink:0 }}>{label}:</span>
      <span style={{ fontSize:11, color: highlight?"#dc2626":"#111", fontWeight:highlight?700:400, lineHeight:1.4 }}>{value||"—"}</span>
    </div>
  );
}

// ─── DISTRESS / SOS SCREEN ──────────────────────────────────
function SOSScreen() {
  const [coords, setCoords] = useState(null);
  const [coordsLoading, setCoordsLoading] = useState(false);
  const [coordsError, setCoordsError] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  function getCoords() {
    setCoordsLoading(true); setCoordsError(false);
    navigator.geolocation.getCurrentPosition(
      pos => { setCoords({ lat:pos.coords.latitude.toFixed(5), lon:pos.coords.longitude.toFixed(5), acc:Math.round(pos.coords.accuracy) }); setCoordsLoading(false); },
      () => { setCoordsError(true); setCoordsLoading(false); },
      { enableHighAccuracy:true, timeout:10000 }
    );
  }

  return (
    <div style={{ padding:"0 16px 100px" }}>
      {/* Big red SOS header */}
      <div style={{ background:"linear-gradient(135deg,#3b0000,#1a0000)", border:"2px solid #ef4444", borderRadius:22, padding:"20px", marginBottom:16, textAlign:"center" }}>
        <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:48, color:"#ef4444", letterSpacing:3, lineHeight:1, marginBottom:6 }}>🚨 SOS</div>
        <div style={{ fontSize:13, color:"rgba(255,255,255,0.6)", marginBottom:10 }}>Emergency Quick Reference</div>
        <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:20, color:"rgba(255,255,255,0.9)" }}>
          {currentTime.toLocaleTimeString("en-US",{hour:"numeric",minute:"2-digit",second:"2-digit",hour12:true})}
        </div>
        <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)", marginTop:2 }}>
          {currentTime.toLocaleDateString("en-US",{weekday:"long",month:"long",day:"numeric"})}
        </div>
      </div>

      {/* Call CG */}
      <div style={{ background:"#3b0000", border:"2px solid #ef444488", borderRadius:18, padding:"16px", marginBottom:14 }}>
        <div style={{ fontSize:11, color:"#f87171", textTransform:"uppercase", letterSpacing:1, fontWeight:700, marginBottom:12 }}>📻 Call Coast Guard — VHF Channel 16</div>
        <div style={{ display:"flex", gap:10, marginBottom:10 }}>
          <a href="tel:15045896225" style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", gap:6, background:"rgba(239,68,68,0.2)", border:"1.5px solid rgba(239,68,68,0.5)", borderRadius:14, padding:"14px 8px", textDecoration:"none" }}>
            <span style={{ fontSize:24 }}>📞</span>
            <span style={{ fontSize:11, color:"#f87171", fontWeight:700, textAlign:"center" }}>New Orleans CG</span>
            <span style={{ fontSize:12, color:"#fff", fontWeight:700 }}>(504) 589-6225</span>
          </a>
          <a href="tel:12514415211" style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", gap:6, background:"rgba(239,68,68,0.2)", border:"1.5px solid rgba(239,68,68,0.5)", borderRadius:14, padding:"14px 8px", textDecoration:"none" }}>
            <span style={{ fontSize:24 }}>📞</span>
            <span style={{ fontSize:11, color:"#f87171", fontWeight:700, textAlign:"center" }}>Mobile CG</span>
            <span style={{ fontSize:12, color:"#fff", fontWeight:700 }}>(251) 441-5211</span>
          </a>
        </div>
        <a href="tel:911" style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:10, background:"rgba(239,68,68,0.25)", border:"1.5px solid #ef4444", borderRadius:14, padding:"14px", textDecoration:"none" }}>
          <span style={{ fontSize:24 }}>🆘</span>
          <span style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:24, color:"#ef4444", letterSpacing:1 }}>CALL 911</span>
        </a>
      </div>

      {/* GPS */}
      <div style={{ background:"rgba(56,189,248,0.08)", border:"1.5px solid rgba(56,189,248,0.3)", borderRadius:18, padding:"16px", marginBottom:14 }}>
        <div style={{ fontSize:11, color:"#38bdf8", textTransform:"uppercase", letterSpacing:0.8, fontWeight:700, marginBottom:12 }}>📍 Your GPS Position</div>
        {!coords && !coordsLoading && !coordsError && (
          <button onClick={getCoords} style={{ width:"100%", padding:"14px", borderRadius:14, border:"1.5px solid rgba(56,189,248,0.5)", background:"rgba(56,189,248,0.15)", color:"#38bdf8", fontSize:14, fontWeight:700, cursor:"pointer" }}>
            📍 Get My Coordinates Now
          </button>
        )}
        {coordsLoading && <div style={{ textAlign:"center", padding:"14px", fontSize:13, color:"rgba(255,255,255,0.5)", animation:"pulse 1.5s infinite" }}>⏳ Getting GPS fix...</div>}
        {coordsError && (
          <div style={{ textAlign:"center", padding:"10px 0" }}>
            <div style={{ fontSize:12, color:"#f87171", marginBottom:8 }}>⚠️ Could not get GPS — enable location on your phone</div>
            <button onClick={getCoords} style={{ padding:"10px 20px", borderRadius:12, border:"none", background:"rgba(56,189,248,0.15)", color:"#38bdf8", fontSize:12, fontWeight:700, cursor:"pointer" }}>Try Again</button>
          </div>
        )}
        {coords && (
          <div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:10 }}>
              <div style={{ background:"rgba(255,255,255,0.05)", borderRadius:12, padding:"12px" }}>
                <div style={{ fontSize:9, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.5, marginBottom:4 }}>Latitude</div>
                <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:20, color:"#38bdf8" }}>{coords.lat}°N</div>
              </div>
              <div style={{ background:"rgba(255,255,255,0.05)", borderRadius:12, padding:"12px" }}>
                <div style={{ fontSize:9, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.5, marginBottom:4 }}>Longitude</div>
                <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:20, color:"#38bdf8" }}>{Math.abs(coords.lon)}°W</div>
              </div>
            </div>
            <div style={{ background:"rgba(74,222,128,0.08)", border:"1px solid rgba(74,222,128,0.2)", borderRadius:10, padding:"8px 14px", marginBottom:10, display:"flex", justifyContent:"space-between" }}>
              <span style={{ fontSize:11, color:"rgba(255,255,255,0.5)" }}>Accuracy: ±{coords.acc}m</span>
              <button onClick={getCoords} style={{ fontSize:11, color:"#4ade80", background:"none", border:"none", cursor:"pointer", fontWeight:700 }}>🔄 Refresh</button>
            </div>
            <div style={{ background:"rgba(255,255,255,0.04)", borderRadius:10, padding:"10px 12px" }}>
              <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", marginBottom:4 }}>Say on VHF Channel 16:</div>
              <div style={{ fontSize:12, color:"rgba(255,255,255,0.7)", lineHeight:1.6, fontStyle:"italic" }}>
                "My position is <strong style={{ color:"#38bdf8" }}>{coords.lat} North, {Math.abs(coords.lon)} West</strong>"
              </div>
            </div>
          </div>
        )}
      </div>

      {/* MAYDAY script */}
      <div style={{ background:"rgba(167,139,250,0.08)", border:"1.5px solid rgba(167,139,250,0.25)", borderRadius:18, padding:"16px", marginBottom:14 }}>
        <div style={{ fontSize:11, color:"#a78bfa", textTransform:"uppercase", letterSpacing:0.8, fontWeight:700, marginBottom:12 }}>📢 MAYDAY Script — Read This Aloud on Ch 16</div>
        <div style={{ background:"rgba(0,0,0,0.3)", borderRadius:12, padding:"14px", marginBottom:10 }}>
          {[
            ["MAYDAY  MAYDAY  MAYDAY", "#f87171", true],
            [`"This is a PWC in distress"`, "#fff", false],
            [coords?`"My position is ${coords.lat} North, ${Math.abs(coords.lon)} West"`:`"My position is [YOUR LOCATION OR NEAREST LANDMARK]"`, "#38bdf8", false],
            [`"I need immediate assistance"`, "#fff", false],
            [`"[Describe emergency — sinking / fire / injury / person overboard]"`, "#fbbf24", false],
            [`"Number of persons aboard: [STATE NUMBER]"`, "#fff", false],
            [`"MAYDAY — PWC in distress — Over"`, "#f87171", true],
          ].map(([line,color,bold],i)=>(
            <div key={i} style={{ fontSize:13, color, fontWeight:bold?700:400, lineHeight:1.8, fontFamily:bold?"'Black Han Sans',sans-serif":"'Barlow',sans-serif", letterSpacing:bold?1:0 }}>{line}</div>
          ))}
        </div>
        <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", lineHeight:1.5 }}>
          Wait 10 seconds after transmitting. Repeat if no response. Switch to Ch 22A when Coast Guard responds.
        </div>
      </div>

      {/* Visual signals */}
      <div style={{ background:"rgba(251,191,36,0.06)", border:"1px solid rgba(251,191,36,0.2)", borderRadius:18, padding:"16px", marginBottom:14 }}>
        <div style={{ fontSize:11, color:"#fbbf24", textTransform:"uppercase", letterSpacing:0.8, fontWeight:700, marginBottom:12 }}>🔦 Visual Distress Signals</div>
        {[
          ["🔴","Flares","Fire 3 flares — the universal distress signal. Use at night or low visibility."],
          ["🤚","Wave Both Arms","Stand on the ski, wave both arms overhead slowly. International distress gesture."],
          ["🧲","Stay With the Ski","A jet ski is far easier to spot than a person in water. Do not abandon it."],
          ["🔦","Phone Flashlight","Flash SOS: 3 short · 3 long · 3 short. Repeat toward any vessel or aircraft."],
          ["🪞","Mirror Signal","Phone screen or any reflective surface angled toward rescuers."],
        ].map(([icon,title,desc],i)=>(
          <div key={i} style={{ display:"flex", gap:10, alignItems:"flex-start", marginBottom:i<4?12:0, paddingBottom:i<4?12:0, borderBottom:i<4?"1px solid rgba(255,255,255,0.05)":"none" }}>
            <span style={{ fontSize:22, flexShrink:0 }}>{icon}</span>
            <div>
              <div style={{ fontSize:13, color:"#fff", fontWeight:700, marginBottom:3 }}>{title}</div>
              <div style={{ fontSize:11, color:"rgba(255,255,255,0.5)", lineHeight:1.55 }}>{desc}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Ordered steps */}
      <div style={{ background:"rgba(74,222,128,0.06)", border:"1px solid rgba(74,222,128,0.15)", borderRadius:18, padding:"16px" }}>
        <div style={{ fontSize:11, color:"#4ade80", textTransform:"uppercase", letterSpacing:0.8, fontWeight:700, marginBottom:12 }}>✅ Emergency Steps — In Order</div>
        {[
          "PUT ON YOUR PFD if not already wearing it",
          "Stay calm — panic kills faster than the emergency itself",
          "Stay with the ski — it floats and rescuers can see it",
          "Tap GPS above to get your exact coordinates",
          "Transmit MAYDAY on VHF Channel 16",
          "If no radio — call 911 if you have any cell signal",
          "Signal visually — flares, arm waves, phone flash",
          "Your float plan contact knows where you are — stay put",
        ].map((step,i)=>(
          <div key={i} style={{ display:"flex", gap:10, alignItems:"flex-start", marginBottom:10 }}>
            <div style={{ width:22, height:22, borderRadius:8, background:"rgba(74,222,128,0.15)", border:"1px solid rgba(74,222,128,0.3)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:10, color:"#4ade80", fontWeight:700, flexShrink:0 }}>{i+1}</div>
            <span style={{ fontSize:12, color:"rgba(255,255,255,0.65)", lineHeight:1.55 }}>{step}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── PRE-TRIP GO/NO-GO CHECKLIST ────────────────────────────

const PRETRIP_SECTIONS = [
  {
    id:"weather", label:"Weather", icon:"🌤️", color:"#38bdf8",
    items:[
      {id:"w1", text:"Checked NOAA marine forecast today",          critical:true},
      {id:"w2", text:"Wind is acceptable for this destination",     critical:true},
      {id:"w3", text:"No thunderstorms in forecast",                critical:true},
      {id:"w4", text:"Checked radar — no active cells nearby",      critical:false},
      {id:"w5", text:"Sunset time noted for Leave By calculator",    critical:false},
    ]
  },
  {
    id:"safety", label:"Safety Gear", icon:"🦺", color:"#f87171",
    items:[
      {id:"s1", text:"PFD on every rider — worn, not just onboard", critical:true},
      {id:"s2", text:"Kill switch lanyard attached to operator",     critical:true},
      {id:"s3", text:"Fire extinguisher present and charged",        critical:true},
      {id:"s4", text:"VHF radio charged and on Channel 16",          critical:true},
      {id:"s5", text:"First aid kit onboard",                        critical:false},
      {id:"s6", text:"Visual distress signals / flares onboard",     critical:false},
    ]
  },
  {
    id:"fuel", label:"Fuel & Range", icon:"⛽", color:"#fbbf24",
    items:[
      {id:"f1", text:"Tank is full",                                  critical:true},
      {id:"f2", text:"Fuel calculator checked — range is sufficient", critical:true},
      {id:"f3", text:"Extra fuel can packed if needed",               critical:false},
      {id:"f4", text:"Nearest fuel dock on route identified",         critical:false},
    ]
  },
  {
    id:"nav", label:"Navigation", icon:"🗺️", color:"#a78bfa",
    items:[
      {id:"n1", text:"Offline maps downloaded in Navionics",          critical:true},
      {id:"n2", text:"Destination coordinates saved to GPS",           critical:false},
      {id:"n3", text:"Launch ramp location confirmed in Maps",         critical:false},
      {id:"n4", text:"Return route planned",                           critical:false},
    ]
  },
  {
    id:"legal", label:"Permits & Legal", icon:"📋", color:"#86efac",
    items:[
      {id:"l1", text:"Vessel registration on board each ski",          critical:true},
      {id:"l2", text:"NASBLA boating cert accessible",                 critical:true},
      {id:"l3", text:"Fishing license (if fishing today)",             critical:false},
      {id:"l4", text:"WMA permit (if entering WMA waters)",            critical:false},
      {id:"l5", text:"MS fishing license (if crossing into MS)",       critical:false},
    ]
  },
  {
    id:"float", label:"Float Plan", icon:"📋", color:"#fb923c",
    items:[
      {id:"fp1", text:"Float plan created in app today",               critical:true},
      {id:"fp2", text:"Float plan texted to onshore contact",          critical:true},
      {id:"fp3", text:"Contact knows exact expected return time",       critical:true},
      {id:"fp4", text:"Contact has Coast Guard number saved",           critical:false},
    ]
  },
  {
    id:"buddy", label:"Riding Buddy", icon:"🤝", color:"#22d3ee",
    items:[
      {id:"b1", text:"Not riding alone (required for advanced trips)", critical:false},
      {id:"b2", text:"Buddy ski fueled and ready",                     critical:false},
      {id:"b3", text:"Buddy has working phone or radio",               critical:false},
      {id:"b4", text:"Both riders know the return plan",               critical:false},
    ]
  },
];

function PreTripScreen({ destinations }) {
  const [dest, setDest] = useState(destinations[0]);
  const [checked, setChecked] = useState(new Set());
  const [showResult, setShowResult] = useState(false);

  const toggle = id => setChecked(prev => {
    const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n;
  });

  const reset = () => { setChecked(new Set()); setShowResult(false); };

  // Score calculation
  const allItems = PRETRIP_SECTIONS.flatMap(s => s.items);
  const criticalItems = allItems.filter(i => i.critical);
  const checkedCritical = criticalItems.filter(i => checked.has(i.id));
  const totalChecked = allItems.filter(i => checked.has(i.id)).length;

  // Advanced/moderate trips require buddy
  const requiresBuddy = dest?.level === "advanced" || dest?.level === "moderate";
  const buddyChecked = checked.has("b1");
  const buddyFail = requiresBuddy && !buddyChecked;

  const missingCritical = criticalItems.filter(i => !checked.has(i.id));
  const allCriticalDone = missingCritical.length === 0;
  const isGO = allCriticalDone && !buddyFail;
  const pct = Math.round((totalChecked / allItems.length) * 100);

  const LEVEL = {
    easy:     { label:"Easy",     dot:"🟢", bg:"#052e16", border:"#16a34a", text:"#4ade80" },
    moderate: { label:"Moderate", dot:"🟡", bg:"#3b1d00", border:"#d97706", text:"#fcd34d" },
    advanced: { label:"Advanced", dot:"🔴", bg:"#3b0000", border:"#dc2626", text:"#f87171" },
  };
  const lv = LEVEL[dest?.level];

  return (
    <div style={{ padding:"0 16px 100px" }}>

      {/* Destination selector */}
      <div style={{ marginBottom:14 }}>
        <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:1, marginBottom:8 }}>🏝️ Today's Destination</div>
        <div style={{ display:"flex", gap:8, overflowX:"auto", paddingBottom:4, WebkitOverflowScrolling:"touch" }}>
          {destinations.map(d=>(
            <button key={d.id} onClick={()=>{setDest(d);setShowResult(false);}} style={{ flexShrink:0, padding:"8px 14px", borderRadius:16, border:`1.5px solid ${dest?.id===d.id?d.color+"88":"rgba(255,255,255,0.08)"}`, background:dest?.id===d.id?d.color+"18":"rgba(255,255,255,0.04)", color:dest?.id===d.id?d.color:"rgba(255,255,255,0.4)", fontSize:12, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap", transition:"all 0.15s" }}>{d.emoji} {d.name.split(" ")[0]}</button>
          ))}
        </div>
      </div>

      {/* Destination info strip */}
      <div style={{ background:`${dest?.color}10`, border:`1px solid ${dest?.color}33`, borderRadius:14, padding:"10px 14px", marginBottom:16, display:"flex", gap:10, alignItems:"center" }}>
        <span style={{ fontSize:22 }}>{dest?.emoji}</span>
        <div style={{ flex:1 }}>
          <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:15, color:"#fff" }}>{dest?.name}</div>
          <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)" }}>{dest?.subtitle}</div>
        </div>
        <span style={{ fontSize:11, fontWeight:700, padding:"3px 10px", borderRadius:20, background:lv?.bg, color:lv?.text, border:`1px solid ${lv?.border}` }}>{lv?.dot} {lv?.label}</span>
      </div>

      {/* Progress bar */}
      <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:14, padding:"12px 16px", marginBottom:14 }}>
        <div style={{ display:"flex", justifyContent:"space-between", marginBottom:8 }}>
          <span style={{ fontSize:11, color:"rgba(255,255,255,0.5)" }}>Preflight Progress</span>
          <span style={{ fontSize:12, fontWeight:700, color: pct===100?"#4ade80":pct>60?"#fbbf24":"#f87171" }}>{totalChecked}/{allItems.length} — {pct}%</span>
        </div>
        <div style={{ background:"rgba(255,255,255,0.07)", borderRadius:8, height:8, overflow:"hidden" }}>
          <div style={{ height:8, borderRadius:8, width:`${pct}%`, background: isGO?"linear-gradient(90deg,#4ade80,#22c55e)":"linear-gradient(90deg,#f87171,#fbbf24)", transition:"width 0.3s ease", boxShadow:isGO?"0 0 10px #4ade8055":"0 0 10px #f8717155" }}/>
        </div>
        {requiresBuddy && (
          <div style={{ marginTop:8, fontSize:11, color:buddyFail?"#f87171":"rgba(255,255,255,0.35)" }}>
            {buddyFail ? "⚠️ Advanced/Moderate trip — buddy required" : "✓ Buddy requirement acknowledged"}
          </div>
        )}
      </div>

      {/* Checklist sections */}
      {PRETRIP_SECTIONS.map(section => {
        const secChecked = section.items.filter(i => checked.has(i.id)).length;
        const secDone = secChecked === section.items.length;
        return (
          <div key={section.id} style={{ background:secDone?"linear-gradient(135deg,#071a0e,#050f08)":"linear-gradient(135deg,#0c1b2a,#08111c)", border:`1.5px solid ${secDone?"#16a34a55":section.color+"44"}`, borderRadius:18, overflow:"hidden", marginBottom:10 }}>
            {/* Section header */}
            <div style={{ padding:"12px 16px 10px", display:"flex", alignItems:"center", gap:10 }}>
              <div style={{ width:36, height:36, borderRadius:11, background:`${section.color}18`, border:`1.5px solid ${section.color}44`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:18, flexShrink:0 }}>
                {secDone ? "✅" : section.icon}
              </div>
              <div style={{ flex:1 }}>
                <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:15, color:"#fff", letterSpacing:0.3 }}>{section.label}</div>
                <div style={{ fontSize:11, color:secDone?"#4ade80":"rgba(255,255,255,0.35)", marginTop:1 }}>{secChecked}/{section.items.length} {secDone?"✓ complete":""}</div>
              </div>
              {/* Mini dot progress */}
              <div style={{ display:"flex", gap:3 }}>
                {section.items.map(item=>(
                  <div key={item.id} style={{ width:6, height:6, borderRadius:"50%", background:checked.has(item.id)?section.color:"rgba(255,255,255,0.1)", boxShadow:checked.has(item.id)?`0 0 4px ${section.color}`:"none" }}/>
                ))}
              </div>
            </div>
            {/* Items */}
            <div style={{ padding:"0 12px 12px", borderTop:`1px solid ${section.color}22` }}>
              {section.items.map(item => {
                const isCh = checked.has(item.id);
                return (
                  <div key={item.id} onClick={()=>toggle(item.id)} style={{ display:"flex", gap:10, alignItems:"center", padding:"10px 8px", borderRadius:12, cursor:"pointer", marginTop:4, background:isCh?`${section.color}0a`:"transparent", transition:"background 0.15s" }}>
                    <div style={{ width:24, height:24, borderRadius:8, flexShrink:0, background:isCh?section.color:"rgba(255,255,255,0.06)", border:`1.5px solid ${isCh?section.color:"rgba(255,255,255,0.12)"}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:12, color:"#000", fontWeight:700, boxShadow:isCh?`0 0 8px ${section.color}66`:"none", transition:"all 0.2s" }}>{isCh?"✓":""}</div>
                    <span style={{ fontSize:13, color:isCh?"rgba(255,255,255,0.4)":"rgba(255,255,255,0.75)", textDecoration:isCh?"line-through":"none", lineHeight:1.4, flex:1, transition:"all 0.2s" }}>{item.text}</span>
                    {item.critical && !isCh && (
                      <span style={{ fontSize:9, fontWeight:700, padding:"2px 6px", borderRadius:6, background:"rgba(239,68,68,0.15)", color:"#f87171", border:"1px solid rgba(239,68,68,0.3)", flexShrink:0 }}>REQ</span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}

      {/* GO / NO-GO result */}
      <div style={{ background:isGO?"linear-gradient(135deg,#052e16,#071a0e)":"linear-gradient(135deg,#3b0000,#1a0000)", border:`2px solid ${isGO?"#16a34a":"#dc2626"}`, borderRadius:22, padding:"20px", marginTop:6 }}>
        <div style={{ display:"flex", alignItems:"center", gap:14, marginBottom:isGO?0:14 }}>
          <div style={{ fontSize:48 }}>{isGO?"✅":"🚫"}</div>
          <div>
            <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:36, color:isGO?"#4ade80":"#f87171", letterSpacing:2, lineHeight:1 }}>{isGO?"GO":"NO GO"}</div>
            <div style={{ fontSize:12, color:"rgba(255,255,255,0.5)", marginTop:4 }}>
              {isGO ? `All critical items checked — safe to launch` : `${missingCritical.length + (buddyFail?1:0)} item${missingCritical.length+(buddyFail?1:0)>1?"s":""} need attention`}
            </div>
          </div>
        </div>

        {!isGO && (
          <div style={{ marginTop:4 }}>
            {[...missingCritical.map(i=>i.text), ...(buddyFail?["Riding buddy required for this trip level"]:[])]
              .map((issue,i)=>(
              <div key={i} style={{ display:"flex", gap:8, alignItems:"flex-start", background:"rgba(239,68,68,0.08)", borderLeft:"3px solid #ef4444", borderRadius:"0 8px 8px 0", padding:"8px 12px", marginBottom:6 }}>
                <span style={{ color:"#f87171", fontSize:12, flexShrink:0 }}>!</span>
                <span style={{ fontSize:12, color:"rgba(255,255,255,0.6)", lineHeight:1.5 }}>{issue}</span>
              </div>
            ))}
          </div>
        )}

        <button onClick={reset} style={{ width:"100%", marginTop:16, padding:"12px", borderRadius:14, border:`1px solid ${isGO?"rgba(74,222,128,0.3)":"rgba(239,68,68,0.3)"}`, background:isGO?"rgba(74,222,128,0.1)":"rgba(239,68,68,0.1)", color:isGO?"#4ade80":"#f87171", fontSize:12, fontWeight:700, cursor:"pointer", letterSpacing:0.5 }}>
          🔄 Reset Checklist
        </button>
      </div>
    </div>
  );
}

// ─── TRIP COST ESTIMATOR ─────────────────────────────────────

// Drive distance in miles from Abita Springs to each launch ramp (one way)
const DRIVE_MILES = {
  1:28, 2:24, 3:32, 4:40, 5:44, 6:48, 7:56, 8:56,
  9:20, 10:72, 11:72, 12:96, 13:96, 14:72, 15:84,
};

// Known launch fees per destination
const LAUNCH_FEES = {
  9:5,   // Big Branch NWR — free but donation suggested
  15:5,  // Atchafalaya Basin Landing — $5 per launch
};

// Fuel availability at each destination ramp
const RAMP_HAS_FUEL = {
  5:true, 7:true, 9:false, 10:true, 11:true, 12:true, 13:true, 14:true, 15:true,
};

function TripCostScreen({ destinations }) {
  const [dest, setDest] = useState(destinations[0]);
  const [numSkis, setNumSkis] = useState(2);
  const [gasMpg, setGasMpg] = useState(4.5);
  const [tankGal, setTankGal] = useState(18);
  const [extraCan, setExtraCan] = useState(2.5);
  const [fuelPrice, setFuelPrice] = useState(4.20);
  const [marineFuelSurcharge, setMarineFuelSurcharge] = useState(0.75);
  const [truckMpg, setTruckMpg] = useState(16);
  const [truckFuelPrice, setTruckFuelPrice] = useState(3.40);
  const [riders, setRiders] = useState(2);
  const [splitCost, setSplitCost] = useState(true);

  const driveMiles = DRIVE_MILES[dest?.id] || 60;
  const roundTripDriveMiles = driveMiles * 2;
  const waterMiles = (dest?.roundTripMiles || 40) * numSkis;
  const launchFee = (LAUNCH_FEES[dest?.id] || 0) * numSkis;
  const hasFuelOnRamp = RAMP_HAS_FUEL[dest?.id] || false;

  // Truck fuel cost
  const truckFuelCost = (roundTripDriveMiles / truckMpg) * truckFuelPrice;

  // Ski fuel cost — water miles per ski
  const waterMilesPerSki = dest?.roundTripMiles || 40;
  const skiFuelPerSki = waterMilesPerSki / gasMpg;
  const skiFuelCostPerSki = skiFuelPerSki * (fuelPrice + marineFuelSurcharge);
  const totalSkiFuelCost = skiFuelCostPerSki * numSkis;

  // Extra fuel can cost
  const extraCanCost = extraCan > 0 ? (extraCan * (fuelPrice + marineFuelSurcharge)) * numSkis : 0;

  const totalCost = truckFuelCost + totalSkiFuelCost + extraCanCost + launchFee;
  const costPerRider = riders > 0 ? totalCost / riders : totalCost;

  const breakdownItems = [
    { label:`🚗 Truck fuel (${roundTripDriveMiles} mi round trip)`, cost:truckFuelCost, color:"#38bdf8" },
    { label:`🚤 Ski fuel × ${numSkis} (${waterMilesPerSki} mi water each)`, cost:totalSkiFuelCost, color:"#fbbf24" },
    ...(extraCan > 0 ? [{ label:`⛽ Extra fuel can × ${numSkis} (${extraCan} gal each)`, cost:extraCanCost, color:"#fb923c" }] : []),
    ...(launchFee > 0 ? [{ label:`🅿️ Launch fee × ${numSkis} skis`, cost:launchFee, color:"#a78bfa" }] : []),
  ];

  const SliderRow = ({ label, value, onChange, min, max, step, display, color }) => (
    <div style={{ marginBottom:14 }}>
      <div style={{ display:"flex", justifyContent:"space-between", marginBottom:6 }}>
        <span style={{ fontSize:12, color:"rgba(255,255,255,0.5)" }}>{label}</span>
        <span style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:18, color:color||"#fff" }}>{display}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value}
        onChange={e=>onChange(step<1?parseFloat(e.target.value):parseInt(e.target.value))}
        style={{ width:"100%", accentColor:color||"#38bdf8" }}/>
      <div style={{ display:"flex", justifyContent:"space-between", marginTop:3 }}>
        <span style={{ fontSize:9, color:"rgba(255,255,255,0.2)" }}>{min}</span>
        <span style={{ fontSize:9, color:"rgba(255,255,255,0.2)" }}>{max}</span>
      </div>
    </div>
  );

  return (
    <div style={{ padding:"0 16px 100px" }}>

      {/* Destination selector */}
      <div style={{ marginBottom:14 }}>
        <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:1, marginBottom:8 }}>🏝️ Destination</div>
        <div style={{ display:"flex", gap:8, overflowX:"auto", paddingBottom:4, WebkitOverflowScrolling:"touch" }}>
          {destinations.map(d=>(
            <button key={d.id} onClick={()=>setDest(d)} style={{ flexShrink:0, padding:"8px 14px", borderRadius:16, border:`1.5px solid ${dest?.id===d.id?d.color+"88":"rgba(255,255,255,0.08)"}`, background:dest?.id===d.id?d.color+"18":"rgba(255,255,255,0.04)", color:dest?.id===d.id?d.color:"rgba(255,255,255,0.4)", fontSize:12, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap", transition:"all 0.15s" }}>{d.emoji} {d.name.split(" ")[0]}</button>
          ))}
        </div>
      </div>

      {/* TOTAL COST HERO */}
      <div style={{ background:`linear-gradient(135deg,${dest?.color}18,${dest?.color}08)`, border:`2px solid ${dest?.color}55`, borderRadius:22, padding:"20px", marginBottom:14 }}>
        <div style={{ textAlign:"center", marginBottom:16 }}>
          <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)", textTransform:"uppercase", letterSpacing:1, marginBottom:4 }}>Estimated Trip Cost</div>
          <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:54, color:dest?.color||"#38bdf8", lineHeight:1, letterSpacing:1 }}>
            ${totalCost.toFixed(2)}
          </div>
          {splitCost && riders > 1 && (
            <div style={{ fontSize:14, color:"rgba(255,255,255,0.5)", marginTop:6 }}>
              ${costPerRider.toFixed(2)} <span style={{ fontSize:11 }}>per rider ({riders} people)</span>
            </div>
          )}
          <div style={{ fontSize:11, color:"rgba(255,255,255,0.35)", marginTop:4 }}>
            {driveMiles} mi from Abita Springs · {dest?.roundTripMiles||40} mi on water
          </div>
        </div>

        {/* Breakdown bars */}
        <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
          {breakdownItems.map((item,i)=>{
            const barPct = Math.round((item.cost / totalCost) * 100);
            return (
              <div key={i}>
                <div style={{ display:"flex", justifyContent:"space-between", marginBottom:4 }}>
                  <span style={{ fontSize:11, color:"rgba(255,255,255,0.55)" }}>{item.label}</span>
                  <span style={{ fontSize:12, fontWeight:700, color:item.color }}>${item.cost.toFixed(2)}</span>
                </div>
                <div style={{ background:"rgba(255,255,255,0.07)", borderRadius:4, height:5, overflow:"hidden" }}>
                  <div style={{ height:5, borderRadius:4, width:`${barPct}%`, background:item.color, boxShadow:`0 0 6px ${item.color}88`, transition:"width 0.3s ease" }}/>
                </div>
              </div>
            );
          })}
        </div>

        {/* Launch fee note */}
        {launchFee === 0 && (
          <div style={{ marginTop:12, fontSize:11, color:"rgba(255,255,255,0.3)", textAlign:"center" }}>No launch fee at this ramp</div>
        )}
        {!hasFuelOnRamp && (
          <div style={{ marginTop:8, background:"rgba(251,191,36,0.1)", border:"1px solid rgba(251,191,36,0.2)", borderRadius:10, padding:"8px 12px", fontSize:11, color:"#fbbf24", textAlign:"center" }}>
            ⚠️ No fuel at this ramp — fill up before you leave home
          </div>
        )}
      </div>

      {/* Split toggle + riders */}
      <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:16, padding:"14px 16px", marginBottom:14, display:"flex", gap:12, alignItems:"center" }}>
        <div style={{ flex:1 }}>
          <div style={{ fontSize:12, color:"rgba(255,255,255,0.6)", marginBottom:2 }}>Split cost between riders</div>
          <div style={{ fontSize:11, color:"rgba(255,255,255,0.35)" }}>{riders} rider{riders>1?"s":""} = ${costPerRider.toFixed(2)} each</div>
        </div>
        <div style={{ display:"flex", gap:8, alignItems:"center" }}>
          {[1,2,3,4].map(n=>(
            <button key={n} onClick={()=>{setRiders(n);setSplitCost(n>1);}} style={{ width:32, height:32, borderRadius:10, border:`1.5px solid ${riders===n?"rgba(56,189,248,0.6)":"rgba(255,255,255,0.1)"}`, background:riders===n?"rgba(56,189,248,0.15)":"rgba(255,255,255,0.04)", color:riders===n?"#38bdf8":"rgba(255,255,255,0.35)", fontSize:13, fontWeight:700, cursor:"pointer" }}>{n}</button>
          ))}
        </div>
      </div>

      {/* Ski settings */}
      <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:18, padding:"16px", marginBottom:14 }}>
        <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)", textTransform:"uppercase", letterSpacing:0.8, fontWeight:700, marginBottom:16 }}>🚤 Ski Settings</div>
        <div style={{ display:"flex", gap:8, marginBottom:16 }}>
          {[1,2,3,4].map(n=>(
            <button key={n} onClick={()=>setNumSkis(n)} style={{ flex:1, padding:"10px 4px", borderRadius:12, border:`1.5px solid ${numSkis===n?"rgba(251,191,36,0.6)":"rgba(255,255,255,0.1)"}`, background:numSkis===n?"rgba(251,191,36,0.15)":"rgba(255,255,255,0.04)", color:numSkis===n?"#fbbf24":"rgba(255,255,255,0.4)", fontSize:12, fontWeight:700, cursor:"pointer" }}>
              {n} Ski{n>1?"s":""}
            </button>
          ))}
        </div>
        <SliderRow label="Ski MPG (avg cruise)" value={gasMpg} onChange={setGasMpg} min={2} max={8} step={0.5} display={`${gasMpg} mpg`} color="#fbbf24"/>
        <SliderRow label="Tank Size" value={tankGal} onChange={setTankGal} min={10} max={30} step={1} display={`${tankGal} gal`} color="#fb923c"/>
        <SliderRow label="Extra Fuel Can (per ski)" value={extraCan} onChange={setExtraCan} min={0} max={5} step={0.5} display={extraCan>0?`${extraCan} gal`:"None"} color="#f87171"/>
        <SliderRow label="Marine Fuel Price" value={fuelPrice+marineFuelSurcharge} onChange={v=>{setFuelPrice(v-marineFuelSurcharge);}} min={3.50} max={8.00} step={0.05} display={`$${(fuelPrice+marineFuelSurcharge).toFixed(2)}/gal`} color="#4ade80"/>
      </div>

      {/* Truck settings */}
      <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:18, padding:"16px", marginBottom:14 }}>
        <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)", textTransform:"uppercase", letterSpacing:0.8, fontWeight:700, marginBottom:16 }}>🚗 Truck / Tow Vehicle</div>
        <SliderRow label="Truck MPG (with trailer)" value={truckMpg} onChange={setTruckMpg} min={8} max={28} step={1} display={`${truckMpg} mpg`} color="#38bdf8"/>
        <SliderRow label="Gas Price" value={truckFuelPrice} onChange={setTruckFuelPrice} min={2.50} max={6.00} step={0.05} display={`$${truckFuelPrice.toFixed(2)}/gal`} color="#38bdf8"/>
      </div>

      {/* All 15 destination cost preview */}
      <div style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:18, padding:"16px" }}>
        <div style={{ fontSize:11, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, fontWeight:700, marginBottom:14 }}>💰 All Destinations — Cost Comparison</div>
        <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
          {[...destinations].sort((a,b)=>{
            const costA = ((DRIVE_MILES[a.id]||60)*2/truckMpg*truckFuelPrice) + ((a.roundTripMiles||40)/gasMpg*(fuelPrice+marineFuelSurcharge)*numSkis) + (LAUNCH_FEES[a.id]||0)*numSkis;
            const costB = ((DRIVE_MILES[b.id]||60)*2/truckMpg*truckFuelPrice) + ((b.roundTripMiles||40)/gasMpg*(fuelPrice+marineFuelSurcharge)*numSkis) + (LAUNCH_FEES[b.id]||0)*numSkis;
            return costA - costB;
          }).map(d=>{
            const dCost = ((DRIVE_MILES[d.id]||60)*2/truckMpg*truckFuelPrice) + ((d.roundTripMiles||40)/gasMpg*(fuelPrice+marineFuelSurcharge)*numSkis) + (LAUNCH_FEES[d.id]||0)*numSkis;
            const isSelected = d.id === dest?.id;
            const maxCost = 200;
            const barW = Math.min(100, (dCost/maxCost)*100);
            return (
              <div key={d.id} onClick={()=>setDest(d)} style={{ cursor:"pointer", padding:"8px 10px", borderRadius:12, background:isSelected?`${d.color}12`:"rgba(255,255,255,0.02)", border:`1px solid ${isSelected?d.color+"44":"rgba(255,255,255,0.05)"}`, transition:"all 0.15s" }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
                  <span style={{ fontSize:12, color:isSelected?d.color:"rgba(255,255,255,0.55)" }}>{d.emoji} {d.name}</span>
                  <span style={{ fontSize:12, fontWeight:700, color:isSelected?d.color:"rgba(255,255,255,0.5)" }}>${dCost.toFixed(0)}{splitCost&&riders>1?` · $${(dCost/riders).toFixed(0)}ea`:""}</span>
                </div>
                <div style={{ background:"rgba(255,255,255,0.06)", borderRadius:3, height:4, overflow:"hidden" }}>
                  <div style={{ height:4, borderRadius:3, width:`${barW}%`, background:isSelected?d.color:"rgba(255,255,255,0.15)", transition:"width 0.3s ease" }}/>
                </div>
              </div>
            );
          })}
        </div>
        <div style={{ fontSize:10, color:"rgba(255,255,255,0.2)", marginTop:10, textAlign:"center" }}>Sorted cheapest to most expensive · Tap to select</div>
      </div>
    </div>
  );
}

// ─── RIGHT NOW SCREEN ───────────────────────────────────────
function RightNowScreen({ destinations }) {
  const [now, setNow] = useState(new Date());
  const [rampMins, setRampMins] = useState(15);
  const [minWaterHours, setMinWaterHours] = useState(1);
  const [sunsetInput, setSunsetInput] = useState("");

  // Live clock — updates every minute
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 60000);
    return () => clearInterval(t);
  }, []);

  // Parse user-entered sunset — required, no fallback
  function parseSunset(str) {
    if (!str) return null;
    const m = str.trim().match(/^(\d{1,2}):(\d{2})$/);
    if (m) {
      const h = parseInt(m[1]), mn = parseInt(m[2]);
      if (h>=0&&h<=23&&mn>=0&&mn<=59) {
        const d = new Date(); d.setHours(h,mn,0,0); return d;
      }
    }
    return null;
  }

  const sunset = parseSunset(sunsetInput);
  const hardStop = sunset ? new Date(sunset.getTime() - 15*60000) : null;
  const hasSunset = !!sunset;

  // For each destination calculate feasibility — only if sunset is entered
  const results = hasSunset ? destinations.map(dest => {
    const driveMins = DRIVE_MINS[dest.id] || 60;
    const returnBuffer = dest.level === "advanced" ? 45 : dest.level === "moderate" ? 30 : 20;
    const minWaterMins = minWaterHours * 60;
    const latestLeave = new Date(hardStop.getTime() - (driveMins + rampMins + minWaterMins + returnBuffer) * 60000);
    const canGo = latestLeave > now;
    const availableMins = Math.max(0, (hardStop.getTime() - now.getTime()) / 60000 - driveMins - rampMins - returnBuffer);
    const availableHours = Math.floor(availableMins / 30) / 2;
    const leaveNow = new Date(now.getTime() + 5*60000);
    const arriveRamp = new Date(leaveNow.getTime() + driveMins*60000);
    const launchTime = new Date(arriveRamp.getTime() + rampMins*60000);
    const offWater = new Date(launchTime.getTime() + availableMins*60000);
    const homeBy = new Date(hardStop.getTime() + (20 + driveMins)*60000);
    const minsUntilLatestLeave = Math.round((latestLeave - now) / 60000);
    return { dest, canGo, availableHours, availableMins, leaveNow, arriveRamp, launchTime, offWater, homeBy, latestLeave, minsUntilLatestLeave, driveMins, returnBuffer };
  }) : [];

  const goTrips       = results.filter(r => r.canGo && r.availableHours >= minWaterHours).sort((a,b) => b.availableHours - a.availableHours);
  const marginalTrips = results.filter(r => r.canGo && r.availableHours > 0 && r.availableHours < minWaterHours).sort((a,b) => b.availableHours - a.availableHours);
  const noGoTrips     = results.filter(r => !r.canGo || r.availableHours <= 0);

  const fmtTime = d => d.toLocaleTimeString("en-US",{hour:"numeric",minute:"2-digit",hour12:true});
  const fmtHours = h => h >= 1 ? `${h}h` : `${Math.round(h*60)}m`;

  const LEVEL_CFG = {
    easy:     {dot:"🟢", color:"#4ade80"},
    moderate: {dot:"🟡", color:"#fcd34d"},
    advanced: {dot:"🔴", color:"#f87171"},
  };

  const TripOption = ({ r, rank }) => {
    const lv = LEVEL_CFG[r.dest.level];
    const urgent = r.minsUntilLatestLeave < 30 && r.minsUntilLatestLeave > 0;
    return (
      <div style={{ background:`${r.dest.color}0e`, border:`1.5px solid ${r.dest.color}44`, borderRadius:18, padding:"14px 16px", marginBottom:10 }}>
        {/* Header */}
        <div style={{ display:"flex", gap:10, alignItems:"center", marginBottom:10 }}>
          {rank && <div style={{ width:28, height:28, borderRadius:10, background:`${r.dest.color}22`, border:`1px solid ${r.dest.color}55`, display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"'Black Han Sans',sans-serif", fontSize:14, color:r.dest.color, flexShrink:0 }}>#{rank}</div>}
          <span style={{ fontSize:24, flexShrink:0 }}>{r.dest.emoji}</span>
          <div style={{ flex:1 }}>
            <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:16, color:"#fff", letterSpacing:0.3 }}>{r.dest.name}</div>
            <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)" }}>{r.dest.subtitle}</div>
          </div>
          <div style={{ textAlign:"right", flexShrink:0 }}>
            <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:20, color:r.dest.color }}>{fmtHours(r.availableHours)}</div>
            <div style={{ fontSize:9, color:"rgba(255,255,255,0.3)", textTransform:"uppercase" }}>on water</div>
          </div>
        </div>

        {/* Timeline strip */}
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr 1fr", gap:6, marginBottom:10 }}>
          {[
            {label:"Leave",    time:r.leaveNow,   color:"#38bdf8"},
            {label:"Launch",   time:r.launchTime, color:r.dest.color},
            {label:"Off Water",time:r.offWater,   color:"#f87171"},
            {label:"Home By",  time:r.homeBy,     color:"#4ade80"},
          ].map(s=>(
            <div key={s.label} style={{ background:"rgba(255,255,255,0.04)", borderRadius:10, padding:"6px 4px", textAlign:"center" }}>
              <div style={{ fontSize:9, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.3, marginBottom:3 }}>{s.label}</div>
              <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:13, color:s.color }}>{fmtTime(s.time)}</div>
            </div>
          ))}
        </div>

        {/* Tags row */}
        <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
          <span style={{ fontSize:10, fontWeight:700, padding:"2px 8px", borderRadius:10, background:`rgba(255,255,255,0.06)`, color:"rgba(255,255,255,0.45)" }}>🚗 {r.driveMins}m drive</span>
          <span style={{ fontSize:10, fontWeight:700, padding:"2px 8px", borderRadius:10, background:`rgba(255,255,255,0.06)`, color:lv.color }}>{lv.dot} {r.dest.level}</span>
          {urgent && <span style={{ fontSize:10, fontWeight:700, padding:"2px 8px", borderRadius:10, background:"rgba(239,68,68,0.15)", color:"#f87171", border:"1px solid rgba(239,68,68,0.3)" }}>⚡ Leave in {r.minsUntilLatestLeave}m</span>}
          {r.minsUntilLatestLeave > 30 && r.minsUntilLatestLeave < 120 && <span style={{ fontSize:10, fontWeight:700, padding:"2px 8px", borderRadius:10, background:"rgba(251,191,36,0.15)", color:"#fbbf24" }}>⏳ Leave within {Math.floor(r.minsUntilLatestLeave/60)}h {r.minsUntilLatestLeave%60}m</span>}
        </div>
      </div>
    );
  };

  return (
    <div style={{ padding:"0 16px 100px" }}>

      {/* Live status card */}
      <div style={{ background:"linear-gradient(135deg,rgba(0,229,160,0.1),rgba(56,189,248,0.06))", border:"1.5px solid rgba(0,229,160,0.3)", borderRadius:20, padding:"16px 18px", marginBottom:16 }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:10 }}>
          <div>
            <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:28, color:"#00e5a0", letterSpacing:1 }}>
              {now.toLocaleTimeString("en-US",{hour:"numeric",minute:"2-digit",hour12:true})}
            </div>
            <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)", marginTop:2 }}>
              {now.toLocaleDateString("en-US",{weekday:"long",month:"long",day:"numeric"})}
            </div>
          </div>
          <div style={{ textAlign:"right" }}>
            <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", marginBottom:2 }}>Sunset</div>
            {hasSunset ? (
              <>
                <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:18, color:"#fb923c" }}>{fmtTime(sunset)}</div>
                <div style={{ fontSize:9, color:"rgba(255,255,255,0.3)", marginTop:2 }}>
                  Hard stop {fmtTime(hardStop)}
                </div>
              </>
            ) : (
              <div style={{ fontSize:11, color:"#fbbf24", fontWeight:700 }}>Enter below ↓</div>
            )}
          </div>
        </div>

        {/* Daylight remaining bar — only show if sunset entered */}
        {hasSunset && (
          <div>
            <div style={{ display:"flex", justifyContent:"space-between", marginBottom:5 }}>
              <span style={{ fontSize:11, color:"rgba(255,255,255,0.5)" }}>Daylight remaining</span>
              <span style={{ fontSize:11, fontWeight:700, color: Math.max(0,(hardStop-now)/60000) < 60 ? "#f87171" : Math.max(0,(hardStop-now)/60000) < 120 ? "#fbbf24" : "#4ade80" }}>
                {Math.max(0,Math.floor((hardStop-now)/60000/60))}h {Math.max(0,Math.floor((hardStop-now)/60000%60))}m
              </span>
            </div>
            <div style={{ background:"rgba(255,255,255,0.08)", borderRadius:6, height:8, overflow:"hidden" }}>
              <div style={{ height:8, borderRadius:6,
                width:`${Math.min(100,Math.max(0,(hardStop-now)/(12*3600000)*100))}%`,
                background:"linear-gradient(90deg,#f87171,#fbbf24,#4ade80)",
                transition:"width 0.5s ease"
              }}/>
            </div>
          </div>
        )}
      </div>

      {/* Sunset input — required */}
      <div style={{ background: hasSunset?"rgba(251,146,60,0.08)":"rgba(251,191,36,0.08)", border:`1.5px solid ${hasSunset?"rgba(251,146,60,0.4)":"rgba(251,191,36,0.4)"}`, borderRadius:16, padding:"14px 16px", marginBottom:14 }}>
        <div style={{ fontSize:10, color:hasSunset?"#fb923c":"#fbbf24", textTransform:"uppercase", letterSpacing:0.8, fontWeight:700, marginBottom:8 }}>
          🌇 {hasSunset?"Today's Sunset":"Enter Today's Sunset to Get Started"}
        </div>
        {!hasSunset && (
          <div style={{ fontSize:11, color:"rgba(255,255,255,0.45)", marginBottom:10, lineHeight:1.5 }}>
            Check your weather app for today's exact sunset time, then enter it below. All trip options will calculate instantly.
          </div>
        )}
        <div style={{ display:"flex", gap:10, alignItems:"center" }}>
          <input type="time" value={sunsetInput} onChange={e=>setSunsetInput(e.target.value)}
            style={{ flex:1, background:"rgba(255,255,255,0.07)", border:`1.5px solid ${hasSunset?"#fb923c":"rgba(251,191,36,0.5)"}`, borderRadius:12, padding:"12px 14px", color:"#fff", fontSize:16, outline:"none", fontFamily:"'Barlow',sans-serif" }}/>
          {sunsetInput && <button onClick={()=>setSunsetInput("")} style={{ padding:"12px 14px", borderRadius:12, border:"none", background:"rgba(255,255,255,0.07)", color:"rgba(255,255,255,0.4)", fontSize:12, cursor:"pointer", fontWeight:700 }}>Clear</button>}
        </div>
      </div>

      {/* Min water hours + ramp time */}
      <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:16, padding:"14px 16px", marginBottom:18 }}>
        <div style={{ marginBottom:14 }}>
          <div style={{ display:"flex", justifyContent:"space-between", marginBottom:6 }}>
            <span style={{ fontSize:12, color:"rgba(255,255,255,0.5)" }}>⏱ Minimum hours I want</span>
            <span style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:18, color:"#00e5a0" }}>{minWaterHours}h</span>
          </div>
          <input type="range" min={0.5} max={6} step={0.5} value={minWaterHours} onChange={e=>setMinWaterHours(parseFloat(e.target.value))} style={{ width:"100%", accentColor:"#00e5a0" }}/>
          <div style={{ fontSize:10, color:"rgba(255,255,255,0.2)", marginTop:3 }}>Destinations with less than this show as marginal</div>
        </div>
        <div>
          <div style={{ display:"flex", justifyContent:"space-between", marginBottom:6 }}>
            <span style={{ fontSize:12, color:"rgba(255,255,255,0.5)" }}>🚤 Ramp setup time</span>
            <span style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:18, color:"#22d3ee" }}>{rampMins}m</span>
          </div>
          <input type="range" min={10} max={45} step={5} value={rampMins} onChange={e=>setRampMins(parseInt(e.target.value))} style={{ width:"100%", accentColor:"#22d3ee" }}/>
        </div>
      </div>

      {/* GO trips */}
      {goTrips.length > 0 && (
        <div>
          <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:12 }}>
            <div style={{ flex:1, height:1, background:"rgba(74,222,128,0.2)" }}/>
            <span style={{ fontSize:11, color:"#4ade80", fontWeight:700, textTransform:"uppercase", letterSpacing:1 }}>✅ You Can Go — {goTrips.length} Option{goTrips.length>1?"s":""}</span>
            <div style={{ flex:1, height:1, background:"rgba(74,222,128,0.2)" }}/>
          </div>
          {goTrips.map((r,i) => <TripOption key={r.dest.id} r={r} rank={i+1}/>)}
        </div>
      )}

      {/* Marginal trips */}
      {marginalTrips.length > 0 && (
        <div style={{ marginTop:goTrips.length>0?8:0 }}>
          <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:12 }}>
            <div style={{ flex:1, height:1, background:"rgba(251,191,36,0.2)" }}/>
            <span style={{ fontSize:11, color:"#fbbf24", fontWeight:700, textTransform:"uppercase", letterSpacing:1 }}>⚡ Marginal — Less than {minWaterHours}h</span>
            <div style={{ flex:1, height:1, background:"rgba(251,191,36,0.2)" }}/>
          </div>
          {marginalTrips.map(r => <TripOption key={r.dest.id} r={r} rank={null}/>)}
        </div>
      )}

      {/* No go */}
      {noGoTrips.length > 0 && (
        <div style={{ marginTop:8 }}>
          <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:10 }}>
            <div style={{ flex:1, height:1, background:"rgba(248,113,113,0.15)" }}/>
            <span style={{ fontSize:11, color:"#f87171", fontWeight:700, textTransform:"uppercase", letterSpacing:1 }}>⛔ Not Enough Time Today — {noGoTrips.length}</span>
            <div style={{ flex:1, height:1, background:"rgba(248,113,113,0.15)" }}/>
          </div>
          <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
            {noGoTrips.map(r=>(
              <div key={r.dest.id} style={{ display:"flex", gap:6, alignItems:"center", background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:12, padding:"7px 12px" }}>
                <span style={{ fontSize:16 }}>{r.dest.emoji}</span>
                <span style={{ fontSize:12, color:"rgba(255,255,255,0.35)" }}>{r.dest.name.split(" ")[0]}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {!hasSunset && (
        <div style={{ textAlign:"center", padding:"30px 20px" }}>
          <div style={{ fontSize:48, marginBottom:12 }}>🌇</div>
          <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:20, color:"#fbbf24", marginBottom:8 }}>Enter Today's Sunset</div>
          <div style={{ fontSize:13, color:"rgba(255,255,255,0.4)", lineHeight:1.6 }}>Check your weather app for today's exact sunset time and enter it above. All destinations will calculate instantly.</div>
        </div>
      )}

      {hasSunset && goTrips.length === 0 && marginalTrips.length === 0 && (
        <div style={{ textAlign:"center", padding:"40px 20px" }}>
          <div style={{ fontSize:48, marginBottom:12 }}>🌙</div>
          <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:24, color:"#f87171", marginBottom:8 }}>Too Late Today</div>
          <div style={{ fontSize:13, color:"rgba(255,255,255,0.4)", lineHeight:1.6 }}>Not enough daylight left to reach any destination before sunset. Plan for tomorrow.</div>
        </div>
      )}
    </div>
  );
}

// ─── TIDAL CURRENT PREDICTIONS ──────────────────────────────

// NOAA current station IDs for key passes near destinations
const CURRENT_STATIONS = {
  rigolets:   { id:"PCT1611", name:"The Rigolets", desc:"Main pass between Lake Pontchartrain and Lake Borgne. Critical for Rabbit Island and eastbound routes.", dests:[5,8], color:"#38bdf8" },
  chef:       { id:"PCT1615", name:"Chef Menteur Pass", desc:"Second pass between Pontchartrain and Borgne. Alternate route to Lake Catherine and eastern marsh.", dests:[5,8], color:"#22d3ee" },
  caminada:   { id:"PUG1515", name:"Caminada Pass", desc:"Main Gulf access near Grand Isle and Fourchon Beach. Strong tidal currents on tide changes.", dests:[12], color:"#fb7185" },
  timbalier:  { id:"PUG1519", name:"Timbalier Pass", desc:"Access between Timbalier Bay and Gulf. Relevant for offshore approaches to Grand Isle area.", dests:[12], color:"#fb923c" },
  belle:      { id:"PUG1513", name:"Belle Pass / Port Fourchon", desc:"Main shipping and recreational access at Port Fourchon. Strong currents during tide changes.", dests:[12], color:"#fbbf24" },
  barataria:  { id:"PCT1521", name:"Barataria Pass", desc:"Main tidal pass into Barataria Bay. Strong ebb and flood currents affect navigation in and out.", dests:[10], color:"#4ade80" },
  biloxi:     { id:"PUG1317", name:"Biloxi Ship Channel", desc:"Commercial shipping channel near Biloxi Small Craft Harbor. Current affects departure and return.", dests:[11,13,14], color:"#fde68a" },
  pearl:      { id:"PCT1601", name:"Pearl River Mouth", desc:"Where the Pearl River meets Mississippi Sound. Tidal influence on river current, especially near mouth.", dests:[1,4,6], color:"#00e5a0" },
};

// Which stations matter most per destination
const DEST_STATIONS = {
  1:  ["pearl"],
  2:  [],
  3:  [],
  4:  ["pearl"],
  5:  ["rigolets","chef"],
  6:  ["pearl"],
  7:  [],
  8:  ["rigolets","chef"],
  9:  [],
  10: ["barataria"],
  11: ["biloxi"],
  12: ["caminada","belle","timbalier"],
  13: ["biloxi"],
  14: ["biloxi"],
  15: [],
};

// General tidal current knowledge per destination type
const CURRENT_NOTES = {
  1:  { tide:"Moderate",  dir:"N/S with Pearl River flow", best:"Incoming tide — river current reduced, easier navigation", caution:"Strong outgoing tide can push you into snags near the mouth" },
  2:  { tide:"Mild",      dir:"East-West through the pass", best:"Slack water — easiest riding through the pass", caution:"Avoid fighting a strong outgoing current through Manchac Pass" },
  3:  { tide:"Mild",      dir:"Tidal influence from Maurepas", best:"High water — more channel options available", caution:"Low water exposes mussel beds and narrows channels" },
  4:  { tide:"Moderate",  dir:"N/S with Pearl River flow", best:"Incoming tide slows river current", caution:"Strong ebb can make the river mouth rough and pushy" },
  5:  { tide:"Strong",    dir:"East-West through Rigolets/Chef", best:"Slack water (1hr before/after high or low)", caution:"Peak flood or ebb through the Rigolets runs 2–4 knots — difficult to fight on a PWC" },
  6:  { tide:"Mild",      dir:"N/S in Mississippi Sound", best:"Incoming tide — better water clarity", caution:"Oyster beds more exposed on low tide — approach from deep side" },
  7:  { tide:"Mild",      dir:"N/S in open marsh", best:"High water — more access to interior ponds", caution:"Low tide can strand you in shallow marsh channels" },
  8:  { tide:"Moderate",  dir:"East-West via MRGO", best:"Slack water for passage through Rigolets area", caution:"Avoid MRGO main channel during commercial vessel traffic regardless of tide" },
  9:  { tide:"Mild",      dir:"N/S from Pontchartrain", best:"High water — more marsh access", caution:"Low water on the south shore can create very shallow runs" },
  10: { tide:"Strong",    dir:"N/S through Barataria Pass", best:"Slack water — easiest entry and exit", caution:"Strong tidal current through Barataria Pass. Flood runs NNW, ebb SSE, up to 3 knots" },
  11: { tide:"Mild",      dir:"Biloxi Sound tidal action", best:"Any tide — short crossing", caution:"Stay clear of shipping channel regardless of tide stage" },
  12: { tide:"Strong",    dir:"N/S through Gulf passes", best:"Slack water for pass crossings", caution:"Caminada and Belle passes run strong on tide changes — cross during slack for safest transit" },
  13: { tide:"Moderate",  dir:"N/S in Mississippi Sound", best:"Slack water for 12-mile crossing — less chop", caution:"Wind-driven current adds to tidal current on open water — account for significant drift" },
  14: { tide:"Moderate",  dir:"N/S in Mississippi Sound", best:"Slack water — smoother crossing", caution:"Same as Ship Island — account for current drift on the offshore crossing" },
  15: { tide:"River-driven", dir:"S-SW river current", best:"Moderate water levels — best riding", caution:"Spring high water increases current to 3–5 mph in main channels — stay in eddies and side channels" },
};

function TidalScreen({ destinations }) {
  const [dest, setDest] = useState(destinations[0]);

  const note = CURRENT_NOTES[dest?.id];
  const stationKeys = DEST_STATIONS[dest?.id] || [];
  const relevantStations = stationKeys.map(k => CURRENT_STATIONS[k]).filter(Boolean);
  const hasCurrentStation = relevantStations.length > 0;

  const tideStrengthColor = {
    "Strong": "#f87171",
    "Moderate": "#fbbf24",
    "Mild": "#4ade80",
    "River-driven": "#2dd4bf",
  };

  // NOAA current prediction link builder
  function noaaCurrentUrl(stationId) {
    const today = new Date().toISOString().slice(0,10).replace(/-/g,"");
    return `https://tidesandcurrents.noaa.gov/noaacurrents/Stations?id=${stationId}`;
  }

  // General tidal links for areas without specific stations
  const generalLinks = [
    { label:"NOAA Current Predictions — All Stations", url:"https://tidesandcurrents.noaa.gov/currents/", icon:"🌊", desc:"Find any NOAA current prediction station. Zoom to your destination and select the nearest station.", color:"#38bdf8" },
    { label:"NOAA Tidal Current Charts — Gulf Coast", url:"https://tidesandcurrents.noaa.gov/noaacurrents/SemiDiurnal?id=g03010", icon:"🗺️", desc:"Visual tidal current charts for the Gulf of Mexico. Shows flood and ebb flow patterns.", color:"#a78bfa" },
    { label:"PredictionTide.com", url:"https://www.tideschart.com/United-States/Louisiana/", icon:"📊", desc:"Simple tide and current predictions for Louisiana coastal areas. Easy to read on mobile.", color:"#4ade80" },
    { label:"Windy.com — Currents Layer", url:"https://www.windy.com/?currents,29.1,-89.9,9", icon:"💨", desc:"Enable the Currents layer on Windy to see real-time surface current speed and direction.", color:"#22d3ee" },
  ];

  return (
    <div style={{ padding:"0 16px 100px" }}>

      {/* Destination selector */}
      <div style={{ marginBottom:14 }}>
        <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:1, marginBottom:8 }}>🏝️ Select Destination</div>
        <div style={{ display:"flex", gap:8, overflowX:"auto", paddingBottom:4, WebkitOverflowScrolling:"touch" }}>
          {destinations.map(d=>(
            <button key={d.id} onClick={()=>setDest(d)} style={{ flexShrink:0, padding:"8px 14px", borderRadius:16, border:`1.5px solid ${dest?.id===d.id?d.color+"88":"rgba(255,255,255,0.08)"}`, background:dest?.id===d.id?d.color+"18":"rgba(255,255,255,0.04)", color:dest?.id===d.id?d.color:"rgba(255,255,255,0.4)", fontSize:12, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap", transition:"all 0.15s" }}>{d.emoji} {d.name.split(" ")[0]}</button>
          ))}
        </div>
      </div>

      {dest && note && (
        <>
          {/* Destination header */}
          <div style={{ background:`${dest.color}12`, border:`1.5px solid ${dest.color}33`, borderRadius:18, padding:"14px 16px", marginBottom:14 }}>
            <div style={{ display:"flex", gap:10, alignItems:"center", marginBottom:10 }}>
              <span style={{ fontSize:26 }}>{dest.emoji}</span>
              <div>
                <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:17, color:"#fff" }}>{dest.name}</div>
                <div style={{ fontSize:11, color:"rgba(255,255,255,0.4)" }}>{dest.subtitle}</div>
              </div>
            </div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
              <div style={{ background:"rgba(255,255,255,0.05)", borderRadius:10, padding:"10px 12px" }}>
                <div style={{ fontSize:9, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.5, marginBottom:4 }}>Tidal Strength</div>
                <div style={{ fontSize:14, fontWeight:700, color:tideStrengthColor[note.tide]||"#fff" }}>{note.tide}</div>
              </div>
              <div style={{ background:"rgba(255,255,255,0.05)", borderRadius:10, padding:"10px 12px" }}>
                <div style={{ fontSize:9, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.5, marginBottom:4 }}>Flow Direction</div>
                <div style={{ fontSize:12, color:"rgba(255,255,255,0.7)" }}>{note.dir}</div>
              </div>
            </div>
          </div>

          {/* Best time and caution */}
          <div style={{ display:"flex", flexDirection:"column", gap:10, marginBottom:16 }}>
            <div style={{ background:"rgba(74,222,128,0.08)", border:"1px solid rgba(74,222,128,0.2)", borderRadius:14, padding:"12px 14px", display:"flex", gap:10, alignItems:"flex-start" }}>
              <span style={{ fontSize:18, flexShrink:0 }}>✅</span>
              <div>
                <div style={{ fontSize:11, color:"#4ade80", fontWeight:700, marginBottom:3 }}>Best Conditions</div>
                <div style={{ fontSize:12, color:"rgba(255,255,255,0.6)", lineHeight:1.55 }}>{note.best}</div>
              </div>
            </div>
            <div style={{ background:"rgba(251,191,36,0.08)", border:"1px solid rgba(251,191,36,0.2)", borderRadius:14, padding:"12px 14px", display:"flex", gap:10, alignItems:"flex-start" }}>
              <span style={{ fontSize:18, flexShrink:0 }}>⚠️</span>
              <div>
                <div style={{ fontSize:11, color:"#fbbf24", fontWeight:700, marginBottom:3 }}>Watch Out For</div>
                <div style={{ fontSize:12, color:"rgba(255,255,255,0.6)", lineHeight:1.55 }}>{note.caution}</div>
              </div>
            </div>
          </div>

          {/* Slack water explanation */}
          <div style={{ background:"rgba(56,189,248,0.06)", border:"1px solid rgba(56,189,248,0.15)", borderRadius:14, padding:"12px 16px", marginBottom:16 }}>
            <div style={{ fontSize:11, color:"#38bdf8", fontWeight:700, marginBottom:6 }}>💡 What is Slack Water?</div>
            <div style={{ fontSize:11, color:"rgba(255,255,255,0.5)", lineHeight:1.65 }}>
              Slack water is the brief period when the tide is neither flooding nor ebbing — current is near zero. It occurs roughly 1 hour before and after each high or low tide. This is the safest time to cross passes, navigate shallow areas, and launch from tidal ramps. Check NOAA tide predictions and plan pass crossings within 1 hour of high or low tide.
            </div>
          </div>

          {/* NOAA current station links for this destination */}
          {hasCurrentStation && (
            <div style={{ marginBottom:16 }}>
              <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:10 }}>📡 Live Current Stations Near {dest.name.split(" ")[0]}</div>
              <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
                {relevantStations.map((s,i)=>(
                  <a key={i} href={noaaCurrentUrl(s.id)} target="_blank" rel="noopener noreferrer" style={{ display:"flex", gap:12, alignItems:"flex-start", background:`${s.color}0a`, border:`1.5px solid ${s.color}33`, borderRadius:16, padding:"14px 16px", textDecoration:"none" }}>
                    <div style={{ width:40, height:40, borderRadius:12, background:`${s.color}18`, border:`1.5px solid ${s.color}44`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:20, flexShrink:0 }}>🌊</div>
                    <div style={{ flex:1 }}>
                      <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:14, color:s.color, marginBottom:3 }}>{s.name}</div>
                      <div style={{ fontSize:11, color:"rgba(255,255,255,0.45)", lineHeight:1.55 }}>{s.desc}</div>
                      <div style={{ fontSize:10, color:"rgba(255,255,255,0.25)", marginTop:4 }}>NOAA Station {s.id} → Live predictions</div>
                    </div>
                    <span style={{ fontSize:16, color:"rgba(255,255,255,0.25)", flexShrink:0 }}>→</span>
                  </a>
                ))}
              </div>
            </div>
          )}

          {/* No specific station message */}
          {!hasCurrentStation && (
            <div style={{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:14, padding:"12px 16px", marginBottom:16 }}>
              <div style={{ fontSize:12, color:"rgba(255,255,255,0.45)", lineHeight:1.6 }}>
                No NOAA current prediction station is directly assigned to {dest.name}. Tidal influence here is {note.tide.toLowerCase()} — use the general resources below or check the nearest coastal station.
              </div>
            </div>
          )}
        </>
      )}

      {/* General tidal current resources */}
      <div style={{ marginBottom:8 }}>
        <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:10 }}>🔗 Tidal Current Resources</div>
        <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
          {generalLinks.map((link,i)=>(
            <a key={i} href={link.url} target="_blank" rel="noopener noreferrer" style={{ display:"flex", gap:12, alignItems:"flex-start", background:`${link.color}0a`, border:`1.5px solid ${link.color}33`, borderRadius:16, padding:"14px 16px", textDecoration:"none" }}>
              <div style={{ width:40, height:40, borderRadius:12, background:`${link.color}18`, border:`1.5px solid ${link.color}44`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:20, flexShrink:0 }}>{link.icon}</div>
              <div style={{ flex:1 }}>
                <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:13, color:link.color, marginBottom:3, lineHeight:1.3 }}>{link.label}</div>
                <div style={{ fontSize:11, color:"rgba(255,255,255,0.45)", lineHeight:1.55 }}>{link.desc}</div>
              </div>
              <span style={{ fontSize:16, color:"rgba(255,255,255,0.25)", flexShrink:0, marginTop:2 }}>→</span>
            </a>
          ))}
        </div>
      </div>

      {/* Quick reference — tide stages */}
      <div style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:16, padding:"14px 16px" }}>
        <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", textTransform:"uppercase", letterSpacing:0.8, marginBottom:12 }}>📖 Quick Reference — Tide Stages</div>
        {[
          { stage:"Flood Tide",   icon:"⬆️", color:"#38bdf8",  desc:"Water rising — current flows inland through passes. Can help or hinder depending on direction of travel." },
          { stage:"High Tide",    icon:"🔝", color:"#4ade80",  desc:"Maximum water level. Slack water begins. Best time to cross passes and navigate shallow areas." },
          { stage:"Ebb Tide",     icon:"⬇️", color:"#f87171",  desc:"Water falling — current flows seaward through passes. Can be strong at narrow passes like the Rigolets." },
          { stage:"Low Tide",     icon:"🔻", color:"#fbbf24",  desc:"Minimum water level. Slack water begins. Oyster bars exposed — use caution in shallow areas." },
        ].map((s,i)=>(
          <div key={i} style={{ display:"flex", gap:10, alignItems:"flex-start", padding:"8px 0", borderBottom:i<3?"1px solid rgba(255,255,255,0.05)":"none" }}>
            <span style={{ fontSize:20, flexShrink:0 }}>{s.icon}</span>
            <div>
              <div style={{ fontSize:13, color:s.color, fontWeight:700, marginBottom:2 }}>{s.stage}</div>
              <div style={{ fontSize:11, color:"rgba(255,255,255,0.5)", lineHeight:1.55 }}>{s.desc}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function NavBtn({ t, active, onClick }) {
  return (
    <button onClick={onClick} style={{
      flex:1, padding:"8px 4px 6px", borderRadius:12, border:"none", cursor:"pointer",
      background: active ? "rgba(56,189,248,0.12)" : "transparent",
      color: active ? "#38bdf8" : "rgba(255,255,255,0.28)",
      fontSize:9, fontWeight:700, textTransform:"uppercase", letterSpacing:0.4,
      display:"flex", flexDirection:"column", alignItems:"center", gap:3,
      transition:"all 0.15s",
      outline:"none",
      WebkitTapHighlightColor:"transparent",
      boxShadow: active ? "inset 0 0 0 1.5px rgba(56,189,248,0.3)" : "none",
    }}>
      <span style={{ fontSize:19, lineHeight:1 }}>{t.icon}</span>
      <span style={{ lineHeight:1 }}>{t.label}</span>
    </button>
  );
}
export default function App() {
  const [screen, setScreen] = useState("trips");
  const [selected, setSelected] = useState(null);
  const [filter, setFilter] = useState("all");
  const [storageReady, setStorageReady] = useState(false);
  const [navOpen, setNavOpen] = useState(false);
  const sheetLock = useRef(false); // prevents card re-open on same tap as close

  // Safe open — blocked while lock is active
  const openSheet = (dest) => {
    if (sheetLock.current) return;
    setSelected(dest);
  };

  // Safe close — sets lock for 400ms so the tap that closes can't re-open
  const closeSheet = () => {
    sheetLock.current = true;
    setSelected(null);
    setTimeout(() => { sheetLock.current = false; }, 400);
  };

  // ── Persistent state ──
  const [done, setDone] = useState(new Set());
  const [gearChecked, setGearChecked] = useState(new Set());
  const [sightingsChecked, setSightingsChecked] = useState(new Set());
  const [journalCount, setJournalCount] = useState(0);
  const [streak, setStreak] = useState(0);
  const [lastRideDate, setLastRideDate] = useState(null);

  // ── Load from storage on mount ──
  useEffect(() => {
    async function load() {
      try {
        const keys = ["pwc_done","pwc_gear","pwc_sightings","pwc_journal_count","pwc_streak","pwc_last_ride"];
        const results = keys.map(k => { try { const v = localStorage.getItem(k); return v ? {value:v} : null; } catch(e) { return null; } });
        const [doneR, gearR, sightR, journalR, streakR, lastRideR] = results;

        if (doneR)    setDone(new Set(JSON.parse(doneR.value)));
        if (gearR)    setGearChecked(new Set(JSON.parse(gearR.value)));
        if (sightR)   setSightingsChecked(new Set(JSON.parse(sightR.value)));
        if (journalR) setJournalCount(JSON.parse(journalR.value));
        if (streakR)  setStreak(JSON.parse(streakR.value));
        if (lastRideR)setLastRideDate(JSON.parse(lastRideR.value));
      } catch(e) {
        console.warn("Storage load error:", e);
      }
      setStorageReady(true);
    }
    load();
  }, []);

  // ── Save helpers ──
  async function saveDone(next) {
    try { localStorage.setItem("pwc_done", JSON.stringify([...next])); } catch(e) {}
  }
  async function saveGear(next) {
    try { localStorage.setItem("pwc_gear", JSON.stringify([...next])); } catch(e) {}
  }
  async function saveSightings(next) {
    try { localStorage.setItem("pwc_sightings", JSON.stringify([...next])); } catch(e) {}
  }
  async function saveStreak(val, date) {
    try {
      localStorage.setItem("pwc_streak", JSON.stringify(val));
      localStorage.setItem("pwc_last_ride", JSON.stringify(date));
    } catch(e) {}
  }
  async function saveJournalCount(val) {
    try { localStorage.setItem("pwc_journal_count", JSON.stringify(val)); } catch(e) {}
  }

  // ── Toggling with save ──
  const toggleDone = id => {
    setDone(prev => {
      const n = new Set(prev);
      n.has(id) ? n.delete(id) : n.add(id);
      saveDone(n);
      return n;
    });
    // Streak logic — increment only when marking complete (not uncomplete)
    setDone(prev => {
      if (!prev.has(id)) {
        const today = new Date().toISOString().slice(0,10);
        const newStreak = lastRideDate === today ? streak : streak + 1;
        setStreak(newStreak);
        setLastRideDate(today);
        saveStreak(newStreak, today);
      }
      return prev;
    });
  };

  const toggleGear = id => {
    setGearChecked(prev => {
      const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id);
      saveGear(n);
      return n;
    });
  };

  const toggleSighting = id => {
    setSightingsChecked(prev => {
      const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id);
      saveSightings(n);
      return n;
    });
  };

  const incrementJournal = () => {
    setJournalCount(prev => {
      const next = prev + 1;
      saveJournalCount(next);
      return next;
    });
  };

  const filtered = destinations.filter(d => filter==="all"||d.level===filter);
  const tripPct = Math.round((done.size/destinations.length)*100);
  const totalGear = GEAR_CATEGORIES.reduce((a,c)=>a+c.items.length,0);
  const gearPct = Math.round((gearChecked.size/totalGear)*100);
  const criticalItems = GEAR_CATEGORIES.flatMap(c=>c.items.filter(i=>i.critical));
  const criticalDone = criticalItems.filter(i=>gearChecked.has(i.id)).length;

  const NAV_TABS = [
    {id:"trips",        icon:"🗺️", label:"Trips"},
    {id:"rightnow",     icon:"⚡", label:"Right Now"},
    {id:"preflight",    icon:"✅", label:"Preflight"},
    {id:"journal",      icon:"📓", label:"Journal"},
    {id:"float",        icon:"📋", label:"Float Plan"},
    {id:"sos",          icon:"🚨", label:"SOS"},
    {id:"weather",      icon:"🌤️", label:"Weather"},
    {id:"water",        icon:"💧", label:"Water"},
    {id:"tidal",        icon:"🌊", label:"Currents"},
    {id:"fuel",         icon:"⛽", label:"Fuel"},
    {id:"cost",         icon:"💰", label:"Trip Cost"},
    {id:"leaveby",      icon:"🕐", label:"Leave By"},
    {id:"fishing",      icon:"🎣", label:"Fishing"},
    {id:"seasonal",     icon:"🌡️", label:"Seasons"},
    {id:"vhf",          icon:"📻", label:"VHF"},
    {id:"permits",      icon:"📋", label:"Permits"},
    {id:"achievements", icon:"🏅", label:"Awards"},
    {id:"gear",         icon:"🎒", label:"Gear"},
  ];

  return (
    <div style={{ minHeight:"100vh", background:"#060c14", fontFamily:"'Barlow',sans-serif", maxWidth:480, margin:"0 auto", paddingBottom:80 }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Black+Han+Sans&family=Barlow:wght@400;500;600;700&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        body{background:#060c14;overscroll-behavior:none;-webkit-font-smoothing:antialiased;}
        @keyframes fadeSlide{from{opacity:0;transform:translateY(16px);}to{opacity:1;transform:translateY(0);}}
        @keyframes sheetUp{from{transform:translateY(40px);opacity:0;}to{transform:translateY(0);opacity:1;}}
        @keyframes shimmer{0%{background-position:-200% center;}100%{background-position:200% center;}}
        @keyframes pulse{0%,100%{opacity:1;}50%{opacity:0.5;}}
        @keyframes popIn{0%{transform:scale(0.88);opacity:0;}100%{transform:scale(1);opacity:1;}}
        @keyframes spin{from{transform:rotate(0deg);}to{transform:rotate(360deg);}}
        input[type=range]{-webkit-appearance:none;appearance:none;height:6px;border-radius:4px;background:rgba(255,255,255,0.1);outline:none;}
        input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:22px;height:22px;border-radius:50%;cursor:pointer;border:2px solid rgba(255,255,255,0.15);}
        input[type=date],input[type=time]{color-scheme:dark;}
        button{-webkit-tap-highlight-color:transparent;touch-action:manipulation;user-select:none;}
        a{-webkit-tap-highlight-color:transparent;}
        ::-webkit-scrollbar{width:0;height:0;}
        textarea{-webkit-appearance:none;font-family:'Barlow',sans-serif;}
      `}</style>

      {/* Loading splash */}
      {!storageReady && (
        <div style={{ position:"fixed", inset:0, background:"#060c14", zIndex:999, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:16 }}>
          <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:36, background:"linear-gradient(90deg,#00e5a0,#38bdf8,#a78bfa)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>PWC PRO 🏄</div>
          <div style={{ fontSize:24, animation:"spin 1s linear infinite" }}>⚙️</div>
          <div style={{ fontSize:12, color:"rgba(255,255,255,0.3)" }}>Loading your saved data...</div>
        </div>
      )}

      {/* HEADER */}
      <div style={{ padding:"28px 20px 16px", background:"linear-gradient(180deg,#0b1e30 0%,#060c14 100%)", position:"relative", overflow:"hidden", borderBottom:"1px solid rgba(255,255,255,0.05)" }}>
        {[{c:"#00e5a0",x:"80%",y:"10%",s:180},{c:"#38bdf8",x:"10%",y:"60%",s:120},{c:"#a78bfa",x:"60%",y:"70%",s:90}].map((o,i)=>(
          <div key={i} style={{ position:"absolute", left:o.x, top:o.y, width:o.s, height:o.s, borderRadius:"50%", background:`radial-gradient(circle,${o.c}22 0%,transparent 70%)`, pointerEvents:"none" }}/>
        ))}
        <div style={{ position:"relative", zIndex:1 }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:8 }}>
            <div>
              <div style={{ fontSize:10, color:"rgba(255,255,255,0.3)", letterSpacing:2, textTransform:"uppercase", marginBottom:4 }}>📍 Abita Springs, LA</div>
              <div style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:32, lineHeight:1, letterSpacing:1 }}>
                <span style={{ color:"#fff" }}>PWC </span>
                <span style={{ background:"linear-gradient(90deg,#00e5a0 0%,#38bdf8 50%,#a78bfa 100%)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent", backgroundSize:"200%", animation:"shimmer 4s linear infinite" }}>PRO 🏄</span>
              </div>
            </div>
            {/* Quick stats pills */}
            <div style={{ display:"flex", flexDirection:"column", gap:4, alignItems:"flex-end" }}>
              <div style={{ fontSize:11, fontWeight:700, color:"#38bdf8", background:"rgba(56,189,248,0.12)", border:"1px solid rgba(56,189,248,0.25)", borderRadius:20, padding:"3px 10px" }}>
                {done.size}/15 🏄
              </div>
              <div style={{ fontSize:11, fontWeight:700, color:"#4ade80", background:"rgba(74,222,128,0.12)", border:"1px solid rgba(74,222,128,0.25)", borderRadius:20, padding:"3px 10px" }}>
                {streak > 0 ? `${streak}d 🔥` : `${gearChecked.size}/${GEAR_CATEGORIES.reduce((a,c)=>a+c.items.length,0)} 🎒`}
              </div>
            </div>
          </div>

          {/* Combined progress bar */}
          <div style={{ display:"flex", gap:4 }}>
            <div style={{ flex:1 }}>
              <div style={{ display:"flex", justifyContent:"space-between", marginBottom:4 }}>
                <span style={{ fontSize:9, color:"rgba(255,255,255,0.25)", textTransform:"uppercase", letterSpacing:0.5 }}>Trips</span>
                <span style={{ fontSize:9, color:"#38bdf8", fontWeight:700 }}>{Math.round((done.size/destinations.length)*100)}%</span>
              </div>
              <div style={{ background:"rgba(255,255,255,0.07)", borderRadius:6, height:6, overflow:"hidden" }}>
                <div style={{ height:6, borderRadius:6, width:`${Math.round((done.size/destinations.length)*100)}%`, background:"linear-gradient(90deg,#00e5a0,#38bdf8)", transition:"width 0.5s ease", boxShadow:"0 0 8px #38bdf855" }}/>
              </div>
            </div>
            <div style={{ flex:1 }}>
              <div style={{ display:"flex", justifyContent:"space-between", marginBottom:4 }}>
                <span style={{ fontSize:9, color:"rgba(255,255,255,0.25)", textTransform:"uppercase", letterSpacing:0.5 }}>Gear</span>
                <span style={{ fontSize:9, color:"#4ade80", fontWeight:700 }}>{Math.round((gearChecked.size/GEAR_CATEGORIES.reduce((a,c)=>a+c.items.length,0))*100)}%</span>
              </div>
              <div style={{ background:"rgba(255,255,255,0.07)", borderRadius:6, height:6, overflow:"hidden" }}>
                <div style={{ height:6, borderRadius:6, width:`${Math.round((gearChecked.size/GEAR_CATEGORIES.reduce((a,c)=>a+c.items.length,0))*100)}%`, background:"linear-gradient(90deg,#4ade80,#22c55e)", transition:"width 0.5s ease", boxShadow:"0 0 8px #4ade8055" }}/>
              </div>
            </div>
            <div style={{ flex:1 }}>
              <div style={{ display:"flex", justifyContent:"space-between", marginBottom:4 }}>
                <span style={{ fontSize:9, color:"rgba(255,255,255,0.25)", textTransform:"uppercase", letterSpacing:0.5 }}>Badges</span>
                <span style={{ fontSize:9, color:"#e8c547", fontWeight:700 }}>{Math.round((ACHIEVEMENTS.filter(a=>a.check(done,destinations,sightingsChecked,journalCount)).length/ACHIEVEMENTS.length)*100)}%</span>
              </div>
              <div style={{ background:"rgba(255,255,255,0.07)", borderRadius:6, height:6, overflow:"hidden" }}>
                <div style={{ height:6, borderRadius:6, width:`${Math.round((ACHIEVEMENTS.filter(a=>a.check(done,destinations,sightingsChecked,journalCount)).length/ACHIEVEMENTS.length)*100)}%`, background:"linear-gradient(90deg,#e8c547,#fb923c)", transition:"width 0.5s ease", boxShadow:"0 0 8px #e8c54755" }}/>
              </div>
            </div>
          </div>

          {criticalDone<criticalItems.length&&(
            <div style={{ marginTop:10, background:"rgba(220,38,38,0.12)", border:"1px solid rgba(220,38,38,0.3)", borderRadius:10, padding:"8px 12px", display:"flex", gap:8, alignItems:"center" }}>
              <span style={{ fontSize:14 }}>🚨</span>
              <span style={{ fontSize:11, color:"#f87171" }}>{criticalItems.length-criticalDone} critical gear items still needed before any trip</span>
            </div>
          )}
        </div>
      </div>

      {/* SCREEN TITLE BAR */}
      <div style={{ padding:"10px 16px 6px", display:"flex", alignItems:"center", justifyContent:"space-between", borderBottom:"1px solid rgba(255,255,255,0.04)" }}>
        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
          <span style={{ fontSize:18 }}>{NAV_TABS.find(t=>t.id===screen)?.icon}</span>
          <span style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:16, color:"rgba(255,255,255,0.7)", letterSpacing:0.5 }}>
            {NAV_TABS.find(t=>t.id===screen)?.label.toUpperCase()}
          </span>
        </div>
        {screen==="gear" && (
          <button onClick={async()=>{
            if(!confirm("Reset all saved data? This cannot be undone.")) return;
            try {
              await Promise.all(["pwc_done","pwc_gear","pwc_sightings","pwc_journal_count","pwc_streak","pwc_last_ride","pwc_journal_entries","pwc_scheduled_trips"].map(k=>(() => { try { localStorage.removeItem(k); } catch(e) {} })()));
              setDone(new Set()); setGearChecked(new Set()); setSightingsChecked(new Set());
              setJournalCount(0); setStreak(0); setLastRideDate(null);
            } catch(e) {}
          }} style={{ fontSize:10, color:"rgba(255,255,255,0.25)", background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.1)", borderRadius:8, padding:"4px 10px", cursor:"pointer", fontWeight:700 }}>
            Reset Data
          </button>
        )}
        {screen!=="gear" && (
          <div style={{ fontSize:10, color:"rgba(255,255,255,0.2)", display:"flex", alignItems:"center", gap:4 }}>
            <span style={{ width:6, height:6, borderRadius:"50%", background:"#4ade80", display:"inline-block", boxShadow:"0 0 6px #4ade80" }}/>
            Saved
          </div>
        )}
      </div>

      {/* CONTENT */}
      {screen==="trips"&&(
        <>
          <div style={{ padding:"12px 16px 8px", display:"flex", gap:8, overflowX:"auto", WebkitOverflowScrolling:"touch" }}>
            {[["all","🌊 All"],["easy","🟢 Easy"],["moderate","🟡 Moderate"],["advanced","🔴 Advanced"]].map(([v,l])=>(
              <button key={v} onClick={()=>setFilter(v)} style={{ padding:"9px 18px", borderRadius:24, border:"none", cursor:"pointer", fontSize:12, fontWeight:700, whiteSpace:"nowrap", flexShrink:0, background:filter===v?"#fff":"rgba(255,255,255,0.07)", color:filter===v?"#060c14":"rgba(255,255,255,0.45)", boxShadow:filter===v?"0 4px 16px rgba(255,255,255,0.15)":"none", transition:"all 0.15s" }}>{l}</button>
            ))}
          </div>
          <div style={{ padding:"4px 16px 12px" }}>
            <div style={{ fontSize:10, color:"rgba(255,255,255,0.2)", textTransform:"uppercase", letterSpacing:1, marginBottom:8 }}>📅 Year at a Glance</div>
            <div style={{ display:"flex", gap:8, overflowX:"auto", paddingBottom:6, WebkitOverflowScrolling:"touch" }}>
              {destinations.map(d=>(
                <div key={d.id} onClick={()=>openSheet(d)} style={{ flexShrink:0, width:66, cursor:"pointer", background:done.has(d.id)?"#052e16":`${d.color}12`, border:`1.5px solid ${done.has(d.id)?"#16a34a55":d.color+"44"}`, borderRadius:14, padding:"8px 4px", textAlign:"center" }}>
                  <div style={{ fontSize:18 }}>{done.has(d.id)?"✅":d.emoji}</div>
                  <div style={{ fontSize:9, color:done.has(d.id)?"#4ade80":d.color, fontWeight:700, marginTop:4, textTransform:"uppercase" }}>{d.month.slice(0,3)}</div>
                  <div style={{ fontSize:9, color:"rgba(255,255,255,0.35)", marginTop:2, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", padding:"0 4px" }}>{d.name.split(" ")[0]}</div>
                </div>
              ))}
            </div>
          </div>
          <div style={{ padding:"4px 16px 20px", display:"flex", flexDirection:"column", gap:10 }}>
            {filtered.map((d,i)=>(
              <TripCard key={d.id} dest={d} idx={i} onClick={openSheet} done={done.has(d.id)} onDone={toggleDone}/>
            ))}
          </div>
        </>
      )}
      {screen==="rightnow"&&<RightNowScreen destinations={destinations}/>}
      {screen==="preflight"&&<PreTripScreen destinations={destinations}/>}
      {screen==="float"&&<FloatPlanScreen destinations={destinations}/>}
      {screen==="sos"&&<SOSScreen/>}
      {screen==="cost"&&<TripCostScreen destinations={destinations}/>}
      {screen==="weather"&&<WeatherScreen destinations={destinations}/>}
      {screen==="water"&&<WaterScreen destinations={destinations}/>}
      {screen==="tidal"&&<TidalScreen destinations={destinations}/>}
      {screen==="fuel"&&<FuelCalc destinations={destinations}/>}
      {screen==="leaveby"&&<LeaveByScreen destinations={destinations}/>}
      {screen==="fishing"&&<FishingScreen destinations={destinations}/>}
      {screen==="seasonal"&&<SeasonalScreen destinations={destinations}/>}
      {screen==="vhf"&&<VhfScreen destinations={destinations}/>}
      {screen==="permits"&&<PermitsScreen/>}
      {screen==="journal"&&<JournalScreen destinations={destinations} done={done} onDone={(id)=>{toggleDone(id);incrementJournal();}}/>}
      {screen==="achievements"&&<AchievementsScreen done={done} destinations={destinations} sightingsChecked={sightingsChecked} journalCount={journalCount} streak={streak} toggleSighting={toggleSighting}/>}
      {screen==="gear"&&<GearChecklist checked={gearChecked} onToggle={toggleGear}/>}

      {/* ── BOTTOM NAV ── Collapsible */}
      <div style={{
        position:"fixed", bottom:0, left:"50%", transform:"translateX(-50%)",
        width:"100%", maxWidth:480, zIndex:100,
        background:"rgba(5,10,18,0.97)", backdropFilter:"blur(24px)",
        borderTop:"1px solid rgba(255,255,255,0.07)",
        paddingBottom:"env(safe-area-inset-bottom, 4px)",
        transition:"all 0.3s cubic-bezier(0.34,1.2,0.64,1)",
      }}>
        {/* Toggle handle — always visible */}
        <div
          onClick={()=>setNavOpen(p=>!p)}
          style={{ display:"flex", alignItems:"center", justifyContent:"center", padding:"10px 16px 8px", cursor:"pointer", userSelect:"none", position:"relative", minHeight:48 }}
        >
          {/* Chevron left */}
          <div style={{ position:"absolute", left:16, fontSize:14, color:"rgba(255,255,255,0.3)", transition:"transform 0.3s", transform:navOpen?"rotate(-90deg)":"rotate(90deg)" }}>❯</div>

          {/* Center — icon + label */}
          <div style={{ display:"flex", alignItems:"center", gap:8 }}>
            <span style={{ fontSize:20 }}>{NAV_TABS.find(t=>t.id===screen)?.icon}</span>
            <span style={{ fontFamily:"'Black Han Sans',sans-serif", fontSize:18, color:"#fff", letterSpacing:0.5 }}>
              {NAV_TABS.find(t=>t.id===screen)?.label.toUpperCase()}
            </span>
          </div>

          {/* Chevron right */}
          <div style={{ position:"absolute", right:16, fontSize:14, color:"rgba(255,255,255,0.3)", transition:"transform 0.3s", transform:navOpen?"rotate(90deg)":"rotate(-90deg)" }}>❯</div>
        </div>

        {/* Collapsible nav grid */}
        <div style={{
          overflow:"hidden",
          maxHeight: navOpen ? "300px" : "0px",
          transition:"max-height 0.3s cubic-bezier(0.34,1.1,0.64,1)",
        }}>
          <div style={{ padding:"4px 6px 2px", display:"flex" }}>
            {NAV_TABS.slice(0,4).map(t=><NavBtn key={t.id} t={t} active={screen===t.id} onClick={()=>{setScreen(t.id);setNavOpen(false);}}/>)}
          </div>
          <div style={{ padding:"2px 6px 2px", display:"flex" }}>
            {NAV_TABS.slice(4,8).map(t=><NavBtn key={t.id} t={t} active={screen===t.id} onClick={()=>{setScreen(t.id);setNavOpen(false);}}/>)}
          </div>
          <div style={{ padding:"2px 6px 2px", display:"flex" }}>
            {NAV_TABS.slice(8,12).map(t=><NavBtn key={t.id} t={t} active={screen===t.id} onClick={()=>{setScreen(t.id);setNavOpen(false);}}/>)}
          </div>
          <div style={{ padding:"2px 6px 8px", display:"flex" }}>
            {NAV_TABS.slice(12).map(t=><NavBtn key={t.id} t={t} active={screen===t.id} onClick={()=>{setScreen(t.id);setNavOpen(false);}}/>)}
          </div>
        </div>
      </div>

      {selected&&<Sheet dest={selected} onClose={closeSheet} done={done.has(selected.id)} onDone={toggleDone}/>}
    </div>
  );
}
