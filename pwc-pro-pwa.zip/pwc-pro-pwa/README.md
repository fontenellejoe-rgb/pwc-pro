# PWC Pro — Deploy Guide

## What's in this folder

```
pwc-pro-pwa/
├── index.html          ← App entry point
├── vite.config.js      ← Build config
├── package.json        ← Dependencies
├── .gitignore
├── public/
│   ├── manifest.json   ← PWA install config
│   ├── sw.js           ← Offline service worker
│   └── icons/          ← App icons
└── src/
    ├── main.jsx        ← React bootstrap
    └── App.jsx         ← The entire app (4000+ lines)
```

---

## Deploy to Vercel (free, ~5 minutes)

### Option A — Drag and Drop (easiest)

1. Go to **vercel.com** and sign up with GitHub, Google, or email (free)
2. Click **"Add New Project"**
3. Click **"Import Third-Party Git Repository"** → skip this, look for **"Deploy without Git"** or use the CLI below

### Option B — Vercel CLI (fastest, recommended)

1. Install Node.js from **nodejs.org** if you don't have it
2. Open Terminal and run:

```bash
# Install Vercel CLI
npm install -g vercel

# Navigate to this folder
cd path/to/pwc-pro-pwa

# Install dependencies
npm install

# Deploy
vercel

# Follow the prompts:
# - Set up and deploy? Y
# - Which scope? (your account)
# - Link to existing project? N
# - Project name: pwc-pro
# - In which directory is your code? ./
# - Override settings? N
```

3. Done — Vercel gives you a URL like **pwc-pro.vercel.app**

---

## Make it installable on iPhone

1. Open **pwc-pro.vercel.app** in Safari on your iPhone
2. Tap the **Share** button (box with arrow)
3. Tap **"Add to Home Screen"**
4. Name it **PWC Pro** → tap **Add**

It now appears on your home screen like a real app. Opens full screen, no browser bar.

---

## Update the app in the future

When I give you an updated `App.jsx` from Claude:

1. Replace `src/App.jsx` with the new file
2. Run `vercel` in the folder again (or just `vercel --prod`)
3. Done — everyone gets the update instantly

That's the full update cycle. Takes about 30 seconds.

---

## Run locally (optional)

```bash
npm install
npm run dev
# Opens at http://localhost:3000
```

---

## Offline support

The service worker caches the app shell on first load. After that, all 19 screens work with zero signal — critical for remote trips. External links (NOAA, USGS, Windy) require internet but the app itself does not.

---

## Your data

All your data (trips, gear, journal, sightings, streak) is stored in **localStorage** on your device. It never leaves your phone. Clearing browser data will clear it, but normal use is safe.
